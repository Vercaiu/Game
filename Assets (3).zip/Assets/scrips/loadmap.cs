using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class loadmap : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }
    public GameObject[] tilesarray;
    public GameObject[] unitsarray;
    public double currentx = 0;
    public double currentz = 0;
    private int count = 0;
    public static int player_count = 6;
    private int current_count = 0;
    private GameObject currentunit;
    // Start is called before the first frame update
    public int value;
    public override string ToString()
    {
        return "MyClass - value: " + value.ToString();
    }

    public int mapMaker(List<string> map)
    {
        newturn.units.Clear();
        load_game.people.Clear();
        ColorRandomizer.excludedColors.Clear();
        ColorRandomizer.excludedColors.Add(Color.blue);
        count = 1;
        List<string> valuesArray = map;
        string[] value1 = valuesArray[count].Split(',');
        GameObject tiled = Instantiate(tilesarray[int.Parse(value1[0])], new Vector3((float).85, 0, (float)-1.5), tilesarray[int.Parse(value1[0])].transform.rotation, GameObject.Find("tiles").transform);
        MyCamera.centerOfMap = tiled.transform;
        Debug.Log(valuesArray.Count);
        place_unit(count, valuesArray, value1, tiled);
        tiled.GetComponent<clickingobject>().tiledigit = int.Parse(value1[0]);
        ++count;
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < i; j++)
            {
                string[] value = valuesArray[count].Split(',');
                currentz += -1.5;
                currentx += -.85;
                GameObject tile = Instantiate(tilesarray[int.Parse(value[0])], new Vector3((float)currentx, 0, (float)currentz), tilesarray[int.Parse(value[0])].transform.rotation, GameObject.Find("tiles").transform);
                place_unit(count, valuesArray, value, tile);
                tile.GetComponent<clickingobject>().tiledigit = int.Parse(value[0]);
                ++count;
            }
            for (int k = 0; k < i; k++)
            {
                string[] value = valuesArray[count].Split(',');
                //  Debug.Log(count);
                currentz += 0;
                currentx += -1.7;
                GameObject tile = Instantiate(tilesarray[int.Parse(value[0])], new Vector3((float)currentx, 0, (float)currentz), tilesarray[int.Parse(value[0])].transform.rotation, GameObject.Find("tiles").transform);
                
                place_unit(count, valuesArray, value, tile);
                tile.GetComponent<clickingobject>().tiledigit = int.Parse(value[0]);
                ++count;
            }
            for (int k = 0; k < i; ++k)
            {
                string[] value = valuesArray[count].Split(',');
                //  Debug.Log(count);
                currentz += 1.5;
                currentx += -.85;
                GameObject tile = Instantiate(tilesarray[int.Parse(value[0])], new Vector3((float)currentx, 0, (float)currentz), tilesarray[int.Parse(value[0])].transform.rotation, GameObject.Find("tiles").transform);
                place_unit(count, valuesArray, value, tile);
                tile.GetComponent<clickingobject>().tiledigit = int.Parse(value[0]);
                ++count;
            }
            for (int k = 0; k < i; ++k)
            {
                string[] value = valuesArray[count].Split(',');
                currentz += 1.5;
                currentx += .85;
                GameObject tile = Instantiate(tilesarray[int.Parse(value[0])], new Vector3((float)currentx, 0, (float)currentz), tilesarray[int.Parse(value[0])].transform.rotation, GameObject.Find("tiles").transform);
                place_unit(count, valuesArray, value, tile);
                tile.GetComponent<clickingobject>().tiledigit = int.Parse(value[0]);
                ++count;
            }
            for (int k = 0; k < i; ++k)
            {
                string[] value = valuesArray[count].Split(',');
                // Debug.Log(count);
                currentz += 0;
                currentx += 1.7;
                GameObject tile = Instantiate(tilesarray[int.Parse(value[0])], new Vector3((float)currentx, 0, (float)currentz), tilesarray[int.Parse(value[0])].transform.rotation, GameObject.Find("tiles").transform);
                place_unit(count, valuesArray, value, tile);
                tile.GetComponent<clickingobject>().tiledigit = int.Parse(value[0]);
                ++count;
            }
            for (int k = 0; k < (i - 1); ++k)
            {
                string[] value = valuesArray[count].Split(',');
                // Debug.Log(count);
                currentz += -1.5;
                currentx += .85;
                GameObject tile = Instantiate(tilesarray[int.Parse(value[0])], new Vector3((float)currentx, 0, (float)currentz), tilesarray[int.Parse(value[0])].transform.rotation, GameObject.Find("tiles").transform);
                place_unit(count, valuesArray, value, tile);
                tile.GetComponent<clickingobject>().tiledigit = int.Parse(value[0]);
                ++count;
            }
            for (int k = 0; k < 1; ++k)
            { if (count < 160)
                {


                    string[] value = valuesArray[count].Split(',');
                    currentz += -1.5;
                    currentx += .85;
                    currentx += 1.7;
                    GameObject tile = Instantiate(tilesarray[int.Parse(value[0])], new Vector3((float)currentx, 0, (float)currentz), tilesarray[int.Parse(value[0])].transform.rotation, GameObject.Find("tiles").transform);
                    place_unit(count, valuesArray, value, tile);
                    tile.GetComponent<clickingobject>().tiledigit = int.Parse(value[0]);
                    ++count;
                }
                else
                {
                    break;
                }

            }
        }
      currentx = 0;
      currentz = 0;
    MyCamera mycamera = GameObject.FindObjectOfType<MyCamera>();
        mycamera.cameraposition();

        return count;
    }
    private void place_unit(int count, List<string> test 
        , string[] info, GameObject newtile)
    {
        if (info.Length >=2)
        {
            newtile.GetComponent<clickingobject>().unitontile = true;

            float y = convertor.placeunitontile(unitsarray[int.Parse(info[12])], newtile);
            Vector3 desiredPosition = new Vector3((float)currentx, y, (float)currentz);
            GameObject instantiatedObject = Instantiate(unitsarray[int.Parse(info[12])], desiredPosition, Quaternion.Euler(0f, 0f, 0f), GameObject.Find("units").transform);
            
            ++current_count; //info from save game
            List<string> list = info.ToList();
            list.RemoveAt(0);
            List<object> objectList = list.Select(str => (object)str).ToList();
            main.Instance.unit_Info.Create_unit(objectList, instantiatedObject);
            stats_ui.setui(instantiatedObject);
            /*            instantiatedObject.GetComponent<unit_info>().controller = info[1];
                        instantiatedObject.GetComponent<unit_info>().Health = int.Parse(info[2]);
                        instantiatedObject.GetComponent<unit_info>().Attack = int.Parse(info[3]);
                        instantiatedObject.GetComponent<unit_info>().Defense = int.Parse(info[4]);
                        instantiatedObject.GetComponent<unit_info>().mojo = int.Parse(info[6]);
                        instantiatedObject.GetComponent<unit_info>().attributes = info[7];
                        instantiatedObject.GetComponent<unit_info>().Type = info[8];*/
           bool nothere = true;
            for (int i = 0; i < newturn.units.Count; i++)
            {
                if(newturn.units[i][0].GetComponent<unit_info>().controller
                    == instantiatedObject.GetComponent<unit_info>().controller)
                {
                    newturn.units[i].Add(instantiatedObject);
                    instantiatedObject.GetComponent<unit_info>().color = newturn.units[i][0].GetComponent<unit_info>().color;
                    newtile.GetComponent<Renderer>().material.color = instantiatedObject.GetComponent<unit_info>().color;
                    nothere = false;
                }
            }
            if (nothere)
            {
                List<GameObject> controller = new List<GameObject>();
                if(instantiatedObject.GetComponent<unit_info>().controller == web.user)
                {
                    instantiatedObject.GetComponent<unit_info>().color = Color.blue;
                    newtile.GetComponent<Renderer>().material.color = instantiatedObject.GetComponent<unit_info>().color;
                }
                else
                {
                  Color color =  ColorRandomizer.SetRandomColor();
                    ColorRandomizer.excludedColors.Add(color);
                    instantiatedObject.GetComponent<unit_info>().color = color;
                    newtile.GetComponent<Renderer>().material.color = instantiatedObject.GetComponent<unit_info>().color;
                }
                
                controller.Add(instantiatedObject);

                // Create a new instance of the controller list before adding it to people list
                List<GameObject> newController = new List<GameObject>(controller);
                newturn.units.Add(newController);
            }
        }
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
