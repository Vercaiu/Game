using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class creategame_ui : MonoBehaviour
{
    public GameObject creategames;
    public static bool creategameswitch = false;
    public static bool joingameswitch = false;
    public static int gamenum;
    public int gamenumtrue;
    public static List<string> games;
    // Start is called before the first frame update


    public void getgames()
    {//https://lone-child.000webhostapp.com/createpreviousgames.php
        StartCoroutine(main.Instance.web.Upload("none!", "none!", "none!", "http://localhost/lone_child/createpreviousgames.php"));
        StartCoroutine(
            
        Wait(() =>
        {
            // Assuming you have a reference to the "load_game" transform
            Transform loadGameTransform = GameObject.Find("create_game").transform;

            // Loop to destroy all child objects
            int childCount = loadGameTransform.childCount;
            for (int i = childCount - 1; i >= 0; i--)
            {
                Transform child = loadGameTransform.GetChild(i);
                Destroy(child.gameObject);
            }
            int placeholder = -1;
            List<List<string>> gamess = new List<List<string>>();
            //this loop separates the compiled list of games information into it's own section
            for (int i = 0; i < games.Count; i++)
            {   if(i % 8 == 0)
                {
                    List<string> game = new List<string>();
                    gamess.Add(game);
                    ++placeholder;
                }
                gamess[placeholder].Add(games[i]);
            }
            for (int i = 0; i < gamess.Count; i++)
            {
                int players = 6;
                for (int j = 0; j < gamess[i].Count; j++)
                {
                if (gamess[i][j] == null)
                    {
                        --players;
                    }
                }
                GameObject creategamess = Instantiate(creategames, GameObject.Find("create_game").transform);
                creategamess.transform.Find("amount").GetComponent<TextMeshProUGUI>().text = players +"/" + gamess[i][6];
                creategamess.transform.Find("user").GetComponent<TextMeshProUGUI>().text = gamess[i][0];
                creategamess.GetComponent<creategame_ui>().gamenumtrue = int.Parse(gamess[i][7]);
                Debug.Log(creategamess.GetComponent<creategame_ui>().gamenumtrue);
            }
           // Canvascontroller.DisableChildElements(GameObject.Find("create_game"));
        }));
        }
    private IEnumerator Wait(Action callback)
    {
        // Perform the operations of the other method
        // ...
        yield return new WaitForSeconds(1.5f);
        // Once the operations are complete, invoke the callback
        callback?.Invoke();
        
    }

    private IEnumerator Wait2(Action callback)
    {
        // Perform the operations of the other method
        // ...
        yield return new WaitForSeconds(2f);
        // Once the operations are complete, invoke the callback
        callback?.Invoke();

    }

    public void creategamescreen()
    {
        StartCoroutine(
                
                Wait(() =>
        {


            Debug.Log("Second");
            Debug.Log(creategameswitch);
            Debug.Log(creategame.hero);
            if (creategameswitch)
            {


                string[] stringArray = creategame.hero.Split('|');
                GameObject creategamess = Instantiate(creategames, GameObject.Find("create_game").transform);
                Debug.Log(gamenum);
                creategames.GetComponent<creategame_ui>().gamenumtrue = (gamenum + 1);
                creategamess.transform.Find("amount").GetComponent<TextMeshProUGUI>().text = "1/" + stringArray[1];
                creategamess.transform.Find("user").GetComponent<TextMeshProUGUI>().text = web.user;

            }
            creategameswitch = false;
        }));
    }
   public void creategamescreen2()
    {
        Debug.Log("yo");


        string[] numplayers = this.transform.Find("amount").GetComponent<TextMeshProUGUI>().text.Split('/');
        string numplayersin = numplayers[0];
        string numplayersneeded = numplayers[1];
        string hero = "";
        //generates hero info to be sent out
        for (int i = 0; i < decks.hero.Count; i++)
        {
            hero += decks.hero[i];
            if (i < 10)
            {
                hero += ",";
            }
            else
            {
                break;
            }
        }
        creategame.hero = hero + "|" + numplayersin + "| " + GetComponent<creategame_ui>().gamenumtrue;
        Debug.Log(numplayers[0]);//https://lone-child.000webhostapp.com/addtopreviousgame.php
        StartCoroutine(main.Instance.web.Upload(web.user, decks.deck, creategame.hero, "http://localhost/lone_child/addtopreviousgame.php"));

        Debug.Log(this.transform.Find("amount").GetComponent<TextMeshProUGUI>().text);

        StartCoroutine(

        Wait(() =>
        {
            if (joingameswitch)
            {


                Debug.Log(GetComponent<creategame_ui>().gamenumtrue);
                this.transform.Find("amount").GetComponent<TextMeshProUGUI>().text = int.Parse(numplayersin) + 1 + "/" + numplayersneeded;
                // string gamecode = GetComponent<creategame_ui>().gamenumtrue + "";
                // Maps.player_count = int.Parse(values[1]);
                // StartCoroutine(main.Instance.web.Upload(gamecode, "none!", "none!", "https://lone-child.000webhostapp.com/createdgameinfo.php"));
                Debug.Log(int.Parse(numplayersin) + 1);
                Debug.Log(int.Parse(numplayersneeded));
                if ((int.Parse(numplayersin) + 1) == int.Parse(numplayersneeded))
                {
                    Debug.Log("check");
                    string gamecode = GetComponent<creategame_ui>().gamenumtrue + "";
                    Maps.player_count = int.Parse(numplayersneeded);//https://lone-child.000webhostapp.com/createdgameinfo.php
                    StartCoroutine(main.Instance.web.Upload(gamecode, GetComponent<creategame_ui>().gamenumtrue.ToString(), "none!", "http://localhost/lone_child/createdgameinfo.php"));
                }
            }
            }));
        StartCoroutine(

                    Wait2(() =>
                    {
                        if (joingameswitch)
                        {


                            if ((int.Parse(numplayersin) + 1) == int.Parse(numplayersneeded))
                            {


                                Debug.Log("check");//https://lone-child.000webhostapp.com/createtruegame.php
                                StartCoroutine(main.Instance.web.Upload(SaveGame.starter, "none!", "none!", "http://localhost/lone_child/createtruegame.php"));
                                Canvascontroller canvascontroller = GameObject.FindObjectOfType<Canvascontroller>();
                                canvascontroller.gotoGame();
                            }
                        }
                    }));
                
            joingameswitch = false;
        
            
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
