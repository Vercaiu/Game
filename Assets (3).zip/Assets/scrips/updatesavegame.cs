using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class updatesavegame : MonoBehaviour
{
    // Start is called before the first frame update
    public static string updategettiles()
    {

        Transform parentTransform = GameObject.Find("tiles").transform;
        Debug.Log(parentTransform.childCount);
        string start = "";

        for (int i = 0; i < parentTransform.childCount; i++)
        {
            int count = i + 1;
            Transform child = parentTransform.GetChild(i);
            int tile = child.gameObject.GetComponent<clickingobject>().tiledigit;
            RaycastHit hit;
            start += " space" + count + " = " + "'" + tile;
            if (Physics.Raycast(child.position, Vector3.up, out hit)
                && hit.collider.gameObject.transform.parent.name == "units")
            {   // check unit_info order
                start += "," + hit.collider.gameObject.GetComponent<unit_info>().key + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().Name + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().Type + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().Species + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().lore + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().Attack + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().Health + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().Defense + ","; //check unit_info order
                start += hit.collider.gameObject.GetComponent<unit_info>().Defensemax + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().mojo + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().attributes + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().modelnumber + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().controller + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().affliction + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().Affect + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().weapon + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().armor + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().shield + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().helmet;
            }
            start += "'";

            start += ",";

        }
        return start;
    }

    public void savinggamebutton()
    {

    }

    public void savinggame()
    {
       // List<string> savedgamedata = main.Instance.web.jsonConverter(jsonArrayString);
/*        Maps maps = GameObject.FindObjectOfType<Maps>();  // Get an instance of the Maps class or MapMaker object
        if (maps != null)
        {
            maps.mapMaker(savedgamedata);  // Call the createMap method on the Maps class or MapMaker object
        }*/
        string start = "UPDATE `new_games2` SET" + updategettiles();
        List<List<string>> hands = new List<List<string>>();
     //   int nullcount = 0;
      //  int count = 0;
/*        while (count < savedgamedata.Count)
        {

            if (savedgamedata[count] == null)
            {
                savedgamedata.RemoveAt(count);
                ++nullcount;
                count = -1;
            }
            ++count;
        }*/
        int personcount = 0;
        for (int i = 0; i < load_game.people.Count; i++)
        {
            ++personcount;
          //  Debug.Log(savedgamedata.Count);
            Debug.Log(i);
            string user = load_game.people[i][0];
            string cards = "'";
            string deckstr = "'";
            string graveyardstr = "'";
            if (user == web.user)
            {
                deckstr += convertor.listtophp(load_game.deckorder);
                cards += convertor.listtophp(load_game.handorder);
                graveyardstr += convertor.listtophp(load_game.graveyardorder);
                start += "player" + personcount + "deck = "
                + deckstr + "'," +
                "player" + personcount + "graveyard = " +
                graveyardstr + "', " +
                "player" + personcount + "hand = " +
                cards + "' ";
            }
            else if( user == null)
            {
                start += "player" + personcount + "= null, " + "player" + personcount + "deck = null, "+
"player" + personcount + "graveyard = null, "+
"player" + personcount + "hand = null";
            }
            else
            {
                start += "player" + personcount + "deck = '"
    + load_game.people[personcount - 1][1] + "'," +
    "player" + personcount + "graveyard = '" +
    load_game.people[personcount - 1][2] + "', " +
    "player" + personcount + "hand = '" +
    load_game.people[personcount - 1][3] + "'";
            }

                start += ",";

          //  string[] numberStrings = savedgamedata[i + 1].Split(',');
         //   List<string> deck = new List<string>(numberStrings);
/*            for (int j = 0; j < 2; j++)
            {
                cards += deck[0] + ",";
                hand.Add(deck[0]);
                deck.RemoveAt(0);
            }*/
/*            cards += "', ";
            hands.Add(hand);
            for (int k = 0; k < deck.Count; ++k)
            {
                deckstr += deck[k] + ",";
            }*/
          //  deckstr += "' ,";
        }
        /*        for (int i = 0; i < nullcount; i++)
                {
                    start += "null, ";
                    if (i % 3 == 0)
                    {
                        start += "null, ";
                    }
                }
                start += "'" + playerturn + "'" + ")";*/
        for (int i = 0; i < load_game.people.Count; i++)
        {
            if(load_game.turn == load_game.people[i][0])
            {
                if(i == load_game.people.Count-1)
                {
                    load_game.turn = load_game.people[0][0];
                    start += " playerturn = '" + load_game.people[0][0] + "'";
                    break;
                }
                else
                {
                    load_game.turn = load_game.people[i + 1][0];
                    start += " playerturn = '" + load_game.people[i + 1][0] + "'";
                    break;
                }
            }
        }
        int turnnum = load_game.turn_num++;
        start += ", turn_num = '" + turnnum + "', ";
        start += "gametype = '" + load_game.gametype + "', ";
        start += "ranked = '" + load_game.ranked + "'";
        start += " where gamenum = " + load_game.currentloadednum;
        Debug.Log(start);//https://lone-child.000webhostapp.com/updatesavegame.php
        StartCoroutine(main.Instance.web.Upload(start, "none!", "none!", "http://localhost/lone_child/updatesavegame.php"));
        //starter = start;
    }

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
