using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class login : MonoBehaviour
{
    public TMP_InputField UsernameInput;
    public TMP_InputField PasswordInput;
    public Button LoginButton;
    // Start is called before the first frame update
    void Start()
    {
        LoginButton.onClick.AddListener(() =>
        {
            StartCoroutine(UploadAndLogin());
        });
    }

    IEnumerator UploadAndLogin()
    {//https://lone-child.000webhostapp.com/login.php
        yield return StartCoroutine(main.Instance.web.Upload(UsernameInput.text, PasswordInput.text, "none!", "http://localhost/lone_child/login(1).php"));
        // yield return StartCoroutine(main.Instance.web.Upload(UsernameInput.text, "none!", "https://lone-child.000webhostapp.com/getDeck.php"));
        // Code to execute after both coroutines finish
    }



    // Update is called once per frame
    void Update()
    {
        
    }
}
