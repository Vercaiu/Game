using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class unit_info : MonoBehaviour
{
    public string Name = "";
    public int Health = 0;
    public int Attack = 0;
    public bool canAttack;
    public int Defense = 0;
    public int Defensemax = 0;
    public int modelnumber =0;
    public string Type = "";
    public int mojo = 0;
    public int lore = 0;
    public string Affect = "";
    public int key =0;

    public Color color = Color.white;
    public string attributes = "";
    public string controller = "";
    public string Species = "";
    public  string helmet;
    public  string shield;
    public  string armor;
    public  string weapon;
    public string affliction = "";
    // Start is called before the first frame update
    public bool canMove = true;
    public bool extraMove;
    public List<GameObject> PlacedUnits { get; set; }

    public void PlaceUnit(GameObject unit)
    {
        PlacedUnits.Add(unit);
    }
    public void Create_unit(List<object> unit, GameObject person)
    {
        person.GetComponent<unit_info>().key = int.Parse(unit[0].ToString().Trim('"'));
        person.GetComponent<unit_info>().Name = (string)unit[1];
        person.GetComponent<unit_info>().Type = (string)unit[2];
        person.GetComponent<unit_info>().Species = (string)unit[3];
        person.GetComponent<unit_info>().lore = int.Parse(unit[4].ToString());
        person.GetComponent<unit_info>().Attack = int.Parse(unit[5].ToString());
        person.GetComponent<unit_info>().Health = int.Parse(unit[6].ToString());
        person.GetComponent<unit_info>().Defense = int.Parse(unit[7].ToString());
        person.GetComponent<unit_info>().Defensemax = int.Parse(unit[8].ToString());
        person.GetComponent<unit_info>().mojo = int.Parse(unit[9].ToString());
        person.GetComponent<unit_info>().attributes = (string)unit[10];
        person.GetComponent<unit_info>().modelnumber = int.Parse(unit[11].ToString());
        if (unit.Count > 12)
        {
            person.GetComponent<unit_info>().controller = (string)unit[12];
        } else if(unit.Count > 13) 
        { 
            person.GetComponent<unit_info>().affliction = (string)unit[12];
            person.GetComponent<unit_info>().Affect = (string)unit[13];
            person.GetComponent<unit_info>().weapon = (string)unit[14];
            person.GetComponent<unit_info>().armor = (string)unit[15];
            person.GetComponent<unit_info>().shield = (string)unit[16];
            person.GetComponent<unit_info>().helmet = (string)unit[17];
        }
        if (person.GetComponent<unit_info>().Type == "hitter")
        {
            person.GetComponent<unit_info>().extraMove = true;
        }
        else
        {
            person.GetComponent<unit_info>().extraMove = false;
        }
        if(web.user == person.GetComponent<unit_info>().controller
            && person.GetComponent<unit_info>().Species == "Hero")
        {
            MyCamera.player = person.transform;
        }
        // Attach the unit_info component to the person GameObject

        // Call the PlaceUnit method if needed
        //  PlaceUnit(person);
    }
    void Start()
    {
        canAttack = true;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
