using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class stats_ui : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public static void setui(GameObject unit)
    {

        // Find the child Canvas object
        Canvas canvas = unit.GetComponentInChildren<Canvas>();
        unit_info script = unit.GetComponent<unit_info>();
        if (canvas != null)
        {
            // Find the child Health object within the Canvas
            canvas.transform.Find("Health").GetComponent<TextMeshProUGUI>().text = "Health: " + script.Health;
            canvas.transform.Find("defense").GetComponent<TextMeshProUGUI>().text = "Defense: " + script.Defense;
            canvas.transform.Find("attack").GetComponent<TextMeshProUGUI>().text = "Attack: " + script.Attack;
           // canvas.transform.Find("mojo crreated").GetComponent<TextMeshProUGUI>().text = "mojo created: " + script; 
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
