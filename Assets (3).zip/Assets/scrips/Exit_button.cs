using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Exit_button : MonoBehaviour
{
    public void ExitGame()
    {
        Application.Quit(); // This will exit the application
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
