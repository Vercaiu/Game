using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class nextturn : MonoBehaviour
{
    private IEnumerator Waitsmall(Action callback)
    {
        // Perform the operations of the other method
        // ...
        yield return new WaitForSeconds(3f);
        // Once the operations are complete, invoke the callback
        callback?.Invoke();

    }
    public void nextturnbutton()
    {
        Transform parentTransform = GameObject.Find("discarded").transform;
        if (web.user == load_game.turn)
        {
            if (parentTransform.childCount < 1)
            {
                GameObject.Find("must_discard").GetComponent<TextMeshProUGUI>().enabled = true;
                StartCoroutine(
                Waitsmall(() =>
                {
                    GameObject.Find("must_discard").GetComponent<TextMeshProUGUI>().enabled = false;
                }));
            }
            else
            {
                clickingobject.tilecolidders.Clear();
                load_game load_game = GameObject.FindObjectOfType<load_game>();
                load_game.graveyardbool = true;
                load_game.handbool = true;
                load_game.deckbool = true;
                for (int i = 0; i < parentTransform.childCount; i++)
                {
                   load_game.deckorder.Add(parentTransform.GetChild(i).GetComponent<unit_info>().key);
                    card_ui.fixhandorder(parentTransform.GetChild(i).GetComponent<unit_info>().key);
                }
                updatesavegame updatesavegame = GameObject.FindObjectOfType<updatesavegame>();
                updatesavegame.savinggame();
                load_game.loadedgames();
                creategame_ui creategame_ui = GameObject.FindObjectOfType<creategame_ui>();
                creategame_ui.getgames();
                cleanup.cleanupgameplay();
                StartCoroutine(

                Waitsmall(() =>
                {
                    Canvascontroller Canvascontroller = GameObject.FindObjectOfType<Canvascontroller>();
                    Canvascontroller.gotomakegame();

                }));
            }
        }
        else
        {
            cleanups();
        }
    }

    public void cleanups()
    {
        StartCoroutine(

Waitsmall(() =>
{
cleanup.cleanupgameplay();
Canvascontroller Canvascontroller = GameObject.FindObjectOfType<Canvascontroller>();
Canvascontroller.gotomakegame();
}));
        clickingobject.tilecolidders.Clear();
        load_game load_game = GameObject.FindObjectOfType<load_game>();
        load_game.loadedgames();
        creategame_ui creategame_ui = GameObject.FindObjectOfType<creategame_ui>();
        creategame_ui.getgames();
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
