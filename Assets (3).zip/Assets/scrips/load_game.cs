using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class load_game : MonoBehaviour
{
    public GameObject loadgameui;
    public static List<List<string>> people = new List<List<string>>();
    public static List<GameObject> player_turn;
    public int loadednum = 0;
    public static int currentloadednum = 0;
    public static List<string> loaded_info;

    public static string turn;
    public static string gametype = "FFA: 0";
    public static int turn_num = 1;
    public static string ranked = "unranked";


    public static List<int> deck_code = new List<int>();
    public static List<int> hand_code = new List<int>();
    public static List<int> graveyard_code = new List<int>();
    public static List<int> deckorder = new List<int>();
    public static List<int> handorder = new List<int>();
    public static List<int> graveyardorder = new List<int>();
    public static bool deckbool = true;
    public static bool handbool = true;
    public static bool graveyardbool = true;
    public static List<string> deckinfo = new List<string>();
    public static List<string> graveyardinfo = new List<string>();
    public static List<string> handinfo = new List<string>();
    public static List<List<string>> deckfullinfo = new List<List<string>>();

    private IEnumerator Wait(Action callback)
    {
        // Perform the operations of the other method
        // ...
        yield return new WaitForSeconds(1.5f);
        // Once the operations are complete, invoke the callback
        callback?.Invoke();

    }
    private IEnumerator Waitsmall(Action callback)
    {
        // Perform the operations of the other method
        // ...
        yield return new WaitForSeconds(.5f);
        // Once the operations are complete, invoke the callback
        callback?.Invoke();

    }
    /*    public static bool turn(GameObject selected)
        {
            Debug.Log(player_turn.Count);
    *//*        Debug.Log(people.Count);
            for (int i = 0; i < people.Count; i++)
            {*//* 
                for (int j = 0; j < player_turn.Count; j++)
                {
                    if( selected == player_turn[j])
                    {
                        return true;
                    }
                }
    *//*        }*//*
            return false;
        }*/
    public void loadgamebutton()
    {
        currentloadednum = this.loadednum;//https://lone-child.000webhostapp.com/loadgame.php
        StartCoroutine(main.Instance.web.Upload(this.loadednum + "", "none!", "none!", "http://localhost/lone_child/loadgame.php"));
    }
    public void loadedgames()
    {//https://lone-child.000webhostapp.com/loadedgames.php
        StartCoroutine(main.Instance.web.Upload(web.user, "none!", "none!", "http://localhost/lone_child/loadedgames.php"));
        StartCoroutine(

        Wait(() =>
        {
            // Assuming you have a reference to the "load_game" transform
            Transform loadGameTransform = GameObject.Find("game_holder").transform;

            // Loop to destroy all child objects
            int childCount = loadGameTransform.childCount;
            for (int i = childCount - 1; i >= 0; i--)
            {
                Transform child = loadGameTransform.GetChild(i);
                Destroy(child.gameObject);
            }
            Debug.Log(loaded_info.Count);
            for (int i = 0; i < loaded_info.Count; i+= 3)
            {
                GameObject loadgamesobject = Instantiate(loadgameui, GameObject.Find("game_holder").transform);
                loadgamesobject.transform.Find("playerturn").GetComponent<TextMeshProUGUI>().text = loaded_info[i];
                loadgamesobject.GetComponent<load_game>().loadednum = int.Parse(loaded_info[i + 1]);
                loadgamesobject.transform.Find("turncount").GetComponent<TextMeshProUGUI>().text = "P: "+loaded_info[i +2];
            }
           // Canvascontroller.EnableAllElements(GameObject.Find("load_game"));
        }));
    }

    public void loadgame(List<string> data)
    {
        
        loadmap loadmap = GameObject.FindObjectOfType<loadmap>();
        int count = loadmap.mapMaker(data);
        if (data.Count >= 5 && int.TryParse(data[data.Count - 3], out int parsedTurnNum))
        {
            (ranked, gametype, _, turn) = (data[^1], data[^2], data[^3], data[^4]);
            turn_num = parsedTurnNum;
            data.RemoveRange(data.Count - 4, 4);
        }
        Debug.Log(data[count]);
        int through = 0;
        Debug.Log(count);
        through = count;
        int nullcount = 0;
        while (through < data.Count)
        {

            if (data[through] == null)
            {
                data.RemoveAt(through);
                ++nullcount;
                through = count -1;
            }
            ++through;
        }
        for (int i = count; i < data.Count; i+= 4)
        {
            List<string> person = new List<string>();
            person.Add(data[i]);
            person.Add(data[i + 1]);
            person.Add(data[i + 2]);
            person.Add(data[i + 3]);
            people.Add(person);
        }
        string deck = "";
        string graveyard = "";
        string hand = "";
        for (int i = 0; i < people.Count; i++)
        {
            if(web.user == people[i][0])
            {
                Debug.Log(people[i][1]);
                string[] decksplit = people[i][1].Split(',');
                 deck = convertor.setupquery(decksplit, deck_code, deckorder);
                string[] graveyardsplit = people[i][2].Split(',');
                 graveyard = convertor.setupquery(graveyardsplit, hand_code, graveyardorder);
                string[] handsplit = people[i][3].Split(',');
                 hand = convertor.setupquery(handsplit, hand_code, handorder);
            }
        }
        Debug.Log(deck);
        Debug.Log(graveyard);
        Debug.Log(hand);
 deckbool = true;
 handbool = true;
 graveyardbool = true;
//https://lone-child.000webhostapp.com/getcardinfo.php
    StartCoroutine(main.Instance.web.Upload(deck, "none!", "none!", "http://localhost/lone_child/getcardinfo.php"));
        StartCoroutine(
Waitsmall(() =>
        {//https://lone-child.000webhostapp.com/getcardinfo.php
            StartCoroutine(main.Instance.web.Upload(graveyard, "none!", "none!", "http://localhost/lone_child/getcardinfo.php"));
        }));

        StartCoroutine(
Wait(() =>
        {//https://lone-child.000webhostapp.com/getcardinfo.php
            StartCoroutine(main.Instance.web.Upload(hand, "none!", "none!", "http://localhost/lone_child/getcardinfo.php"));
            Canvascontroller canvascontroller = GameObject.FindObjectOfType<Canvascontroller>();
            canvascontroller.gotoGame();
        }));
        /*        deckbool = true;
                graveyardbool = true;*/
    }




    // Start is called before the first frame update
    void Start()
    {
/*        buttongame.onClick.AddListener(() =>
        {
            StartCoroutine(WaitForCoroutine());
        });*/
    }

    IEnumerator WaitForCoroutine()
    {
        //yield return StartCoroutine(main.Instance.web.Gettiles());
        yield return null;
        main.Instance.Canvas.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
