using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class card_ui : MonoBehaviour
{
    public GameObject cards;
    public GameObject armorcards;
    private GameObject currentcard;
    public static Collider[] colliders;
    public static Collider[] placingunitcolliders;
    public static float tileradius = 1.5f;
    public bool discarded = false;
    private bool placingunit = false;
    private bool armored = false;
    
    private string parent;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    void Update()
    {

    }

    public void organizeCard1(GameObject unit, string find)
    {       //change where it is instantiated
        GameObject card = Instantiate(cards, GameObject.Find(find).transform);

        convertor.statstostats(unit, card);

        card.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = card.GetComponent<unit_info>().mojo.ToString(); //mojo
        card.transform.Find("attack").GetComponent<TextMeshProUGUI>().text = card.GetComponent<unit_info>().Attack.ToString(); //attack
        card.transform.Find("health").GetComponent<TextMeshProUGUI>().text = card.GetComponent<unit_info>().Health.ToString(); //health
        card.transform.Find("defense").GetComponent<TextMeshProUGUI>().text = card.GetComponent<unit_info>().Defense.ToString(); //defense
    }

    public void organizeCard2(List<string> unit, string find)
    {       //change where it is instantiated
        GameObject card = Instantiate(cards, GameObject.Find(find).transform);

        convertor.listtostats(card, unit);

        card.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = card.GetComponent<unit_info>().mojo.ToString(); //mojo
        card.transform.Find("attack").GetComponent<TextMeshProUGUI>().text = card.GetComponent<unit_info>().Attack.ToString(); //attack
        card.transform.Find("health").GetComponent<TextMeshProUGUI>().text = card.GetComponent<unit_info>().Health.ToString(); //health
        card.transform.Find("defense").GetComponent<TextMeshProUGUI>().text = card.GetComponent<unit_info>().Defense.ToString(); //defense
    }

    public void organizeArmor(List<string> weapon, string findable)
    {
        GameObject armorcard = Instantiate(armorcards, GameObject.Find(findable).transform);
        string strweapon = "";
        armorcard.GetComponent<unit_info>().key = int.Parse(weapon[0].ToString().Trim('"'));
        for (int i = 0; i < weapon.Count; i++)
        {
            strweapon += weapon[i].ToString().Trim('"');
            if(weapon.Count-1 > i)
            {
                strweapon += "$";
            }
        }
        armorcard.GetComponent<unit_info>().weapon = strweapon;

        armorcard.transform.Find("attack").GetComponent<TextMeshProUGUI>().text = weapon[5].ToString().Trim('"');
        armorcard.transform.Find("health").GetComponent<TextMeshProUGUI>().text = weapon[6].ToString().Trim('"');
        armorcard.transform.Find("defense").GetComponent<TextMeshProUGUI>().text = weapon[7].ToString().Trim('"');
        armorcard.transform.Find("addedmojo").GetComponent<TextMeshProUGUI>().text = weapon[8].ToString().Trim('"'); 
        armorcard.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = weapon[9].ToString().Trim('"');
    }


    public void mouseDown()
    {
        Transform Canvas = GameObject.Find("Canvas-gameplay").transform;
        if (Canvascontroller.CurrentCanvas.name == "Canvas-deckpage")
        {
            startdragdeckpage();
        }
        if (Canvascontroller.CurrentCanvas.name == "Canvas-gameplay")
        {
            CanvasDropHandler.newstring = "discarded";
            Debug.Log("Currently on the target canvas.");
            // Do your actions specific to the target canvas here

            Transform enhancedCardTransform = Canvas.transform.Find("enhanced_card");
            if (enhancedCardTransform.childCount > 8)
            {
                Destroy(enhancedCardTransform.GetChild(enhancedCardTransform.childCount - 1).gameObject);
            }
            Canvascontroller.DisableChildElements(enhancedCardTransform.gameObject);
            currentcard = gameObject;
            if (web.user == load_game.turn)
            {
                newturn.mojo -= currentcard.GetComponent<unit_info>().mojo;
                Canvas.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = "Mojo: " + newturn.mojo;
                if (currentcard.CompareTag("armorcard"))
                {
                    setarmorable(true, Color.green);
                    armored = true;
                }
                else if (currentcard.CompareTag("unitcard"))
                {
                    placingunit = true;
                    Transform parentTransform = GameObject.Find("units").transform;
                    for (int i = 0; i < parentTransform.childCount; i++)
                    {
                        Transform child = parentTransform.GetChild(i);
                        if (child.GetComponent<unit_info>().Species == "Hero"
                            && child.GetComponent<unit_info>().controller == web.user)
                        {
                            placingunitcolliders = Physics.OverlapSphere(child.position, tileradius); // 5f is the radius
                            foreach (Collider collider in placingunitcolliders)
                            {
                                clickingobject script = collider.gameObject.GetComponent<clickingobject>();
                                if (!collider.gameObject.CompareTag("blocker")
                                    && script.unitontile == false)
                                {
                                    Renderer renderer1 = collider.gameObject.GetComponent<Renderer>();
                                    script.placeunittile = true;

                                    renderer1.material.color = Color.clear;
                                }
                            }
                        }
                    }
                }
                if (currentcard.GetComponent<unit_info>().mojo <= newturn.mojo)
                {

                }
            }
        }
    }

    private void startdragdeckpage()
    {
        currentcard = gameObject;
        parent = gameObject.transform.parent.name;
        CanvasDropHandler.newstring = parent;
    }

    private void enddragstartpage()
    {

    }
    public void endDrag()
    {
        if (Canvascontroller.CurrentCanvas.name == "Canvas-gameplay")
        {
            Debug.Log("what is happening");
        bool usedmojo = false;
        // Check if the pointer is over a UI element
/*        if (EventSystem.current.IsPointerOverGameObject())
        {
            // Pointer is over a UI element (e.g., image in Canvas)
            Debug.Log("Drag ended on a UI element, ignoring further processing.");
        }*/
      //  else
       // {


        RaycastHit hit;
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (web.user == load_game.turn && newturn.mojo >= 0 && Physics.Raycast(ray, out hit))
        {

            GameObject tilehit = hit.collider.gameObject;
            if (tilehit.GetComponent<clickingobject>().placeunittile)
            {
                usedmojo = true;
                tilehit.GetComponent<clickingobject>().unitontile = true;
                Vector3 center = tilehit.transform.position;
                GameObject unit = main.Instance.maps.GetComponent<createmap>().unitsarray[currentcard.GetComponent<unit_info>().modelnumber];
                float y = convertor.placeunitontile(unit, tilehit);
                center.y += y; // move up by 0.5 units
                GameObject instantiatedObject = Instantiate(unit, center, tilehit.transform.rotation, GameObject.Find("units").transform);
            instantiatedObject.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
            unit_info draggedCardUnitInfo = currentcard.GetComponent<unit_info>();
                unit_info instantiatedObjectUnitInfo = instantiatedObject.GetComponent<unit_info>();
                instantiatedObjectUnitInfo.key = draggedCardUnitInfo.key;
                instantiatedObjectUnitInfo.mojo = draggedCardUnitInfo.mojo;
                instantiatedObjectUnitInfo.Health = draggedCardUnitInfo.Health;
                instantiatedObjectUnitInfo.Attack = draggedCardUnitInfo.Attack;
                instantiatedObjectUnitInfo.attributes = draggedCardUnitInfo.attributes;
                instantiatedObjectUnitInfo.Type = draggedCardUnitInfo.Type;
                instantiatedObjectUnitInfo.Species = draggedCardUnitInfo.Species;
                instantiatedObjectUnitInfo.Defense = draggedCardUnitInfo.Defense;
                instantiatedObjectUnitInfo.Defense = draggedCardUnitInfo.Defensemax;
                instantiatedObjectUnitInfo.Name = draggedCardUnitInfo.Name;
                instantiatedObjectUnitInfo.modelnumber = draggedCardUnitInfo.modelnumber;
                instantiatedObjectUnitInfo.controller = web.user;
            species.humanabilitygain(instantiatedObjectUnitInfo);
            main.Instance.tilespecial.enteringtile(tilehit, instantiatedObject);
            stats_ui.setui(instantiatedObject);
                fixhandorder(draggedCardUnitInfo.key);
                deathgraveyard.graveyard(instantiatedObjectUnitInfo.key, web.user);
                deleteCard(instantiatedObjectUnitInfo.key, "cards");
                Debug.Log("what is happening");
                clickingobject.reverting(hit);
            }
            else if (tilehit.GetComponent<clickingobject>().armorable)
            {
                string[] stringArray = currentcard.GetComponent<unit_info>().weapon.Split('$');
                tilehit.GetComponent<unit_info>().Attack += int.Parse(stringArray[5]);
                tilehit.GetComponent<unit_info>().Defense += int.Parse(stringArray[7]);
                tilehit.GetComponent<unit_info>().Defensemax += int.Parse(stringArray[7]);
                tilehit.GetComponent<unit_info>().Health += int.Parse(stringArray[6]);
                if (tilehit.GetComponent<unit_info>().Defense < 0)
                {
                    tilehit.GetComponent<unit_info>().Defense = 0;
                }
                deathgraveyard.ispersondead(tilehit);
                tilehit.GetComponent<clickingobject>().armorable = false;
                stats_ui.setui(tilehit);
                if (stringArray[2] == "hat")
                {
                    UpdateEquipment(info => info.helmet, (info, value) => info.helmet = value, tilehit, currentcard);
                }
                else if (stringArray[2] == "weapon")
                {
                    UpdateEquipment(info => info.weapon, (info, value) => info.weapon = value, tilehit, currentcard);
                }
                else if (stringArray[2] == "shield")
                {
                    UpdateEquipment(info => info.shield, (info, value) => info.shield = value, tilehit, currentcard);
                }
                fixhandorder(int.Parse(stringArray[0]));
                Transform Canvas = GameObject.Find("Canvas-gameplay").transform;
                newturn.mojo -= int.Parse(stringArray[9]);
                Canvas.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = "Mojo: " + newturn.mojo;
                deletearmorCard(currentcard.GetComponent<unit_info>().weapon);
                deathgraveyard.graveyard(int.Parse(stringArray[0]), web.user);
                clickingobject.reverting(hit);
            }
                    
                
        }
        //}
        if (usedmojo == false)
        {
            Transform Canvas = GameObject.Find("Canvas-gameplay").transform;
            newturn.mojo += currentcard.GetComponent<unit_info>().mojo;
            Canvas.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = "Mojo: " + newturn.mojo;
        }
        if (placingunit)
        {
            foreach (Collider collider in placingunitcolliders)
            {
                clickingobject script = collider.gameObject.GetComponent<clickingobject>();
                script.placeunittile = false;
                Renderer renderer1 = collider.gameObject.GetComponent<Renderer>();

                renderer1.material.color = Color.white;
            }
            placingunit = false;
        }
        if (armored)
        {
            setarmorable(false, Color.white);
            armored = false;
        }
        }
    }
    // Update is called once per frame

    public void deleteCard(int key, string parent)
        {
            Transform parentTransform = GameObject.Find(parent).transform;

            for (int i = 0; i < parentTransform.childCount; i++)
            {
                Transform child = parentTransform.GetChild(i);

                // Check if the child has a specific attribute/component
                int someComponent = child.GetComponent<unit_info>().key;

                if (someComponent == key)
                {
                    // Destroy the child object
                    Destroy(child.gameObject);
                    break;
                }
            }
    }

    public static void fixhandorder(int key)
    {
        for (int i = 0; i < load_game.handorder.Count; i++)
        {
            if (load_game.handorder[i] == key)
            {
                load_game.handorder.RemoveAt(i);
                break;
            }
        }
    }

    public void deletearmorCard(string weapon)
    {
        Transform parentTransform = GameObject.Find("cards").transform;

        for (int i = 0; i < parentTransform.childCount; i++)
        {
            Transform child = parentTransform.GetChild(i);

            // Check if the child has a specific attribute/component
            unit_info someComponent = child.GetComponent<unit_info>();

            if (someComponent.weapon == weapon)
            {
                // Destroy the child object
                Destroy(child.gameObject);
                break;
            }
        }
    }

    public void setarmorable(bool switches, Color type)
    {
        Transform parentTransform = GameObject.Find("units").transform;
        for (int i = 0; i < parentTransform.childCount; i++)
        {
            string[] stringArray = currentcard.GetComponent<unit_info>().weapon.Split('$');
            Transform child = parentTransform.GetChild(i);
            if (child.GetComponent<unit_info>().controller == web.user)
            {
                clickingobject script = child.gameObject.GetComponent<clickingobject>();
                if (stringArray[3] == child.GetComponent<unit_info>().Type
                    || stringArray[3] == "everyone")
                {
                    script.armorable = switches;
                    Renderer renderer1 = child.gameObject.GetComponent<Renderer>();
                    renderer1.material.color = type;
                }
            }
        }
    }

    public void UpdateEquipment(Func<unit_info, string> getEquipment, Action<unit_info, string> setEquipment, GameObject tilehit, GameObject currentcard)
    {
        string currentEquipment = getEquipment(tilehit.GetComponent<unit_info>());
        setEquipment(tilehit.GetComponent<unit_info>(), currentcard.GetComponent<unit_info>().weapon);

        if (!string.IsNullOrEmpty(currentEquipment))
        {
            string[] user = currentEquipment.Split('$');
            tilehit.GetComponent<unit_info>().Attack -= int.Parse(user[5]);
            tilehit.GetComponent<unit_info>().Defense -= int.Parse(user[7]);
            tilehit.GetComponent<unit_info>().Defensemax -= int.Parse(user[7]);
            tilehit.GetComponent<unit_info>().Health -= int.Parse(user[6]);
            if (tilehit.GetComponent<unit_info>().Defense < 0)
            {
                tilehit.GetComponent<unit_info>().Defense = 0;
            }
            deathgraveyard.graveyard(int.Parse(user[0]), web.user);
        }
    }
}
