using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class endofgame : MonoBehaviour
{
    private static List<int> losses = new List<int>();
    private static string user = "";
    private static bool win = false;
    // Start is called before the first frame update

    public void isherodead(unit_info info,string Hero, string matchtype)
    { 
        if(info.Species == "Hero")
        {
            losses.Clear();
            for (int i = 0; i < newturn.units.Count; i++)
            {
                if (newturn.units[i][0].GetComponent<unit_info>().controller == Hero)
                {
                    for (int j = 0; j < newturn.units[i].Count; j++)
                    {
                        losses.Add(newturn.units[i][j].GetComponent<unit_info>().key);
                        Destroy(newturn.units[i][j]);
                    }
                    getcardsinfo(Hero);
                    sendingdata(info,matchtype);
                }
            }
        }
    }

    private void getcardsinfo(string Hero)
    {
        for (int i = 0; i < load_game.people.Count; i++)
        {
            if (load_game.people[i][0] == Hero)
            {
                
                user = load_game.people[i][0];
                Debug.Log(user);
                string[] splitsdeck = load_game.people[i][1].Split(",");
                for (int j = 0; j < splitsdeck.Length; j++)
                {
                    losses.Add(int.Parse(splitsdeck[j]));
                }
                string[] splitsgraveyuard = load_game.people[i][2].Split(",");
                for (int j = 0; j < splitsgraveyuard.Length; j++)
                {
                    losses.Add(int.Parse(splitsgraveyuard[j]));
                }
                string[] splitshand = load_game.people[i][3].Split(",");
                for (int j = 0; j < splitshand.Length; j++)
                {
                    losses.Add(int.Parse(splitshand[j]));
                }
                load_game.people[i][0] = null;
                break;
            }
        }
    }

    private void sendingdata(unit_info info,string matchtype)
    {
        StringBuilder updateQuery = new StringBuilder();

        if (win)
        {
            UpdateQuery(updateQuery, "spell_info", "Wins", losses, 2000, 3000);
            UpdateQuery(updateQuery, "armor_info", "Wins", losses, 1000, 2000);
            UpdateQuery(updateQuery, "unit_info", "Wins", losses, 0, 1000);
        }
        else
        {
            UpdateQuery(updateQuery, "spell_info", "losses", losses, 2000, 3000);
            UpdateQuery(updateQuery, "armor_info", "losses", losses, 1000, 2000);
            UpdateQuery(updateQuery, "unit_info", "losses", losses, 0, 1000);
        }

        string complete = updateQuery.ToString();
        Debug.Log(complete);
        if (!win)
        {//https://lone-child.000webhostapp.com/recieved_losses.php
            StartCoroutine(main.Instance.web.Upload(complete, user, "none!", "http://localhost/lone_child/recieved_losses.php"));
            int count = 0;
            for (int j = 0; j < load_game.people.Count; j++)
            {
                if (load_game.people[j][0] != null)
                {
                    ++count;
                }
            }
            if (count == 1 && matchtype == "FFA")
            {
                win = true;
                isherodead(info ,web.user, matchtype);
            }
        }
        else
        {
            win = false;
            Debug.Log(load_game.currentloadednum);//https://lone-child.000webhostapp.com/recieved_wins.php
            StartCoroutine(main.Instance.web.Upload(complete, user, load_game.currentloadednum.ToString(), "http://localhost/lone_child/recieved_wins.php"));
        }
    }

    void UpdateQuery(StringBuilder queryBuilder, string tableName, string column, List<int> losses, int lowerThreshold, int upperThreshold)
    {
        List<int> filteredLosses = losses.Where(loss => loss >= lowerThreshold && loss < upperThreshold).ToList();
        if (filteredLosses.Count > 0)
        {
            queryBuilder.Append($"| UPDATE {tableName} SET {column} = {column} + 1 WHERE Keyed IN ({string.Join(",", filteredLosses)})");
            queryBuilder.AppendLine(); // Add a new line for readability
        }
    }

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
