using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class creategame : MonoBehaviour
{
    public static string hero;
   // public static string holder;
    // Start is called before the first frame update
    void Start()
    {
        
    }

/*    public static string  insertdeck()
    {
        int decklength = 0;
        int k = 0;
        string insert = "";
        for (int i = 0; i < decks.currentdeck.Count; i++)
        {
            decklength += decks.currentdeck[i].Count;
        }
        for (int i = 0; i < decks.currentdeck.Count; i++)
        {
            for (int j = 0; j < decks.currentdeck[i].Count; j++)
            {
                ++k;
                insert += decks.currentdeck[i][j];
                if (k <= decklength - 1)
                {
                    insert += ",";
                }
            }
        }
        return insert;
    }*/

    public void creategamemeth()
    {/*   string goin = "";
        int count1 = 0;
        int count2 = 0;
        for (int i = 0; i < decks.currentdecktrue.Count; i++)
        { ++count1;
            for (int j = 0; j < decks.currentdecktrue[i].Count; j++)
            { ++count2;
                goin += decks.currentdecktrue[i][j];
                if(count1 != decks.currentdecktrue.Count
                    || count2 != decks.currentdecktrue[i].Count)
                {
                    goin += ",";
                }
            }
            count2 = 0;
        }
        Debug.Log("yo");*/
        hero = "";
        for (int i = 0; i < decks.hero.Count; i++)
        {
            hero += decks.hero[i];
            if (i < 10)
            {
                hero += ",";
            }
            else
            {
                break;
            }
        }
        hero = hero + "|" + gamemodeselect.playeramount;
        Debug.Log(hero);
        //string insert = insertdeck(); //https://lone-child.000webhostapp.com/creategame.php
        StartCoroutine(main.Instance.web.Upload(web.user, decks.deck, hero, "http://localhost/lone_child/creategame.php"));
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
