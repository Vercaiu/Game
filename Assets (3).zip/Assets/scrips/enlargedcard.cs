using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class enlargedcard : MonoBehaviour
{
    private static GameObject card;
    
    public void infoaboutunit(GameObject gameObject)
    {
        Transform Canvas = GameObject.Find("Canvas-gameplay").transform;
        /*        Image image = Canvas.Find("enhanced_card").GetComponent<Image>();
                image.enabled = true;*/
        Transform enhancedCardTransform = Canvas.transform.Find("enhanced_card");
        // Destroy the existing enhanced card if there is one
        if (enhancedCardTransform.childCount > 8)
        {
            Destroy(enhancedCardTransform.GetChild(enhancedCardTransform.childCount - 1).gameObject);
        }
        Canvascontroller.EnableAllElements(enhancedCardTransform.gameObject);
        // Instantiate a copy of the clicked card and set it as the child of enhanced_card
        GameObject clickedCard = Instantiate(gameObject, enhancedCardTransform);
        card = clickedCard;
        RectTransform cardRectTransform = clickedCard.GetComponent<RectTransform>();
        clickedCard.GetComponent<Button>().enabled = false;
        cardRectTransform.anchorMin = new Vector2(1, 1);
        cardRectTransform.anchorMax = new Vector2(1, 1);
        cardRectTransform.pivot = new Vector2(1, 1);
        clickedCard.transform.localPosition = enhancedCardTransform.Find("Image").transform.localPosition;
        clickedCard.transform.localScale = enhancedCardTransform.Find("Image").transform.localScale;
        clickedCard.transform.Find("type").GetComponent<TextMeshProUGUI>().text = clickedCard.GetComponent<unit_info>().Type;
        clickedCard.transform.Find("species").GetComponent<TextMeshProUGUI>().text = clickedCard.GetComponent<unit_info>().Species;
        clickedCard.transform.Find("type").GetComponent<TextMeshProUGUI>().enabled = true;
        clickedCard.transform.Find("species").GetComponent<TextMeshProUGUI>().enabled = true;
    }
    public void clickCard()
    {
        infoaboutunit(gameObject);
    }

    public void loreclick()
    {
        Debug.Log("test test");
        Transform Canvas = GameObject.Find("Canvas-gameplay").transform;
        Transform enhancedCardTransform = Canvas.transform.Find("enhanced_card");
        Canvascontroller.DisableChildElements(enhancedCardTransform.GetChild(enhancedCardTransform.childCount-1).gameObject);
        enhancedCardTransform.GetChild(enhancedCardTransform.childCount - 1).gameObject.GetComponent<Image>().enabled = false;
        Transform rect = enhancedCardTransform.Find("scrollrect").transform;
        GameObject deeplore = rect.Find("loretext").gameObject;
        deeplore.transform.GetComponent<TextMeshProUGUI>().text = Lore.loresegments[card.GetComponent<unit_info>().lore];
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
