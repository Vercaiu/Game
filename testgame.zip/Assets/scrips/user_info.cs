using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class user_info : MonoBehaviour
{
     public string UserID { get; private set; }
     string UserName;
     string Password;

    public void SetCredentials(string username, string password)
    {
        UserName = username;
        Password = password;
    }
    public void setID(string id)
    {
        UserID = id;
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
