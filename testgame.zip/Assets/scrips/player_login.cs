using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player_login : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void setdeck()
    {
        Debug.Log("test test test");
        StartCoroutine(main.Instance.web.Upload(web.user, "Deck_1", "none!", "https://lone-child.000webhostapp.com/getDeck.php"));
    
    }

    public void pickHero()
    {
        Debug.Log("test test test");
        StartCoroutine(main.Instance.web.Upload(2 + "", "none!", "none!", "https://lone-child.000webhostapp.com/Get_Hero.php"));
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
