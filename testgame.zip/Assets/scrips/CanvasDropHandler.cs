using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

public class CanvasDropHandler : MonoBehaviour, IDropHandler
{
    public void OnDrop(PointerEventData eventData)
    {
        // Get the dropped GameObject (if any)
        GameObject droppedObject = eventData.pointerDrag;
        unit_info instantiatedObjectUnitInfo = droppedObject.GetComponent<unit_info>();
        // Check if a GameObject was dragged and dropped within the Canvas
        if (droppedObject != null && eventData.pointerEnter.transform is RectTransform
            && droppedObject.GetComponent<card_ui>().discarded == false)
        {
            Transform Canvas = GameObject.Find("Canvas-gameplay").transform;
            newturn.mojo += droppedObject.GetComponent<unit_info>().mojo;
            Canvas.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = "Mojo: " + newturn.mojo;
            // The droppedObject is a GameObject dragged within the Canvas
            Debug.Log("Dropped on an image within the Canvas!");
            GameObject discarded=Instantiate(droppedObject, GameObject.Find("discarded").transform);
            card_ui card_ui = GameObject.FindObjectOfType<card_ui>();
            discarded.GetComponent<card_ui>().discarded = true;
            card_ui.deleteCard(instantiatedObjectUnitInfo.Name);
            // Add your specific logic here for handling the dropped object on the image
        }
    }
}