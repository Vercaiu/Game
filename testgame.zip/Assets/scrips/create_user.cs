using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class create_user : MonoBehaviour
{
    public TMP_InputField UsernameInput;
    public TMP_InputField PasswordInput;
    public TMP_InputField PasswordInputcheck;
    public Button createuser;
    // Start is called before the first frame update
    void Start()
    {
        createuser.onClick.AddListener(() =>
        {
            if(PasswordInput.text == PasswordInputcheck.text)
            {
                StartCoroutine(UploadAndLogin());
            }
            else
            {
                Debug.Log("passwords don't match");
            }
        });
    }
    public void adduser()
    {
        if (PasswordInput.text == PasswordInputcheck.text)
        {
            StartCoroutine(UploadAndLogin());
        }
        else
        {
            Debug.Log("passwords don't match");
        }
    }
    IEnumerator UploadAndLogin()
    {
        yield return StartCoroutine(main.Instance.web.Upload(UsernameInput.text, PasswordInput.text, "none!", "https://lone-child.000webhostapp.com/createAccount.php"));
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
