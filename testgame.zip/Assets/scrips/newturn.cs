using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class newturn : MonoBehaviour
{
    private Transform Canvas;
    public static int mojo =0;
    void Start()
    {
        Canvas = GameObject.Find("Canvas-gameplay").transform;
    }
    public void startturn()
    {
        Debug.Log("check check checvk");
        load_game.deckfullinfo.Clear();
        load_game.deckfullinfo = decks.getfullinfo(load_game.deckinfo, load_game.deckorder);
        decks.drawcard();

        Transform parentTransform = GameObject.Find("units").transform;

        int mojocount = 0;
        for (int i = 0; i < parentTransform.childCount; i++)
        {
            Transform child = parentTransform.GetChild(i);
            unit_info script = child.GetComponent<unit_info>();
            if (script.controller == web.user)
            {
                if (script.Species == "Hero")
                {
                    mojocount += script.mojo;
                }
                // add mojo info for other units here
            }
            script.Defense = script.Defensemax;
        }
        Canvas.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = "Mojo: " + mojocount;
        mojo = mojocount;
    }
    public void resetplayers()
    {
        int playernum = 0;
        for (int i = 0; i < load_game.people.Count; i++)
        {
            if(load_game.people[i][0]
                == web.user)
            {
                playernum = i;
                break;
            }
        }


        for (int i = 0; i < load_game.people[playernum].Count; i++)
        {

        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
