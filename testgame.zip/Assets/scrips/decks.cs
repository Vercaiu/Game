using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class decks : MonoBehaviour
{
    // Start is called before the first frame update
    public static List<List<int>> Deck1;
    public static List<List<string>> Deck1true = new List<List<string>>();
    public static List<List<int>> Deck2;
    public static List<List<string>> Deck2true = new List<List<string>>();
    public static List<List<int>> Deck3;
    public static List<List<string>> Deck3true = new List<List<string>>();
    public static List<List<int>> currentdeck;
    public static List<List<string>> currentdecktrue;
    public static List<List<string>> graveyard = new List<List<string>>();
    public static List<string> hero;

    public static string deck;


    public IEnumerator decodeDeck(string jsonArrayString)
    {
        Debug.Log("Hello");
        List<string> first = main.Instance.web.jsonConverter(jsonArrayString);
        if (currentdeck == Deck1)
        {
            Deck1 = placeIntoDeck(0, first);
            currentdeck = Deck1;
        }
/*        if (currentdeck == Deck2)
        {
            Deck2 = placeIntoDeck(1, first);
        }
        if (currentdeck == Deck3)
        {
            Deck3 = placeIntoDeck(2, first);
        }*/
        yield return null;
    }

    public IEnumerator GetRightDeck(string jsonArrayString)
    {
        Debug.Log(jsonArrayString);
        List<string> cards = main.Instance.web.jsonConverter(jsonArrayString);
        Debug.Log(cards);
        if (Deck1true[0][0] == "placeholder")
        {
            unitToDecck20(Deck1true, cards);
        }
        else if (Deck2true[0][0] == "placeholder")
        {
            unitToDecck20(Deck2true, cards);
        }
        else if (Deck3true[0][0] == "placeholder")
        {
            unitToDecck20(Deck3true, cards);
        }
        yield return null;
    }
    private void unitToDecck20(List<List<string>> deck, List<string> cards)
    {
        int placeholder = 0;
        for (int i = 0; i < cards.Count; i++)
        {
            if( i % 10 == 0)
            {
                List<string> card = new List<string>();
                deck.Add(card);
                ++placeholder;
            }
            deck[placeholder].Add(cards[i]);
        }
        deck.RemoveAt(0);
        Shuffle(deck);
        currentdecktrue = deck;
    }

    public static List<string> organizecard(List<string> unit, int start, int statlength)
    {
        List<string> newunit = new List<string>();
        for (int i = start; i < (statlength+start); i++)
        {
            newunit.Add(unit[i]);
        }
        return newunit;
    }

    public static void drawcard()
    {if (load_game.deckorder.Count == 0)
        {
            Debug.Log("no cards left");
        }
        else
        {


            load_game.handorder.Add(load_game.deckorder[load_game.deckorder.Count - 1]);
            load_game.deckorder.RemoveAt(load_game.deckorder.Count - 1);
            card_ui card_ui = GameObject.FindObjectOfType<card_ui>();
            card_ui.organizeCard2(load_game.deckfullinfo[load_game.deckfullinfo.Count - 1]);
            load_game.deckfullinfo.RemoveAt(load_game.deckfullinfo.Count - 1);
        }
    }

    public static List<List<string>> getfullinfo(List<string> info, List<int> order)
    { int count = 0;
        List<List<string>> betterinfo = new List<List<string>>();
        List<List<string>> straightinfo = new List<List<string>>();
        for (int i = 0; i < info.Count; i+= 11)
        {
                List<string> unit = decks.organizecard(info, i, 11);
            straightinfo.Add(unit);
        }
        for (int i = 0; i < straightinfo.Count; i++)
        {
            if (int.Parse(straightinfo[i][0].ToString().Trim('"')) == order[count])
            {
                betterinfo.Add(straightinfo[i]);
                i = 0;
                ++count;
             }
        }
        return betterinfo;
    }
/*    public static void getcards(List<string> info, List<int> order)
    {
        for (int i = 0; i < info.Count; i += 11)
        {
            Debug.Log(i);
            List<string> unit = decks.organizeunits(info, i);
            for (int j = 0; j < order.Count; j++)
            {
                Debug.Log(unit[0].ToString().Trim('"'));
                Debug.Log(order[j]);
                if (int.Parse(unit[0].ToString().Trim('"')) == order[j])
                {
                    card_ui card_ui = GameObject.FindObjectOfType<card_ui>();
                    card_ui.organizeCard2(unit);
                }
            }
        }
    }*/
    public List<List<int>> placeIntoDeck(int num, List<string> first)
    {
        string input = first[num];
        string[] numberStrings = input.Split(',');
        List<List<int>> deck = new List<List<int>>();
        List<int> units = new List<int>();
        List<int> spells = new List<int>();
        List<int> weapons = new List<int>();

        foreach (string numberString in numberStrings)
        {
            if (int.Parse(numberString) < 1000)
            {
                units.Add(int.Parse(numberString));
            }
            if (int.Parse(numberString) < 2000 && int.Parse(numberString) >= 1000)
            {
                spells.Add(int.Parse(numberString));
            }
            if (int.Parse(numberString) < 3000 && int.Parse(numberString) >= 2000)
            {
                weapons.Add(int.Parse(numberString));
            }
        }
        deck.Add(units);
        deck.Add(spells);
        deck.Add(weapons);
        string middle = "";
        int decklength = 0;
        int k = 0;
        for (int i = 0; i < deck.Count; i++)
        {
            decklength += deck[i].Count;
        }
        for (int i = 0; i < deck.Count; i++)
        {
            for (int j = 0; j < deck[i].Count; j++)
            {
                ++k;
                middle += " keyed = " + deck[i][j];
                if (k <= decklength-1)
                {
                    middle += " or";
                }
            }
        }
        string start = "Select keyed, Name, Type, Species, Lore, Attack, Health, Defense, Mojo, attributes, model_type from unit_info where";
        string full = start + middle;
        //StartCoroutine(main.Instance.web.insertUnits(full));
        StartCoroutine(main.Instance.web.Upload(full, "none!","none!", "https://lone-child.000webhostapp.com/Get_units.php"));
        Debug.Log(full);
        return deck;
    }

    public static void Shuffle(List<List<string>> list)
    {
        for (int i = 0; i < list.Count; i++)
        {
            int r =  Random.Range(0, list.Count);
            List<string> holder = new List<string>();
            holder = list[i];
            list[i] = list[r];
            list[r] = holder;
        }
    }
    public static void Shuffle2(List<string> list)
    {
        for (int i = 0; i < list.Count; i++)
        { 
            int r = Random.Range(0, list.Count);
            string holder = "";
            holder = list[i];
            list[i] = list[r];
            list[r] = holder;
        }
    }


    private int randomValue; // Declare a variable to store the random number

    public int GenerateRandomNumber()
    {
        randomValue = Random.Range(0, 2);// Generate a random number and store it in the variable
        return randomValue;    
    }

    public void pickHero()
    {
        StartCoroutine(main.Instance.web.Upload(2 +"", "none!", "none!", "https://lone-child.000webhostapp.com/Get_Hero.php"));
    }
    public List<object> Place_card()
    {
        if (randomValue == 0)
        {


            List<object> card = new List<object>();
            card.Add("The Lone Child");
            card.Add(3);
            card.Add(4);
            card.Add(1);
            card.Add("hitter");
            card.Add("human");
            card.Add("none");
            card.Add(0);
            return card;
        }
        else
        {
            List<object> card = new List<object>();
            card.Add("Miriam");
            card.Add(7);
            card.Add(12);
            card.Add(8);
            card.Add("mage");
            card.Add("monki");
            card.Add("none");
            card.Add(1);
            return card;
        }
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
