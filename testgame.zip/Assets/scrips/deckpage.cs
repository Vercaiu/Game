using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class deckpage : MonoBehaviour
{
   // public Button DeckPage;
    public Button Deck1;
    public Button Deck2;
    public Button Deck3;
   // public Canvas targetCanvas; // Reference to the target Canvas
  //  public Button goback;


    public void getDeck1()
    {
        /*        List<string> test = new List<string>();
                test.Add("placeholder");
                decks.Deck1true.Add(test);
                decks.currentdeck = decks.Deck1;*/
        string deck = "Deck_1";
        StartCoroutine(main.Instance.web.Upload(web.user, deck, "none!", "https://lone-child.000webhostapp.com/getDeck.php"));
    }
    public void getDeck2()
    {
        /*        List<string> test = new List<string>();
                test.Add("placeholder");
                decks.Deck2true.Add(test);
                decks.currentdeck = decks.Deck2;*/
        string deck = "Deck_2";
        StartCoroutine(main.Instance.web.Upload(web.user, deck, "none!", "https://lone-child.000webhostapp.com/getDeck.php"));
    }
    public void getDeck3()
    {
        /*        List<string> test = new List<string>();
                test.Add("placeholder");
                decks.Deck3true.Add(test);
                decks.currentdeck = decks.Deck3;*/
        string deck = "Deck_3";
        StartCoroutine(main.Instance.web.Upload(web.user, deck, "none!", "https://lone-child.000webhostapp.com/getDeck.php"));
    }
    // Start is called before the first frame update
    void Start()
    {
/*        DeckPage.onClick.AddListener(() =>
        {
          //  StartCoroutine(main.Instance.web.Upload(web.user, "none!", "https://lone-child.000webhostapp.com/getDeck.php"));
        });*/
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
