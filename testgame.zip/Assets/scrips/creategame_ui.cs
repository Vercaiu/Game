using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class creategame_ui : MonoBehaviour
{
    public GameObject creategames;
    public static bool creategameswitch = false;
    public static bool joingameswitch = false;
    public static int gamenum;
    public int gamenumtrue;
    public static List<string> games;
    // Start is called before the first frame update


    public void getgames()
    {
        StartCoroutine(main.Instance.web.Upload("none!", "none!", "none!", "https://lone-child.000webhostapp.com/createpreviousgames.php"));
        StartCoroutine(
            
        Wait(() =>
        {
            // Assuming you have a reference to the "load_game" transform
            Transform loadGameTransform = GameObject.Find("create_game").transform;

            // Loop to destroy all child objects
            int childCount = loadGameTransform.childCount;
            for (int i = childCount - 1; i >= 0; i--)
            {
                Transform child = loadGameTransform.GetChild(i);
                Destroy(child.gameObject);
            }
            int placeholder = -1;
            List<List<string>> gamess = new List<List<string>>();
            for (int i = 0; i < games.Count; i++)
            {   if(i % 8 == 0)
                {
                    List<string> game = new List<string>();
                    gamess.Add(game);
                    ++placeholder;
                }
                gamess[placeholder].Add(games[i]);
            }
            for (int i = 0; i < gamess.Count; i++)
            {
                int players = 6;
                for (int j = 0; j < gamess[i].Count; j++)
                {
                if (gamess[i][j] == null)
                    {
                        --players;
                    }
                }
                GameObject creategamess = Instantiate(creategames, GameObject.Find("create_game").transform);
                creategamess.transform.Find("amount").GetComponent<TextMeshProUGUI>().text = players +"/" + gamess[i][6];
                creategamess.transform.Find("user").GetComponent<TextMeshProUGUI>().text = gamess[i][0];
                creategamess.GetComponent<creategame_ui>().gamenumtrue = int.Parse(gamess[i][7]);
                Debug.Log(creategamess.GetComponent<creategame_ui>().gamenumtrue);
            }
        }));
        }
    private IEnumerator Wait(Action callback)
    {
        // Perform the operations of the other method
        // ...
        yield return new WaitForSeconds(1.5f);
        // Once the operations are complete, invoke the callback
        callback?.Invoke();
        
    }

    private IEnumerator Wait2(Action callback)
    {
        // Perform the operations of the other method
        // ...
        yield return new WaitForSeconds(2f);
        // Once the operations are complete, invoke the callback
        callback?.Invoke();

    }

    public void creategamescreen()
    {
        StartCoroutine(
                
                Wait(() =>
        {


            Debug.Log("Second");
            Debug.Log(creategameswitch);
            Debug.Log(creategame.hero);
            if (creategameswitch)
            {


                string[] stringArray = creategame.hero.Split('|');
                GameObject creategamess = Instantiate(creategames, GameObject.Find("create_game").transform);
                Debug.Log(gamenum);
                creategames.GetComponent<creategame_ui>().gamenumtrue = (gamenum + 1);
                creategamess.transform.Find("amount").GetComponent<TextMeshProUGUI>().text = "1/" + stringArray[1];
                creategamess.transform.Find("user").GetComponent<TextMeshProUGUI>().text = web.user;
            }
            creategameswitch = false;
        }));
    }
   public void creategamescreen2()
    {
/*        string goin = "";
        int count1 = 0;
        int count2 = 0;
        for (int i = 0; i < decks.currentdecktrue.Count; i++)
        {
            ++count1;
            for (int j = 0; j < decks.currentdecktrue[i].Count; j++)
            {
                ++count2;
                goin += decks.currentdecktrue[i][j];
                if (count1 != decks.currentdecktrue.Count
                    || count2 != decks.currentdecktrue[i].Count)
                {
                    goin += ",";
                }
            }
            count2 = 0;
        }*/
        Debug.Log("yo");

        //string insert = creategame.insertdeck();

        string[] values = this.transform.Find("amount").GetComponent<TextMeshProUGUI>().text.Split('/');
        string hero = "";
        for (int i = 0; i < decks.hero.Count; i++)
        {
            hero += decks.hero[i];
            if (i < 10)
            {
                hero += ",";
            }
            else
            {
                break;
            }
        }
        creategame.hero = hero + "|" + values[0] + "| " + GetComponent<creategame_ui>().gamenumtrue;
        Debug.Log(values[0]);
        StartCoroutine(main.Instance.web.Upload(web.user, decks.deck, creategame.hero, "https://lone-child.000webhostapp.com/addtopreviousgame.php"));

        Debug.Log(this.transform.Find("amount").GetComponent<TextMeshProUGUI>().text);

        StartCoroutine(

        Wait(() =>
        {
            if (joingameswitch)
            {


                Debug.Log(GetComponent<creategame_ui>().gamenumtrue);
                this.transform.Find("amount").GetComponent<TextMeshProUGUI>().text = int.Parse(values[0]) + 1 + "/" + values[1];
                // string gamecode = GetComponent<creategame_ui>().gamenumtrue + "";
                // Maps.player_count = int.Parse(values[1]);
                // StartCoroutine(main.Instance.web.Upload(gamecode, "none!", "none!", "https://lone-child.000webhostapp.com/createdgameinfo.php"));
                Debug.Log(int.Parse(values[0]) + 1);
                Debug.Log(int.Parse(values[1]));
                if ((int.Parse(values[0]) + 1) == int.Parse(values[1]))
                {
                    Debug.Log("check");
                    string gamecode = GetComponent<creategame_ui>().gamenumtrue + "";
                    Maps.player_count = int.Parse(values[1]);
                    StartCoroutine(main.Instance.web.Upload(gamecode, "none!", "none!", "https://lone-child.000webhostapp.com/createdgameinfo.php"));
                }
            }
            }));
        StartCoroutine(

                    Wait2(() =>
                    {
                        if (joingameswitch)
                        {


                            if ((int.Parse(values[0]) + 1) == int.Parse(values[1]))
                            {


                                Debug.Log("check");
                                StartCoroutine(main.Instance.web.Upload(SaveGame.starter, "none!", "none!", "https://lone-child.000webhostapp.com/createtruegame.php"));
                                Canvascontroller canvascontroller = GameObject.FindObjectOfType<Canvascontroller>();
                                canvascontroller.gotoGame();
                            }
                        }
                    }));
                
            joingameswitch = false;
        
            
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
