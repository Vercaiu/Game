using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SaveGame : MonoBehaviour
{
    public static string starter;
    public static int gamenum;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public static string gettiles()
    {
        Transform parentTransform = GameObject.Find("tiles").transform;
        Debug.Log(parentTransform.childCount);
        string start = "";
        for (int i = 0; i < parentTransform.childCount; i++)
        {
            Transform child = parentTransform.GetChild(i);
            int tile = child.gameObject.GetComponent<clickingobject>().tiledigit;
            RaycastHit hit;
            start += "'" + tile;
            if (Physics.Raycast(child.position, Vector3.up, out hit)
                && hit.collider.gameObject.transform.parent.name == "units")
            {
                start += "," + hit.collider.gameObject.GetComponent<unit_info>().key + ",";
                start +=hit.collider.gameObject.GetComponent<unit_info>().Name + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().Type + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().Species + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().lore + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().Attack + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().Health + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().Defense + ","; //check unit_info order
                hit.collider.gameObject.GetComponent<unit_info>().Defensemax =
                hit.collider.gameObject.GetComponent<unit_info>().Defense ;
                start += hit.collider.gameObject.GetComponent<unit_info>().Defensemax + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().mojo + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().attributes + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().modelnumber + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().controller + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().affliction + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().Affect + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().weapon + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().armor + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().shield + ",";
                start += hit.collider.gameObject.GetComponent<unit_info>().helmet;
            }
            start += "'";

            start += ",";

        }
        return start;
    }




    public static IEnumerator savinggamefirst(string jsonArrayString)
    {
        List<string> savedgamedata = main.Instance.web.jsonConverter(jsonArrayString);
        Maps maps = GameObject.FindObjectOfType<Maps>();  // Get an instance of the Maps class or MapMaker object
        if (maps != null)
        {
            maps.mapMaker(savedgamedata);  // Call the createMap method on the Maps class or MapMaker object
        }
        string start = "insert into `games2` values (null," + gettiles();
        List<List<string>> hands = new List<List<string>>();
        string playerturn = "";
        int nullcount = 0;
        int count = 0;
        savedgamedata.RemoveAt(savedgamedata.Count - 1);
        while (count < savedgamedata.Count)
        {
            
            if (savedgamedata[count] == null)
            {
                savedgamedata.RemoveAt(count);
                ++nullcount;
                count = -1;
            }
            ++count;
        }
        for (int i = 0; i < savedgamedata.Count; i+= 3)
        {
            Debug.Log(savedgamedata.Count);
            Debug.Log(i);
            string user = savedgamedata[i];
            playerturn = user;
            string cards = "'";
            string deckstr = "";
            List<string> hand = new List<string>();
            string[] numberStrings = savedgamedata[i+1].Split(',');
            List<string> deck = new List<string>(numberStrings);
            decks.Shuffle2(deck);
            int starthandsize = 2;
            for (int j = 0; j < starthandsize; j++)
            {
                cards += deck[0];
                if(starthandsize-1 > j)
                {
                    cards += ",";
                }
                hand.Add(deck[0]);
                deck.RemoveAt(0);
            }
            cards += "', ";
            hands.Add(hand);
            deckstr += "'";
            for (int k = 0; k < deck.Count; ++k)
            {
                deckstr += deck[k];
                if(deck.Count-1 > k)
                {
                    deckstr += ",";
                }
            }
            deckstr += "' ,";
            start +=  "'"+user +"'," +deckstr +"'0', " + cards;
        }
        for (int i = 0; i < nullcount; i++)
        {
            start += "null, ";
            if(i % 3 == 0)
            {
                start += "null, ";
            }
        }
        start += "'"+playerturn + "'"+ ")";
        Debug.Log(start);
        starter = start;
        yield return null;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}


