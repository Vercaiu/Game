using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class convertor : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public static string listtophp(List<int> incoming)
    {
        string list = "";
        for (int g = 0; g < incoming.Count; g++)
        {
            list += incoming[g];
            if(g < incoming.Count - 1)
            {
                list += ",";
            }
        }
        return list;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
