using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Maps : MonoBehaviour
{   public static int[] Map1 = new int[] {0
    ,1,0,1,0,0,0
    ,0,1,0,0,1,1,1,1,0,1,1,0
    ,0,1,1,0,0,0,0,0,1,1,1,1,0,0,1,0,1,0
    ,0,1,1,1,1,1,1,1,1,1,0,0,0,0,1,0,0,1,0,0,0,0,0,0
    ,0,0,0,0,0,0,0,0,0,1,0,1,1,1,1,1,0,0,0,0,0,0,1,1,1,0,0,0,0,1
    ,0,1,0,1,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0
    ,5,19,25,64,93,53,55}; //test
    // Start is called before the first frame update
    public static int[] Map2 = new int[] {0
    ,0,0,0,0,0,0
    ,1,0,0,0,1,0,0,0,1,0,0,0
    ,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1
    ,1,1,1,0,0,1,1,0,1,1,1,0,0,1,1,0,1,1,1,0,0,1,1,0
    ,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    ,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0
    ,126, 114, 102, 1000,1000,1000,1000}; //3players

    public static int[] Map3 = new int[] {1
    ,0,1,0,1,0,1
    ,0,0,0,0,0,0,0,0,0,0,0,0
    ,0,1,1,0,1,0,0,1,1,0,1,0,0,1,1,0,1,0
    ,1,1,0,1,0,0,0,0,1,1,0,1,0,0,0,0,1,1,0,1,0,0,0,0
    ,0,0,0,0,0,0,1,1,1,0,0,1,0,0,0,0,0,0,0,0,0,1,1,1,0,0,1,0,0,0
    ,0,0,0,1,1,1,0,0,0,1,1,1,0,0,0,1,1,1,0,0,0,1,1,1,0,0,0,1,1,1,0,0,0,1,1,1
    ,123,105,1000,1000,1000,1000
    }; //2players

    public GameObject[] tilesarray;
    public GameObject[] unitsarray;
    public double currentx = 0;
    public double currentz = 0;
    private int count = 0;
    public static int player_count = 6;
    private int current_count = 0;
    private List<string> savedgamedata;
    // Start is called before the first frame update
    public int value;
    public override string ToString()
    {
        return "MyClass - value: " + value.ToString();
    }

    public void mapMaker(List<string> data)
    {
        savedgamedata = data;
        player_count = int.Parse(data[data.Count - 1]);
        count = 0;
        int[] valuesArray = new int[Map2.Length];
        if (player_count == 2)
        {

            List<int[]> p2 = new List<int[]>();
            p2.Add(Map3);
            int p = UnityEngine.Random.Range(0, 1);
            Array.Copy(Map3, valuesArray, Map3.Length);

        }
        else if (player_count == 3)
        {
            List<int[]> p2 = new List<int[]>();
            p2.Add(Map2);
            int p = UnityEngine.Random.Range(0, 1);
            Array.Copy(Map2, valuesArray, Map2.Length);
        }
        else
        {
            List<int[]> p2 = new List<int[]>();
            p2.Add(Map1);
            int p = UnityEngine.Random.Range(0, 1);
            Array.Copy(Map1, valuesArray, Map1.Length);
        }
        GameObject tiled = Instantiate(tilesarray[valuesArray[count]], new Vector3((float).85, 0, (float)-1.5), tilesarray[valuesArray[count]].transform.rotation, GameObject.Find("tiles").transform);
        MyCamera.centerOfMap = tiled.transform;
        place_unit(count, valuesArray);
        tiled.GetComponent<clickingobject>().tiledigit = valuesArray[count];
        ++count;
        for (int i = 0; i < 7; i++)
        {
            for (int j = 0; j < i; j++)
            {
                // Debug.Log(count);
                currentz += -1.5;
                currentx += -.85;
                place_unit(count, valuesArray);
                GameObject tile = Instantiate(tilesarray[valuesArray[count]], new Vector3((float)currentx, 0, (float)currentz), tilesarray[valuesArray[count]].transform.rotation, GameObject.Find("tiles").transform);
                tile.GetComponent<clickingobject>().tiledigit = valuesArray[count];
                ++count;
            }
            for (int k = 0; k < i; k++)
            {
                //  Debug.Log(count);
                currentz += 0;
                currentx += -1.7;
                place_unit(count, valuesArray);
                GameObject tile = Instantiate(tilesarray[valuesArray[count]], new Vector3((float)currentx, 0, (float)currentz), tilesarray[valuesArray[count]].transform.rotation, GameObject.Find("tiles").transform);
                tile.GetComponent<clickingobject>().tiledigit = valuesArray[count];
                ++count;
            }
            for (int k = 0; k < i; ++k)
            {
                //  Debug.Log(count);
                currentz += 1.5;
                currentx += -.85;
                place_unit(count, valuesArray);
                GameObject tile = Instantiate(tilesarray[valuesArray[count]], new Vector3((float)currentx, 0, (float)currentz), tilesarray[valuesArray[count]].transform.rotation, GameObject.Find("tiles").transform);
                tile.GetComponent<clickingobject>().tiledigit = valuesArray[count];
                ++count;
            }
            for (int k = 0; k < i; ++k)
            {
                currentz += 1.5;
                currentx += .85;
                place_unit(count, valuesArray);
                GameObject tile = Instantiate(tilesarray[valuesArray[count]], new Vector3((float)currentx, 0, (float)currentz), tilesarray[valuesArray[count]].transform.rotation, GameObject.Find("tiles").transform);
                tile.GetComponent<clickingobject>().tiledigit = valuesArray[count];
                ++count;
            }
            for (int k = 0; k < i; ++k)
            {
                // Debug.Log(count);
                currentz += 0;
                currentx += 1.7;
                place_unit(count, valuesArray);
                GameObject tile = Instantiate(tilesarray[valuesArray[count]], new Vector3((float)currentx, 0, (float)currentz), tilesarray[valuesArray[count]].transform.rotation, GameObject.Find("tiles").transform);
                tile.GetComponent<clickingobject>().tiledigit = valuesArray[count];
                ++count;
            }
            for (int k = 0; k < (i - 1); ++k)
            {
                // Debug.Log(count);
                currentz += -1.5;
                currentx += .85;
                place_unit(count, valuesArray);
                GameObject tile = Instantiate(tilesarray[valuesArray[count]], new Vector3((float)currentx, 0, (float)currentz), tilesarray[valuesArray[count]].transform.rotation, GameObject.Find("tiles").transform);
                tile.GetComponent<clickingobject>().tiledigit = valuesArray[count];
                ++count;
            }
            for (int k = 0; k < 1; ++k)
            {
                if (count <= 95)
                {
                    currentz += -1.5;
                    currentx += .85;
                    currentx += 1.7;
                    place_unit(count, valuesArray);
                    GameObject tile = Instantiate(tilesarray[valuesArray[count]], new Vector3((float)currentx, 0, (float)currentz), tilesarray[valuesArray[count]].transform.rotation, GameObject.Find("tiles").transform);
                    tile.GetComponent<clickingobject>().tiledigit = valuesArray[count];
                    ++count;
                }
                else
                {
                    break;
                }
            }
        }
        MyCamera mycamera = GameObject.FindObjectOfType<MyCamera>();
        mycamera.cameraposition();
    }
    private void place_unit(int count, int[] valuesArray)
    {
        if ((count == valuesArray[valuesArray.Length - 7] ||
            count == valuesArray[valuesArray.Length - 6] || count == valuesArray[valuesArray.Length - 5] ||
            count == valuesArray[valuesArray.Length - 4] || count == valuesArray[valuesArray.Length - 3] ||
            count == valuesArray[valuesArray.Length - 2] || count == valuesArray[valuesArray.Length - 1])
            && current_count < player_count)
        {
            string[] value = savedgamedata[(current_count * 3) + 2].Split(',');
            List<object> hero = new List<object>();
            for (int i = 0; i < value.Length; i++)
            {
                hero.Add(value[i]);
            }
            hero.Add(savedgamedata[(current_count * 3)]);
            Debug.Log(hero.Count);
            string myString = hero[7].ToString(); //defense

            // Insert the string at index 2
            hero.Insert(8, myString);
            for (int i = 0; i < hero.Count; i++)
            {
                Debug.Log(hero[i]);
            }
            Instantiate(unitsarray[int.Parse(hero[hero.Count -2].ToString())], new Vector3((float)currentx, (float).52, ((float)currentz)), tilesarray[valuesArray[count]].transform.rotation, GameObject.Find("units").transform);
            GameObject instantiatedObject = GameObject.Find("units").transform.GetChild(current_count).gameObject;
            ++current_count;
            main.Instance.unit_Info.Create_unit(hero, instantiatedObject);
            if (instantiatedObject.GetComponent<unit_info>().Type == "hitter")
            {
                instantiatedObject.GetComponent<unit_info>().extraMove = true;
            }
            stats_ui.setui(instantiatedObject);
            /*            List<GameObject> controller = new List<GameObject>();
                        controller.Add(instantiatedObject);

                        // Create a new instance of the controller list before adding it to people list
                        List<GameObject> newController = new List<GameObject>(controller);
                        load_game.people.Add(newController);
                        Debug.Log(load_game.people.Count);
                        if (load_game.people.Count > 1)
                        {
                            load_game.player_turn = load_game.people[0];
                        }*/
        }
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
