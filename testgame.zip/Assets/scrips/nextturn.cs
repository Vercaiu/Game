using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class nextturn : MonoBehaviour
{
    private IEnumerator Waitsmall(Action callback)
    {
        // Perform the operations of the other method
        // ...
        yield return new WaitForSeconds(1f);
        // Once the operations are complete, invoke the callback
        callback?.Invoke();

    }
    public void nextturnbutton()
    {
        Transform parentTransform = GameObject.Find("discarded").transform;
        if (web.user == load_game.turn)
        {
            if (parentTransform.childCount < 2)
            {
                Debug.Log("must discard at least 2 cards");
            }
            else
            {
                Canvascontroller Canvascontroller = GameObject.FindObjectOfType<Canvascontroller>();
                Canvascontroller.gotomakegame();
                updatesavegame updatesavegame = GameObject.FindObjectOfType<updatesavegame>();
                updatesavegame.savinggame();
                load_game load_game = GameObject.FindObjectOfType<load_game>();
                load_game.loadedgames();
                creategame_ui creategame_ui = GameObject.FindObjectOfType<creategame_ui>();
                creategame_ui.getgames();
            }
        }
        else
        {
            StartCoroutine(

Waitsmall(() =>
{
    Canvascontroller Canvascontroller = GameObject.FindObjectOfType<Canvascontroller>();
    Canvascontroller.gotomakegame();
}));
            load_game load_game = GameObject.FindObjectOfType<load_game>();
            load_game.loadedgames();
            creategame_ui creategame_ui = GameObject.FindObjectOfType<creategame_ui>();
            creategame_ui.getgames();
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
