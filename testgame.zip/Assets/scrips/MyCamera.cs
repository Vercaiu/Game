using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyCamera : MonoBehaviour
{
    private float moveSpeed = 15.0f;
    private Vector3 moveVector;
    public float cameraDistance = 300f;
    public float minFOV = 100f;   // Minimum field of view (zoomed out)
    public float maxFOV = 1000f;   // Maximum field of view (zoomed in)
    public float zoomSpeed = 5f; // Speed of zooming
    void Start()
    {
        moveVector = new Vector3(0, 0, 0);
    }

    void Update()
    {
        // Get the raw input values for horizontal and vertical axes
        float horizontalInput = Input.GetAxisRaw("Horizontal");
        float verticalInput = Input.GetAxisRaw("Vertical");

        // Calculate the movement direction based on the MyCamera's orientation
        Vector3 movementDirection = CalculateMovementDirection(horizontalInput, verticalInput);

        // Move the MyCamera based on the adjusted input values and movement direction
        if (movementDirection != Vector3.zero)
        {
            transform.position += moveSpeed * movementDirection * Time.deltaTime;
        }

        // Get the scroll wheel input
        float scrollInput = Input.GetAxis("Mouse ScrollWheel");

        // Calculate the new field of view
        float newFOV = Camera.main.fieldOfView - scrollInput * zoomSpeed;

        // Clamp the new field of view within the allowed range
        newFOV = Mathf.Clamp(newFOV, minFOV, maxFOV);

        // Set the camera's field of view to the new value
        Camera.main.fieldOfView = newFOV;
    }

    Vector3 CalculateMovementDirection(float horizontalInput, float verticalInput)
    {
        // Get the MyCamera's forward and right vectors
        Vector3 cameraForward = transform.forward;
        Vector3 cameraRight = transform.right;

        // Project the MyCamera vectors onto the horizontal plane (ignore the vertical component)
        cameraForward.y = 0f;
        cameraRight.y = 0f;
        cameraForward.Normalize();
        cameraRight.Normalize();

        // Calculate the movement direction based on the MyCamera's orientation
        Vector3 movementDirection = (cameraForward * verticalInput + cameraRight * horizontalInput).normalized;

        return movementDirection;
    }

    public  static Transform player; // Reference to the GameObject the MyCamera should follow
    public  static Transform centerOfMap; // Reference to the center of the map GameObject

    public void cameraposition()
    {
        if (player == null || centerOfMap == null)
        {
            Debug.LogError("CameraController: Player or center of map references not set!");
            return;
        }

        // Calculate the midpoint between the player and the center of the map
        Vector3 midpoint = (player.position + centerOfMap.position) / 2f;

        // Calculate the desired position for the MyCamera
        Vector3 cameraPosition = midpoint - player.forward;

        // Set the desired height of the camera
        float desiredHeight = 25f;
        cameraPosition.y = desiredHeight;

        // Set the MyCamera's position to the calculated position
        transform.position = cameraPosition;

        // Calculate the direction from the MyCamera to the center of the map
        Vector3 cameraToCenterDir = (centerOfMap.position - transform.position).normalized;

        // Calculate the direction from the MyCamera to the player
        Vector3 cameraToPlayerDir = (player.position - transform.position).normalized;

        // Calculate the direction that is midway between the center and the player
        Vector3 targetDirection = (cameraToCenterDir + cameraToPlayerDir).normalized;

        // Calculate the rotation based on the target direction and apply the 45-degree x-axis rotation
        Quaternion targetRotation = Quaternion.LookRotation(targetDirection) * Quaternion.Euler(45f, 0f, 180f);

        // Set the MyCamera's rotation to the calculated rotation
        transform.rotation = targetRotation;
    }
    /*
        public void Flip()
        {
            // Get the current MyCamera rotation
            Quaternion currentRotation = transform.rotation;

            // Calculate the flipped rotation by adding 180 degrees to the Y-axis rotation
            Quaternion flippedRotation = Quaternion.Euler(currentRotation.eulerAngles.x, currentRotation.eulerAngles.y
                + 360f/loadmap.player_count, currentRotation.eulerAngles.z);
            // Apply the flipped rotation to the MyCamera
            transform.rotation = flippedRotation;
            Debug.Log(load_game.turn_num);
            if (load_game.turn_num >= loadmap.player_count - 1)
            {
                load_game.turn_num = -1;
            }
            //load_game.player_turn = load_game.people[++load_game.turn_num];
    *//*        for (int i = 0; i < load_game.people.Count; i++)
            {
                unit_info reset = load_game.player_turn[i].GetComponent<unit_info>();
                reset.canMove = true;
                reset.canAttack = true;
                if(reset.Type == "hitter")
                {
                    reset.extraMove = true;
                }
                load_game.player_turn[i].gameObject.GetComponent<Renderer>().material.color = Color.black;
            }*/
}
