using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

public class card_ui : MonoBehaviour
{
    public GameObject cards;
    public GameObject armorcards;
    private GameObject currentcard;
    public static Collider[] colliders;
    public static Collider[] placingunitcolliders;
    public static float tileradius = 1.5f;
    public bool discarded = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void organizeCard2(List<string> unit)
    {
        GameObject card = Instantiate(cards, GameObject.Find("cards").transform);
        card.GetComponent<unit_info>().key = int.Parse(unit[0].ToString().Trim('"'));
        Debug.Log(unit[1].ToString().Trim('"'));
        card.GetComponent<unit_info>().Name = unit[1].ToString().Trim('"');
        card.GetComponent<unit_info>().Type = unit[2].ToString().Trim('"');
        card.GetComponent<unit_info>().Species = unit[3].ToString().Trim('"');
        card.GetComponent<unit_info>().lore = int.Parse(unit[4].ToString().Trim('"'));
        card.GetComponent<unit_info>().Attack = int.Parse(unit[5].ToString().Trim('"'));
        card.GetComponent<unit_info>().Health = int.Parse(unit[6].ToString().Trim('"'));
        card.GetComponent<unit_info>().Defense = int.Parse(unit[7].ToString().Trim('"'));
        card.GetComponent<unit_info>().mojo = int.Parse(unit[8].ToString().Trim('"'));
        card.GetComponent<unit_info>().attributes = unit[9].ToString().Trim('"');
        card.GetComponent<unit_info>().modelnumber = int.Parse(unit[10].ToString().Trim('"'));


        card.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = card.GetComponent<unit_info>().mojo.ToString(); //mojo
        card.transform.Find("attack").GetComponent<TextMeshProUGUI>().text = card.GetComponent<unit_info>().Attack.ToString(); //attack
        card.transform.Find("health").GetComponent<TextMeshProUGUI>().text = card.GetComponent<unit_info>().Health.ToString(); //health
        card.transform.Find("defense").GetComponent<TextMeshProUGUI>().text = card.GetComponent<unit_info>().Defense.ToString(); //defense
    }

    public void organizeArmor(List<string> weapon)
    {
        GameObject armorcard = Instantiate(armorcards, GameObject.Find("cards").transform);
        string strweapon = "";
        for (int i = 0; i < weapon.Count; i++)
        {
            strweapon += weapon[i].ToString().Trim('"');
            if(weapon.Count-1 > i)
            {
                strweapon += "$";
            }
        }
        armorcard.GetComponent<unit_info>().weapon = strweapon;

        armorcard.transform.Find("attack").GetComponent<TextMeshProUGUI>().text = weapon[5].ToString().Trim('"'); //mojo
        armorcard.transform.Find("health").GetComponent<TextMeshProUGUI>().text = weapon[6].ToString().Trim('"'); //attack
        armorcard.transform.Find("defense").GetComponent<TextMeshProUGUI>().text = weapon[7].ToString().Trim('"'); //health
        armorcard.transform.Find("addedmojo").GetComponent<TextMeshProUGUI>().text = weapon[8].ToString().Trim('"'); 
        armorcard.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = weapon[9].ToString().Trim('"');//defense
    }

/*    public void organizeCard()
    {
       GameObject card = Instantiate(cards, this.transform);
        Debug.Log(decks.currentdecktrue.Count);
        Debug.Log(decks.currentdecktrue[0].Count);

        card.GetComponent<unit_info>().Name = decks.currentdecktrue[0][0];
        card.GetComponent<unit_info>().Type = decks.currentdecktrue[0][1];
        card.GetComponent<unit_info>().Species = decks.currentdecktrue[0][2];
        card.GetComponent<unit_info>().lore = int.Parse(decks.currentdecktrue[0][3]);
        card.GetComponent<unit_info>().Attack = int.Parse(decks.currentdecktrue[0][4]);
        card.GetComponent<unit_info>().Health = int.Parse(decks.currentdecktrue[0][5]);
        card.GetComponent<unit_info>().Defense = int.Parse(decks.currentdecktrue[0][6]);
        card.GetComponent<unit_info>().mojo = int.Parse(decks.currentdecktrue[0][7]);
        card.GetComponent<unit_info>().attributes = decks.currentdecktrue[0][8];
        card.GetComponent<unit_info>().modelnumber = int.Parse(decks.currentdecktrue[0][9]);


        card.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = decks.currentdecktrue[0][7]; //mojo
        card.transform.Find("attack").GetComponent<TextMeshProUGUI>().text = decks.currentdecktrue[0][4]; //attack
        card.transform.Find("health").GetComponent<TextMeshProUGUI>().text = decks.currentdecktrue[0][5]; //health
        card.transform.Find("defense").GetComponent<TextMeshProUGUI>().text = decks.currentdecktrue[0][6]; //defense

        decks.graveyard.Add(decks.currentdecktrue[0]);
        decks.currentdecktrue.RemoveAt(0);
    }*/

    public void grabCard()
    {
        Debug.Log(GetComponent<unit_info>().Health);
    }

    public void mouseDown()
    {
        Debug.Log(GetComponent<unit_info>().Attack);
        currentcard = gameObject;
        if (web.user == load_game.turn)
        {
                Transform Canvas = GameObject.Find("Canvas-gameplay").transform;
                newturn.mojo -= currentcard.GetComponent<unit_info>().mojo;
                Canvas.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = "Mojo: " + newturn.mojo;
            if (currentcard.CompareTag("armorcard"))
            {
                Transform parentTransform = GameObject.Find("units").transform;
                for (int i = 0; i < parentTransform.childCount; i++)
                {
                    string[] stringArray = currentcard.GetComponent<unit_info>().weapon.Split('$');
                    Transform child = parentTransform.GetChild(i);
                    if (child.GetComponent<unit_info>().controller == web.user)
                    {
                        clickingobject script = child.gameObject.GetComponent<clickingobject>();
                        if (stringArray[3] == child.GetComponent<unit_info>().Type)
                        {
                            script.armorable = true;
                            Renderer renderer1 = child.gameObject.GetComponent<Renderer>();

                            renderer1.material.color = Color.green;
                        }
                    }
                }
            }
            else if (currentcard.CompareTag("unitcard"))
            {

                Transform parentTransform = GameObject.Find("units").transform;
                for (int i = 0; i < parentTransform.childCount; i++)
                {
                    Transform child = parentTransform.GetChild(i);
                    if (child.GetComponent<unit_info>().Species == "Hero"
                        && child.GetComponent<unit_info>().controller == web.user)
                    {
                        placingunitcolliders = Physics.OverlapSphere(child.position, tileradius); // 5f is the radius
                        foreach (Collider collider in placingunitcolliders)
                        {
                            clickingobject script = collider.gameObject.GetComponent<clickingobject>();
                            if (collider.gameObject.CompareTag("TileT")
                                && script.unitontile == false)
                            {
                                Renderer renderer1 = collider.gameObject.GetComponent<Renderer>();
                                script.placeunittile = true;

                                renderer1.material.color = Color.clear;
                            }
                        }
                    }
                }
            }
            if (currentcard.GetComponent<unit_info>().mojo <= newturn.mojo)
            {

            }
        }
    }

    public void endDrag()
    {
        // Check if the pointer is over a UI element
        if (EventSystem.current.IsPointerOverGameObject())
        {
            // Pointer is over a UI element (e.g., image in Canvas)
            Debug.Log("Drag ended on a UI element, ignoring further processing.");
            Transform Canvas = GameObject.Find("Canvas-gameplay").transform;
            newturn.mojo += currentcard.GetComponent<unit_info>().mojo;
            Canvas.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = "Mojo: " + newturn.mojo;
            return;
        }
        RaycastHit hit;
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        
        if (web.user == load_game.turn)
        {
            if (newturn.mojo >= 0)
            {


                if (Physics.Raycast(ray, out hit))
                {

                    GameObject tilehit = hit.collider.gameObject;
                    if (tilehit.GetComponent<clickingobject>().placeunittile)
                    {

                        tilehit.GetComponent<clickingobject>().unitontile = true;
                        Vector3 center = tilehit.transform.position;
                        center.y += 0.55f; // move up by 0.5 units
                        GameObject instantiatedObject = Instantiate(main.Instance.createmap.GetComponent<createmap>().unitsarray[currentcard.GetComponent<unit_info>().modelnumber], center, tilehit.transform.rotation, GameObject.Find("units").transform);
                        unit_info draggedCardUnitInfo = currentcard.GetComponent<unit_info>();
                        unit_info instantiatedObjectUnitInfo = instantiatedObject.GetComponent<unit_info>();
                        instantiatedObjectUnitInfo.key = draggedCardUnitInfo.key;
                        instantiatedObjectUnitInfo.mojo = draggedCardUnitInfo.mojo;
                        instantiatedObjectUnitInfo.Health = draggedCardUnitInfo.Health;
                        instantiatedObjectUnitInfo.Attack = draggedCardUnitInfo.Attack;
                        instantiatedObjectUnitInfo.attributes = draggedCardUnitInfo.attributes;
                        instantiatedObjectUnitInfo.Type = draggedCardUnitInfo.Type;
                        instantiatedObjectUnitInfo.Species = draggedCardUnitInfo.Species;
                        instantiatedObjectUnitInfo.Defense = draggedCardUnitInfo.Defense;
                        instantiatedObjectUnitInfo.Defense = draggedCardUnitInfo.Defensemax;
                        instantiatedObjectUnitInfo.Name = draggedCardUnitInfo.Name;
                        instantiatedObjectUnitInfo.modelnumber = draggedCardUnitInfo.modelnumber;
                        instantiatedObjectUnitInfo.controller = web.user;
                        stats_ui.setui(instantiatedObject);
                        for (int i = 0; i < load_game.handorder.Count; i++)
                        {
                            if (load_game.handorder[i] == draggedCardUnitInfo.key)
                            {
                                load_game.handorder.RemoveAt(i);
                            }
                        }
                        deleteCard(instantiatedObjectUnitInfo.Name);
                        Debug.Log("what is happening");

                    }
                    else
                    {
                        Transform Canvas = GameObject.Find("Canvas-gameplay").transform;
                        newturn.mojo += currentcard.GetComponent<unit_info>().mojo;
                        Canvas.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = "Mojo: " + newturn.mojo;
                    }
                }
                else
                {
                    Transform Canvas = GameObject.Find("Canvas-gameplay").transform;
                    newturn.mojo += currentcard.GetComponent<unit_info>().mojo;
                    Canvas.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = "Mojo: " + newturn.mojo;
                }
                foreach (Collider collider in placingunitcolliders)
                {
                    clickingobject script = collider.gameObject.GetComponent<clickingobject>();
                    script.placeunittile = false;
                    Renderer renderer1 = collider.gameObject.GetComponent<Renderer>();

                    renderer1.material.color = Color.white;
                }
            }
            else
            {
                Transform Canvas = GameObject.Find("Canvas-gameplay").transform;
                newturn.mojo += currentcard.GetComponent<unit_info>().mojo;
                Canvas.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = "Mojo: " + newturn.mojo;
            }
        }
    }
    // Update is called once per frame

    public void deleteCard(string Name)
    {
        Transform parentTransform = GameObject.Find("cards").transform;

        for (int i = 0; i < parentTransform.childCount; i++)
        {
            Transform child = parentTransform.GetChild(i);

            // Check if the child has a specific attribute/component
            unit_info someComponent = child.GetComponent<unit_info>();

            if (someComponent.Name == Name)
            {
                // Destroy the child object
                Destroy(child.gameObject);
            }
        }
    }
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            // Get the unit_info component attached to the image object
            

            // Check if the unit_info component exists
        }
        if (Input.GetMouseButtonUp(0))
        {

        }
    }
}
