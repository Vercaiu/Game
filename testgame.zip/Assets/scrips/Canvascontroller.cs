using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Canvascontroller : MonoBehaviour
{
    public Canvas Main;
    public Canvas gameplay;
    public Button Gameplaybutton;
    public Button Mainbutton;
    public Canvas decks;
    public Button Decksbutton;
    private static Canvas current;
    public Canvas createuser;
    public Canvas makegame;
    // Start is called before the first frame update

    public void gotoMain()
    {
        DisableAllElements(gameplay);
        DisableAllElements(decks);
        DisableAllElements(createuser);
        DisableAllElements(makegame);
        EnableAllElements(Main);
    }
    public void gotoDecks()
    {
        DisableAllElements(gameplay);
        DisableAllElements(Main);
        DisableAllElements(createuser);
        DisableAllElements(makegame);
        EnableAllElements(decks);
    }
    public void gotoGame()
    {
        DisableAllElements(Main);
        DisableAllElements(decks);
        DisableAllElements(createuser);
        DisableAllElements(makegame);
        EnableAllElements(gameplay);
    }
    public void gotocreateuser()
    {
        DisableAllElements(gameplay);
        DisableAllElements(decks);
        DisableAllElements(Main);
        DisableAllElements(makegame);
        EnableAllElements(createuser);
    }
    public void gotomakegame()
    {
        DisableAllElements(gameplay);
        DisableAllElements(decks);
        DisableAllElements(Main);
        DisableAllElements(createuser);
        EnableAllElements(makegame);
    }


    public void DisableAllElements(Canvas targetCanvas)
    {
        // Get all child GameObjects of the canvas
        GameObject[] childObjects = new GameObject[targetCanvas.transform.childCount];
        for (int i = 0; i < targetCanvas.transform.childCount; i++)
        {
            childObjects[i] = targetCanvas.transform.GetChild(i).gameObject;
        }

        // Disable components on all child GameObjects
        foreach (GameObject childObject in childObjects)
        {
            // Disable the GameObject's components as needed
            if (childObject.TryGetComponent(out Graphic graphic))
            {
                graphic.enabled = false;
            }
            if (childObject.TryGetComponent(out Button button))
            {
                button.enabled = false;
            }
            if (childObject.TryGetComponent(out Image image))
            {
                image.enabled = false;
            }
            // Add more components to disable if needed (e.g., Image, Text, etc.)
        }
        targetCanvas.enabled = false;
    }

    public void EnableAllElements(Canvas targetCanvas)
    {
        // Get all child GameObjects of the canvas
        GameObject[] childObjects = new GameObject[targetCanvas.transform.childCount];
        for (int i = 0; i < targetCanvas.transform.childCount; i++)
        {
            childObjects[i] = targetCanvas.transform.GetChild(i).gameObject;
        }

        // Enable components on all child GameObjects
        foreach (GameObject childObject in childObjects)
        {
            // Enable the GameObject's components as needed
            if (childObject.TryGetComponent(out Graphic graphic))
            {
                graphic.enabled = true;
            }
            if (childObject.TryGetComponent(out Button button))
            {
                button.enabled = true;
            }
            if (childObject.TryGetComponent(out Image image))
            {
                image.enabled = true;
            }
            // Add more components to enable if needed (e.g., Image, Text, etc.)
        }
        targetCanvas.enabled = true;
    }
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
