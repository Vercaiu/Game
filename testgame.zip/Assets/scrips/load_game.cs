using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class load_game : MonoBehaviour
{
    public GameObject loadgameui;
    public static List<List<string>> people = new List<List<string>>();
    public static List<GameObject> player_turn;
    public static int turn_num =0;
    public int loadednum = 0;
    public static int currentloadednum = 0;
    public static List<string> loaded_info;
    public static string turn;
   //  public Button buttongame;
    public static List<int> deck_code = new List<int>();
    public static List<int> hand_code = new List<int>();
    public static List<int> graveyard_code = new List<int>();
    public static List<int> deckorder = new List<int>();
    public static List<int> handorder = new List<int>();
    public static List<int> graveyardorder = new List<int>();
    public static bool deckbool = true;
    public static bool handbool = true;
    public static bool graveyardbool = true;
    public static List<string> deckinfo = new List<string>();
    public static List<string> graveyardinfo = new List<string>();
    public static List<string> handinfo = new List<string>();
    public static List<List<string>> deckfullinfo = new List<List<string>>();

    private IEnumerator Wait(Action callback)
    {
        // Perform the operations of the other method
        // ...
        yield return new WaitForSeconds(1.5f);
        // Once the operations are complete, invoke the callback
        callback?.Invoke();

    }
    private IEnumerator Waitsmall(Action callback)
    {
        // Perform the operations of the other method
        // ...
        yield return new WaitForSeconds(.5f);
        // Once the operations are complete, invoke the callback
        callback?.Invoke();

    }
    /*    public static bool turn(GameObject selected)
        {
            Debug.Log(player_turn.Count);
    *//*        Debug.Log(people.Count);
            for (int i = 0; i < people.Count; i++)
            {*//* 
                for (int j = 0; j < player_turn.Count; j++)
                {
                    if( selected == player_turn[j])
                    {
                        return true;
                    }
                }
    *//*        }*//*
            return false;
        }*/

    public void loadedgames()
    {
        StartCoroutine(main.Instance.web.Upload(web.user, "none!", "none!", "https://lone-child.000webhostapp.com/loadedgames.php"));
        StartCoroutine(

        Wait(() =>
        {
            // Assuming you have a reference to the "load_game" transform
            Transform loadGameTransform = GameObject.Find("load_game").transform;

            // Loop to destroy all child objects
            int childCount = loadGameTransform.childCount;
            for (int i = childCount - 1; i >= 0; i--)
            {
                Transform child = loadGameTransform.GetChild(i);
                Destroy(child.gameObject);
            }
            Debug.Log(loaded_info.Count);
            for (int i = 0; i < loaded_info.Count; i+= 2)
            {
                GameObject loadgamesobject = Instantiate(loadgameui, GameObject.Find("load_game").transform);
                loadgamesobject.transform.Find("playerturn").GetComponent<TextMeshProUGUI>().text = loaded_info[i];
                loadgamesobject.GetComponent<load_game>().loadednum = int.Parse(loaded_info[i + 1]);
            }

        }));
    }

    public void loadgame(List<string> data)
    {
        Canvascontroller canvascontroller = GameObject.FindObjectOfType<Canvascontroller>();
        canvascontroller.gotoGame();
        
        loadmap loadmap = GameObject.FindObjectOfType<loadmap>();
        int count = loadmap.mapMaker(data);
        turn = data[data.Count - 1];
        data.RemoveAt(data.Count - 1);
        Debug.Log(data[count]);
        int through = 0;
        through = count;
        int nullcount = 0;
        while (through < data.Count)
        {

            if (data[through] == null)
            {
                data.RemoveAt(through);
                ++nullcount;
                through = count -1;
            }
            ++through;
        }
        for (int i = count; i < data.Count; i+= 4)
        {
            List<string> person = new List<string>();
            person.Add(data[i]);
            person.Add(data[i + 1]);
            person.Add(data[i + 2]);
            person.Add(data[i + 3]);
            people.Add(person);
        }
        string deck = "";
        string graveyard = "";
        string hand = "";
        for (int i = 0; i < people.Count; i++)
        {
            if(web.user == people[i][0])
            {
                Debug.Log(people[i][1]);
                string[] decksplit = people[i][1].Split(',');
                 deck = setupquery(decksplit, deck_code, deckorder);
                string[] graveyardsplit = people[i][2].Split(',');
                 graveyard = setupquery(graveyardsplit, hand_code, graveyardorder);
                string[] handsplit = people[i][3].Split(',');
                 hand = setupquery(handsplit, hand_code, handorder);
            }
        }
        Debug.Log(deck);
        Debug.Log(graveyard);
        Debug.Log(hand);

            StartCoroutine(main.Instance.web.Upload(deck, "none!", "none!", "https://lone-child.000webhostapp.com/getcardinfo.php"));
        StartCoroutine(
Waitsmall(() =>
        {
            StartCoroutine(main.Instance.web.Upload(graveyard, "none!", "none!", "https://lone-child.000webhostapp.com/getcardinfo.php"));
        }));

        StartCoroutine(
Wait(() =>
        {
            StartCoroutine(main.Instance.web.Upload(hand, "none!", "none!", "https://lone-child.000webhostapp.com/getcardinfo.php"));
        }));
        /*        deckbool = true;
                graveyardbool = true;*/
    }

    private static string setupquery(string[] type, List<int> type_code, List<int> order)
    {
        Debug.Log(type[0]);
        if (type[0] == "")
        {
            Debug.Log("none left");
            return "";
        }

        else
        {


            type_code.Clear();
            order.Clear();
            type_code.Add(0); //units
            type_code.Add(0); //armor
            type_code.Add(0); //spells

            string unitgrab = "select keyed, Name, Type, Species, Lore, Attack, Health, Defense, Mojo, attributes, model_type from unit_info where ";
            string spellgrab = "| select keyed, Name, type, description, mojo, lore, modeltype from spell_info where ";
            string weapongrab = "| select keyed, Name, Type, Classfor, Lore, givenAttack, givenHealth, givenDefense, givenmojo, mojo, Ability, modeltype  from armor_info where ";
            for (int j = 0; j < type.Length; j++)
            {
                if (int.Parse(type[j]) < 1000)
                {
                    order.Add(int.Parse(type[j]));
                    type_code[0] += 1;
                    unitgrab += "keyed = " + type[j] + " or ";
                }
                if (int.Parse(type[j]) < 2000 && int.Parse(type[j]) > 1000)
                {
                    order.Add(int.Parse(type[j]));
                    type_code[1] += 1;
                    weapongrab += "keyed = " + type[j] + " or ";
                }
                if (int.Parse(type[j]) < 3000 && int.Parse(type[j]) > 2000)
                {
                    order.Add(int.Parse(type[j]));
                    type_code[2] += 1;
                    spellgrab += "keyed = " + type[j] + " or ";
                }
            }
            string unitgrabmodified = unitgrab.Substring(0, unitgrab.Length - 3);
            if (type_code[0] == 0)
            {
                unitgrabmodified = "";
            }
            string weapongrabmodified = weapongrab.Substring(0, weapongrab.Length - 3);
            if (type_code[1] == 0)
            {
                weapongrabmodified = "";
            }
            string spellgrabmodified = spellgrab.Substring(0, spellgrab.Length - 3);
            if (type_code[2] == 0)
            {
                spellgrabmodified = "";
            }
            return unitgrabmodified + spellgrabmodified + weapongrabmodified;
        }
    }
    public void loadgamebutton()
    {
        currentloadednum = this.loadednum;
        StartCoroutine(main.Instance.web.Upload(this.loadednum+"", "none!", "none!", "https://lone-child.000webhostapp.com/loadgame.php"));
    }

    // Start is called before the first frame update
    void Start()
    {
/*        buttongame.onClick.AddListener(() =>
        {
            StartCoroutine(WaitForCoroutine());
        });*/
    }

    IEnumerator WaitForCoroutine()
    {
        //yield return StartCoroutine(main.Instance.web.Gettiles());
        yield return null;
        main.Instance.Canvas.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
