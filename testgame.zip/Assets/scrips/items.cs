using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using SimpleJSON;
using UnityEngine.UI;
using TMPro;

public class items : MonoBehaviour
{
    public GameObject thingss;
    public GameObject names;
    Action<string> _createItemsCallback;
    // Start is called before the first frame update
    void Start()
    { 

     /*   main.Instance.Login.LoginButton.onClick.AddListener(() =>
        {

            _createItemsCallback = (jsonarrayString) =>
            {
                StartCoroutine(CreateItemsRoutine(jsonarrayString));
            };

            CreateItems();
        }); */
    }

    public void CreateItems()
    { string userid = main.Instance.UserInfo.UserID;
        Debug.Log(userid);
        //StartCoroutine(main.Instance.web.Gettiles());
        StartCoroutine(main.Instance.web.GetItemsID(userid, _createItemsCallback));
    }
    // Update is called once per frame
    public IEnumerator CreateItemsRoutine(string jsonArrayString)
    { //parsing json array string as an array
        JSONArray jsonarray = JSON.Parse(jsonArrayString) as JSONArray;
        for (int i = 0; i < jsonarray.Count; i++)
        {   //create local variable
            bool isdone = false;
            string itemid = jsonarray[i].AsObject["itemID"];
            JSONObject iteminforjson = new JSONObject();

            //create a callback to get the information from web.cs
            Action<string> getItemInforCallback = (itemInfo) =>
            {
                isdone = true;
                JSONArray temparray = JSON.Parse(itemInfo) as JSONArray;
                iteminforjson = temparray[0].AsObject;
            };
            StartCoroutine(main.Instance.web.GetItems(itemid, getItemInforCallback));

            //wait until the callback is called from web (infor finished downloading)
            yield return new WaitUntil(() => isdone == true);

            GameObject item = Instantiate(thingss);
            item.transform.SetParent(this.transform);
            item.transform.localScale = Vector3.one;
            item.transform.localPosition = Vector3.zero;
            item.transform.Find("name").GetComponent<TextMeshProUGUI>().text = iteminforjson["name"];
            item.transform.Find("description").GetComponent<TextMeshProUGUI>().text = iteminforjson["description"];
            item.transform.Find("price").GetComponent<TextMeshProUGUI>().text = iteminforjson["price"];


        }
    }
}
