<?php
$servername = "lonechild.mysql.database.azure.com";
$username = "duncan";
$password = "285Thornrd";
$dbname = "Lone_Child";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query for unit_info
$query1 = "SELECT keyed, Name, Type, Species, lore, Attack, Health, Defense, Mojo, attributes, model_type FROM unit_info WHERE level = 0;";
$result1 = $conn->query($query1);

// Query for spell_info
$query2 = "select keyed, Name, type, description, mojo, lore, modeltype from spell_info WHERE level = 0;";
$result2 = $conn->query($query2);

// Query for armor_info
$query3 = "select keyed, Name, Type, Classfor, Lore, givenAttack, givenHealth, givenDefense, givenmojo, mojo, Ability, modeltype from armor_info WHERE level = 0;";
$result3 = $conn->query($query3);

// Combine query results into a single array
$queryResults = array();
$queryResults[] = $result1->fetch_all(MYSQLI_ASSOC);
$queryResults[] = $result2->fetch_all(MYSQLI_ASSOC);
$queryResults[] = $result3->fetch_all(MYSQLI_ASSOC);

// Create an associative array for the final JSON response
$response = array(
    "query_results" => $queryResults
);

// Encode the response as JSON and print it
echo json_encode($response);

// Close connection
$conn->close();
?>