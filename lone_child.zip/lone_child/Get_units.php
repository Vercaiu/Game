<?php

$servername = "lonechild.mysql.database.azure.com";
$username = "duncan";
$password = "285Thornrd";
$dbname = "Lone_Child";

// Retrieve the queries from Unity
$queries = explode("|", $_POST["loginUser"]);

// Establish the database connection
$connection = mysqli_connect($servername, $username, $password, $dbname);

// Check if the connection was successful
if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Process each query and collect the results
$results = array();
foreach ($queries as $query) {
    $query = trim($query); // Remove any leading/trailing whitespace
    if (!empty($query)) { // Skip empty queries
        $result = mysqli_query($connection, $query);
        $data = array();
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $data[] = $row;
            }
        }
        $results[] = $data;
    }
}

// Close the database connection
mysqli_close($connection);

// Prepare the response array
$response = array(
    "query_results" => $results
);

// Convert the response array to JSON
$jsonResponse = json_encode($response);

// Set the content type and send the JSON response
echo $jsonResponse;
?>