 <?php
$servername = "lonechild.mysql.database.azure.com";
$username = "duncan";
$password = "285Thornrd";
$dbname = "Lone_Child";

$loginUser = $_POST["loginUser"];
var_dump($_POST);
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

$sql = "SELECT
    playerturn,
    gamenum,
    (
        IF(player1 IS NOT NULL, 1, 0) +
        IF(player2 IS NOT NULL, 1, 0) +
        IF(player3 IS NOT NULL, 1, 0) +
        IF(player4 IS NOT NULL, 1, 0) +
        IF(player5 IS NOT NULL, 1, 0) +
        IF(player6 IS NOT NULL, 1, 0) +
        IF(player7 IS NOT NULL, 1, 0)
    ) AS player_count
FROM `new_games2`
WHERE
    (player1 = '$loginUser')
    OR (player2 = '$loginUser')
    OR (player3 = '$loginUser')
    OR (player4 = '$loginUser')
    OR (player5 = '$loginUser')
    OR (player6 = '$loginUser')
    OR (player7 = '$loginUser')";
$result = $conn->query($sql);

if($result->num_rows >0){ //92
	$rows = array();
	while($row = $result->fetch_assoc()){
		$rows[] = $row;
	}
	echo json_encode($rows);
} else{
	echo "0";
}
$conn->close();
?> 