 <?php
$servername = "lonechild.mysql.database.azure.com";
$username = "duncan";
$password = "285Thornrd";
$dbname = "Lone_Child";

$loginUser = $_POST["loginUser"];
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

$sql = "SELECT `player1`, `player1deck`, `player1graveyard`, `player1hand`, `player2`, `player2deck`, `player2graveyard`, `player2hand` `player3`, `player3deck`, `player3graveyard`, `player3hand`, `player4`, `player4deck`, `player4graveyard`, `player4hand`, `player5`, `player5deck`, `player5graveyard`, `player5hand`, `player6`, `player6deck`, `player6graveyard`, `player6hand`, `player7`, `player7deck`, `player7graveyard`, `player7hand`, `playerturn` FROM `new_games2` WHERE gamenum = '" . $loginUser . "'";
$result = $conn->query($sql);

if($result->num_rows >0){ //92
	$rows = array();
	while($row = $result->fetch_assoc()){
		$rows[] = $row;
	}
	echo json_encode($rows);
} else{
	echo "0";
}
$conn->close();
?> 