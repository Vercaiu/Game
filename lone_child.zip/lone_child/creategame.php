<?php
$servername = "lonechild.mysql.database.azure.com";
$username = "duncan";
$password = "285Thornrd";
$dbname = "Lone_Child";

$loginUser = $_POST["loginUser"];
$loginPass = $_POST["loginPass"];
$thirdoption = $_POST["thirdoption"];
$thirdoption = explode("|", $_POST["thirdoption"]);
$column1 = $thirdoption[0];
$column2 = $thirdoption[1];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT user FROM `looking_for_game` WHERE user =  '" . $loginUser . "' ";
$result = $conn->query($sql);
$gamenum ="0";
if ($result->num_rows > 5) {
  echo "Cannot create more";
} else {
  $sql = "INSERT INTO `looking_for_game`(`keyed`, `user`, `deck`, `hero`, `number_of_players`, `gamenum`) 
          VALUES (null, '" . $loginUser . "' , '" . $loginPass . "', '" . $column1 . "',  '" . $column2 . "', null )";

  if ($conn->query($sql) === TRUE) {
    // Get the last inserted ID (keyed) and update gamenum
    $gamenum = $conn->insert_id;
    $updateSql = "UPDATE `looking_for_game` SET `gamenum` = " . $gamenum . " WHERE `keyed` = " . $gamenum;
    $conn->query($updateSql);

    echo "New record created successfully";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
}

$result = $conn->query("SELECT gamenum FROM `looking_for_game` WHERE gamenum = " . $gamenum);
if ($result->num_rows > 0) {
  $rows = array();
  while ($row = $result->fetch_assoc()) {
    $rows[] = $row;
  }
  echo json_encode($rows);
}

$conn->close();
?>