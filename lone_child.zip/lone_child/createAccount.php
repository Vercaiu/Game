 <?php
$servername = "lonechild.mysql.database.azure.com";
$username = "duncan";
$password = "285Thornrd";
$dbname = "Lone_Child";

$loginUser = $_POST["loginUser"];
$loginPass = $_POST["loginPass"];
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "Select * from `users` where username =  '" . $loginUser . "' ";
$result = $conn->query($sql);

if($result->num_rows >0){
	echo "that user already exists";
} else{
    
$sql = "INSERT INTO `users`(`keyed`, `username`, `passwords`,
`Deck_1`, `Deck_2`, `Deck_3`) VALUES (null, '" . $loginUser . "', '" . $loginPass . "', '6,7,8,9,1001', '5,4,10,11,1003,1005', '12,13,14,1002,1004,1006')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

}
$conn->close();
?>