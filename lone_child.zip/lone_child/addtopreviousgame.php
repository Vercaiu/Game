<?php
$servername = "lonechild.mysql.database.azure.com";
$username = "duncan";
$password = "285Thornrd";
$dbname = "Lone_Child";

$loginUser = $_POST["loginUser"];
$loginPass = $_POST["loginPass"];
$thirdoption = explode("|", $_POST["thirdoption"]);
$column1 = $thirdoption[0];
$column2 = intval($thirdoption[1]); // Convert to integer
$column3 = $thirdoption[2];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Sanitize user inputs
$loginUser = $conn->real_escape_string($loginUser);
$loginPass = $conn->real_escape_string($loginPass);
$column1 = $conn->real_escape_string($column1);
$column2 = intval($column2);
$column3 = $conn->real_escape_string($column3);

$sql = "SELECT *
        FROM looking_for_game
        WHERE (user = '$loginUser' AND keyed = '$column3')
           OR (user2 = '$loginUser' AND keyed = '$column3')
           OR (user3 = '$loginUser' AND keyed = '$column3')
           OR (user4 = '$loginUser' AND keyed = '$column3')
           OR (user5 = '$loginUser' AND keyed = '$column3')
           OR (user6 = '$loginUser' AND keyed = '$column3')
           OR (user7 = '$loginUser' AND keyed = '$column3')";
$result = $conn->query($sql);

if ($result->num_rows >= 1) {
    echo "already in game";
} else {
    if ($column2 == 1) {
        $sql = "UPDATE looking_for_game SET user2 = '$loginUser', deck2 = '$loginPass', hero2 = '$column1' WHERE keyed = '$column3'";
        $conn->query($sql);
    } else if ($column2 == 2) {
        $sql = "UPDATE looking_for_game SET user3 = '$loginUser', deck3 = '$loginPass', hero3 = '$column1' WHERE keyed = '$column3'";
        $conn->query($sql);
    } else if ($column2 == 3) {
        $sql = "UPDATE looking_for_game SET user4 = '$loginUser', deck4 = '$loginPass', hero4 = '$column1' WHERE keyed = '$column3'";
        $conn->query($sql);
    } else if ($column2 == 4) {
        $sql = "UPDATE looking_for_game SET user5 = '$loginUser', deck5 = '$loginPass', hero5 = '$column1' WHERE keyed = '$column3'";
        $conn->query($sql);
    } else if ($column2 == 5) {
        $sql = "UPDATE looking_for_game SET user6 = '$loginUser', deck6 = '$loginPass', hero6 = '$column1' WHERE keyed = '$column3'";
        $conn->query($sql);
    } else if ($column2 == 6) {
        $sql = "UPDATE looking_for_game SET user7 = '$loginUser', deck7 = '$loginPass', hero7 = '$column1' WHERE keyed = '$column3'";
        $conn->query($sql);
    }
    else {
        echo "complete fail";
    }
}

$conn->close();
?>