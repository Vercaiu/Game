 <?php
$servername = "lonechild.mysql.database.azure.com";
$username = "duncan";
$password = "285Thornrd";
$dbname = "Lone_Child";

$loginUser = $_POST["loginUser"];
$loginPass = $_POST["loginPass"];
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT passwords, keyed from users where username = '" . $loginUser . "'";
$result = $conn->query($sql);

//$sql = "select password, keyed from users where username = ?";

//$statement = $conn.prepare($sql);

//$statement->bind_param("s", $loginUser);

//$statement->execute();
//$result = $statement->get_result();

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
	if($row["passwords"] == $loginPass){
		echo $row["keyed"];
	}
	else{
		echo "wrong credentials.";
	}
  }
} else {
  echo "0 results, no username matches";
}
$conn->close();
?> 