<?php

$servername = "lonechild.mysql.database.azure.com";
$username = "duncan";
$password = "285Thornrd";
$dbname = "Lone_Child";

// Retrieve the queries from Unity
$queries = explode("|", $_POST["loginUser"]);
$loginPass = $_POST["loginPass"];
$thirdoption = $_POST["thirdoption"];

// Establish the database connection
$connection = mysqli_connect($servername, $username, $password, $dbname);

// Check if the connection was successful
if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Process each query and collect the results

foreach ($queries as $query) {
    $query = trim($query); // Remove any leading/trailing whitespace
    if (!empty($query)) { // Skip empty queries
        $result = mysqli_query($connection, $query);

    }
}
$query = "UPDATE users SET experience = experience + 5 WHERE username = '$loginPass'";
$result = mysqli_query($connection, $query);

$query = "delete from new_games2 where gamenum = $thirdoption";
$result = mysqli_query($connection, $query);

// Close the database connection
mysqli_close($connection);


?>