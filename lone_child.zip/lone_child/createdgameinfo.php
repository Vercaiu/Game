 <?php
$servername = "lonechild.mysql.database.azure.com";
$username = "duncan";
$password = "285Thornrd";
$dbname = "Lone_Child";

$loginUser = $_POST["loginUser"];
$loginPass = $_POST["loginPass"];
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

$sql = "SELECT `user`, `deck`, `hero`, `user2`, `deck2`, `hero2`, `user3`, `deck3`, `hero3`, `user4`, `deck4`, `hero4`, `user5`, `deck5`, `hero5`, `user6`, `deck6`, `hero6`, `user7`, `deck7`, `hero7`, `number_of_players` FROM `looking_for_game` WHERE keyed = '" . $loginUser . "'";
$result = $conn->query($sql);

if($result->num_rows >0){ //92
	$rows = array();
	while($row = $result->fetch_assoc()){
		$rows[] = $row;
	}
	echo json_encode($rows);
} else{
	echo "0";
}

$query = "DELETE FROM `looking_for_game` WHERE keyed = '$loginPass'";
$result = mysqli_query($conn, $query);

$conn->close();
?> 