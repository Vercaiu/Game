<?php

$servername = "lonechild.mysql.database.azure.com";
$username = "duncan";
$password = "285Thornrd";
$dbname = "Lone_Child";

// Retrieve the queries from Unity
$loginUser = $_POST["loginUser"];
$loginPass = $_POST["loginPass"];
$thirdoption = $_POST["thirdoption"];

// Establish the database connection
$connection = mysqli_connect($servername, $username, $password, $dbname);

// Check if the connection was successful
if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

$query = "UPDATE users SET $loginUser = '$loginPass' WHERE username = '$thirdoption'";
$result = mysqli_query($connection, $query);

// Close the database connection
mysqli_close($connection);


?>