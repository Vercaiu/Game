 <?php
$servername = "lonechild.mysql.database.azure.com";
$username = "duncan";
$password = "285Thornrd";
$dbname = "Lone_Child";

$loginUser = $_POST["loginUser"];
var_dump($_GET);
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
//$sql ="Select * from unit_info where keyed = 4 or keyed = 1 or keyed = 3";
$result = $conn->query($loginUser);

if ($result === TRUE) {
  echo " updated";
}

$conn->close();
?> 