 <?php
$servername = "lonechild.mysql.database.azure.com";
$username = "duncan";
$password = "285Thornrd";
$dbname = "Lone_Child";

$loginUser = $_POST["loginUser"];
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if ($conn->query($loginUser) === TRUE) {
  $lastInsertedId = $conn->insert_id;
  echo $lastInsertedId;
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();
?>