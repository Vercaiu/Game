using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class convertor : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public static void statstostats(GameObject unit, GameObject card)
    {
        card.GetComponent<unit_info>().key = unit.GetComponent<unit_info>().key;
        card.GetComponent<unit_info>().Name = unit.GetComponent<unit_info>().Name;
        card.GetComponent<unit_info>().Type = unit.GetComponent<unit_info>().Type;
        card.GetComponent<unit_info>().Species = unit.GetComponent<unit_info>().Species;
        card.GetComponent<unit_info>().lore = unit.GetComponent<unit_info>().lore;
        card.GetComponent<unit_info>().Attack = unit.GetComponent<unit_info>().Attack;
        card.GetComponent<unit_info>().Health = unit.GetComponent<unit_info>().Health;
        card.GetComponent<unit_info>().Defense = unit.GetComponent<unit_info>().Defense;
        card.GetComponent<unit_info>().mojo = unit.GetComponent<unit_info>().mojo;
        card.GetComponent<unit_info>().attributes = unit.GetComponent<unit_info>().attributes;
        card.GetComponent<unit_info>().modelnumber = unit.GetComponent<unit_info>().modelnumber;
    }

    public static void listtostats(GameObject card, List<string> unit)
    {
        card.GetComponent<unit_info>().key = int.Parse(unit[0].ToString().Trim('"'));
        card.GetComponent<unit_info>().Name = unit[1].ToString().Trim('"');
        card.GetComponent<unit_info>().Type = unit[2].ToString().Trim('"');
        card.GetComponent<unit_info>().Species = unit[3].ToString().Trim('"');
        card.GetComponent<unit_info>().lore = int.Parse(unit[4].ToString().Trim('"'));
        card.GetComponent<unit_info>().Attack = int.Parse(unit[5].ToString().Trim('"'));
        card.GetComponent<unit_info>().Health = int.Parse(unit[6].ToString().Trim('"'));
        card.GetComponent<unit_info>().Defense = int.Parse(unit[7].ToString().Trim('"'));
        card.GetComponent<unit_info>().mojo = int.Parse(unit[8].ToString().Trim('"'));
        card.GetComponent<unit_info>().attributes = unit[9].ToString().Trim('"');
        card.GetComponent<unit_info>().modelnumber = int.Parse(unit[10].ToString().Trim('"'));
    }

    public static float placeunitontile(GameObject instantiated, GameObject tile)
    {
        // Get the collider of the object to be instantiated
        Collider colliderToInstantiate = instantiated.GetComponent<Collider>();
        // Get the collider of the object at the specified location
        Collider colliderAtLocation = tile.GetComponent<Collider>(); // Get the collider from the object at the currentx, .52, currentz location
        //colliderAtLocation.bounds.m
        // Calculate the y offset to ensure the colliders are aligned
        // Vector3 desiredPosition = new Vector3((float)currentx, colliderAtLocation.bounds.max.y + colliderToInstantiate.bounds.min.y, (float)currentz);
        //colliderAtLocation.bounds.max.y + colliderToInstantiate.bounds.min.y
        return .9f;
    }
    public static string listtophp(List<int> incoming)
    {
        string list = "";
        for (int g = 0; g < incoming.Count; g++)
        {
            list += incoming[g];
            if(g < incoming.Count - 1)
            {
                list += ",";
            }
        }
        return list;
    }

    public static void gettingcards(List<string> info, string instantiator)
    {
        int count = 0;
        while (count < info.Count)
        {
            if (int.Parse(info[count].ToString().Trim('"')) < 1000)
            {
                int statlength = 11;
                List<string> unit = decks.organizecard(info, count, statlength);
                card_ui card_ui = GameObject.FindObjectOfType<card_ui>();
                card_ui.organizeCard2(unit, instantiator);
                count += 11;
            }
            else if (int.Parse(info[count].ToString().Trim('"')) < 2000
                && int.Parse(info[count].ToString().Trim('"')) > 1000)
            {
                int statlength = 12;
                List<string> armor = decks.organizecard(info, count, statlength);
                card_ui card_ui = GameObject.FindObjectOfType<card_ui>();
                card_ui.organizeArmor(armor, instantiator);
                count += 12;
            }
            else if (int.Parse(info[count].ToString().Trim('"')) < 3000
                    && int.Parse(info[count].ToString().Trim('"')) > 2000)
            { //    STILL NEED TO SET UP SPELLS
                int statlength = 7;
                List<string> spell = decks.organizecard(info, count, statlength);
                card_ui card_ui = GameObject.FindObjectOfType<card_ui>();
                card_ui.organizeCard2(spell, instantiator);
            }
        }
    }
    public static string setupquery(string[] type, List<int> type_code, List<int> order)
    {
        Debug.Log(type[0]);
        if (type[0] == "")
        {
            Debug.Log("none left");
            return "";
        }

        else
        {


            type_code.Clear();
            order.Clear();
            type_code.Add(0); //units
            type_code.Add(0); //armor
            type_code.Add(0); //spells

            string unitstart = "select keyed, Name, Type, Species, Lore, Attack, Health, Defense, Mojo, attributes, model_type from unit_info where ";
            string unitgrab = "select keyed, Name, Type, Species, Lore, Attack, Health, Defense, Mojo, attributes, model_type from unit_info where ";
            string start = "| ";
            string spellend = "select keyed, Name, type, description, mojo, lore, modeltype from spell_info where ";
            string spellgrab = start + spellend;
            string weaponend = "select keyed, Name, Type, Classfor, Lore, givenAttack, givenHealth, givenDefense, givenmojo, mojo, Ability, modeltype from armor_info where ";
            string weapongrab = start + weaponend;
            for (int j = 0; j < type.Length; j++)
            {
                if (int.Parse(type[j]) < 1000)
                {
                    order.Add(int.Parse(type[j]));
                    type_code[0] += 1;
                    unitgrab += "keyed = " + type[j] + " Union ALL " + unitstart;
                }
                if (int.Parse(type[j]) < 2000 && int.Parse(type[j]) > 1000)
                {
                    order.Add(int.Parse(type[j]));
                    type_code[1] += 1;
                    weapongrab += "keyed = " + type[j] + " Union ALL " + weaponend;
                }
                if (int.Parse(type[j]) < 3000 && int.Parse(type[j]) > 2000)
                {
                    order.Add(int.Parse(type[j]));
                    type_code[2] += 1;
                    spellgrab += "keyed = " + type[j] + " Union ALL " + spellend;
                }
            }
            string unitgrabmodified = modifystring(unitgrab, 127);
            if (type_code[0] == 0)
            {
                unitgrabmodified = "";
            }
            string weapongrabmodified = modifystring(weapongrab, 150);
            if (type_code[1] == 0)
            {
                weapongrabmodified = "";
            }
            string spellgrabmodified = modifystring(spellgrab, 94);
            if (type_code[2] == 0)
            {
                spellgrabmodified = "";
            }
            return unitgrabmodified + spellgrabmodified + weapongrabmodified;
        }
    }
    private static string modifystring(string grab, int length)
    {
        string grabmodified = "";
        if (grab.Length >= length)
        {
            grabmodified = grab.Substring(0, grab.Length - length);
        }
        return grabmodified;
    }
    /*    public static List<string> stringtolist(string breakup)
        {

        }*/

    // Update is called once per frame
    void Update()
    {
        
    }
}
