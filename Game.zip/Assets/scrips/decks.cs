using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class decks : MonoBehaviour
{
    // Start is called before the first frame update
    public static List<List<int>> Deck1;
    public static List<List<string>> Deck1true = new List<List<string>>();
    public static List<List<int>> Deck2;
    public static List<List<string>> Deck2true = new List<List<string>>();
    public static List<List<int>> Deck3;
    public static List<List<string>> Deck3true = new List<List<string>>();
    public static List<List<int>> currentdeck;
    public static List<List<string>> currentdecktrue;
    public static List<List<string>> graveyard = new List<List<string>>();
    public static List<string> hero;

    public static string deck;

    public static string deck1;
    public static string deck2;
    public static string deck3;


/*    public IEnumerator decodeDeck(string jsonArrayString)
    {
        Debug.Log("Hello");
        List<string> first = main.Instance.web.jsonConverter(jsonArrayString);
        if (currentdeck == Deck1)
        {
            Deck1 = placeIntoDeck(0, first);
            currentdeck = Deck1;
        }

*//*        if (currentdeck == Deck2)
        {
            Deck2 = placeIntoDeck(1, first);
        }
        if (currentdeck == Deck3)
        {
            Deck3 = placeIntoDeck(2, first);
        }*//*
        yield return null;
    }*/

    public IEnumerator GetRightDeck(string jsonArrayString)
    {
        Debug.Log(jsonArrayString);
        List<string> cards = main.Instance.web.jsonConverter(jsonArrayString);
        Debug.Log(cards);
        if (Deck1true[0][0] == "placeholder")
        {
            unitToDecck20(Deck1true, cards);
        }
        else if (Deck2true[0][0] == "placeholder")
        {
            unitToDecck20(Deck2true, cards);
        }
        else if (Deck3true[0][0] == "placeholder")
        {
            unitToDecck20(Deck3true, cards);
        }
        yield return null;
    }
    private void unitToDecck20(List<List<string>> deck, List<string> cards)
    {
        int placeholder = 0;
        for (int i = 0; i < cards.Count; i++)
        {
            if( i % 10 == 0)
            {
                List<string> card = new List<string>();
                deck.Add(card);
                ++placeholder;
            }
            deck[placeholder].Add(cards[i]);
        }
        deck.RemoveAt(0);
        Shuffle(deck);
        currentdecktrue = deck;
    }

    public static List<string> organizecard(List<string> unit, int start, int statlength)
    {
        List<string> newunit = new List<string>();
        for (int i = start; i < (statlength+start); i++)
        {
            newunit.Add(unit[i]);
        }
        return newunit;
    }

    public static void drawcard()
    {if (load_game.deckorder.Count == 0)
        {
            Debug.Log("no cards left");
        }
        else
        {


            load_game.handorder.Add(load_game.deckorder[load_game.deckorder.Count - 1]);
            load_game.deckorder.RemoveAt(load_game.deckorder.Count - 1);
            card_ui card_ui = GameObject.FindObjectOfType<card_ui>();
            Debug.Log(load_game.deckfullinfo[load_game.deckfullinfo.Count - 1][0].ToString().Trim('"'));
            if (int.Parse(load_game.deckfullinfo[load_game.deckfullinfo.Count - 1][0].ToString().Trim('"')) < 1000)
            {
                card_ui.organizeCard2(load_game.deckfullinfo[load_game.deckfullinfo.Count - 1], "cards");
                load_game.deckfullinfo.RemoveAt(load_game.deckfullinfo.Count - 1);
            }
            else if (int.Parse(load_game.deckfullinfo[load_game.deckfullinfo.Count - 1][0].ToString().Trim('"')) < 2000
                && int.Parse(load_game.deckfullinfo[load_game.deckfullinfo.Count - 1][0].ToString().Trim('"')) > 1000)
            {
                card_ui.organizeArmor(load_game.deckfullinfo[load_game.deckfullinfo.Count - 1], "cards");
                load_game.deckfullinfo.RemoveAt(load_game.deckfullinfo.Count - 1);
            }
            else if (int.Parse(load_game.deckfullinfo[load_game.deckfullinfo.Count - 1][0].ToString().Trim('"')) < 3000
                    && int.Parse(load_game.deckfullinfo[load_game.deckfullinfo.Count - 1][0].ToString().Trim('"')) > 2000)
            { //STILL NEED TO SET UP SPELLS

            }


/*            card_ui.organizeCard2(load_game.deckfullinfo[load_game.deckfullinfo.Count - 1]);
            load_game.deckfullinfo.RemoveAt(load_game.deckfullinfo.Count - 1);*/
        }
    }

    public static List<List<string>> getfullinfo(List<string> info, List<int> order)
    {   
        int count = 0;
        int count2 = 0;
        List<List<string>> betterinfo = new List<List<string>>();
        List<List<string>> straightinfo = new List<List<string>>();
        for (int i = 0; i < info.Count; i++)
        {
            Debug.Log(info[i]);
        }
        while (count2 < info.Count)
        {
            if (int.Parse(info[count2].ToString().Trim('"')) < 1000)
            {
                int statlength = 11;
                List<string> unit = decks.organizecard(info, count2, statlength);
                count2 += statlength;
                straightinfo.Add(unit);
            }
            else if (int.Parse(info[count2].ToString().Trim('"')) < 2000
                && int.Parse(info[count2].ToString().Trim('"')) > 1000)
            {
                int statlength = 12;
                List<string> unit = decks.organizecard(info, count2, statlength);
                count2 += statlength;
                straightinfo.Add(unit);
            }
            else if (int.Parse(info[count2].ToString().Trim('"')) < 3000
                    && int.Parse(info[count2].ToString().Trim('"')) > 2000)
            {
                int statlength = 7;
                List<string> unit = decks.organizecard(info, count2, statlength);
                count2 += statlength;
                straightinfo.Add(unit);
            }
        }
        /*            for (int i = 0; i < info.Count; i+= 11)
                {
                        List<string> unit = decks.organizecard(info, i, 11);
                    straightinfo.Add(unit);
                }*/
        Debug.Log(order.Count);
        Debug.Log(straightinfo.Count);
        for (int i = 0; i < straightinfo.Count; i++)
        {
            if (int.Parse(straightinfo[i][0].ToString().Trim('"')) == order[count])
            {
                betterinfo.Add(straightinfo[i]);
                i = 0;
                ++count;
                Debug.Log(count);
                if(count == order.Count)
                {
                    break;
                }
            }
        }
        return betterinfo;
    }

    public static void Shuffle(List<List<string>> list)
    {
        for (int i = 0; i < list.Count; i++)
        {
            int r =  Random.Range(0, list.Count);
            List<string> holder = new List<string>();
            holder = list[i];
            list[i] = list[r];
            list[r] = holder;
        }
    }
    public static void Shuffle2(List<string> list)
    {
        for (int i = 0; i < list.Count; i++)
        { 
            int r = Random.Range(0, list.Count);
            string holder = "";
            holder = list[i];
            list[i] = list[r];
            list[r] = holder;
        }
    }


    private int randomValue; // Declare a variable to store the random number

    public int GenerateRandomNumber()
    {
        randomValue = Random.Range(0, 2);// Generate a random number and store it in the variable
        return randomValue;    
    }

    public void pickHero()
    {
        StartCoroutine(main.Instance.web.Upload(2 +"", "none!", "none!", "https://lone-child.000webhostapp.com/Get_Hero.php"));
    }
    public List<object> Place_card()
    {
        if (randomValue == 0)
        {


            List<object> card = new List<object>();
            card.Add("The Lone Child");
            card.Add(3);
            card.Add(4);
            card.Add(1);
            card.Add("hitter");
            card.Add("human");
            card.Add("none");
            card.Add(0);
            return card;
        }
        else
        {
            List<object> card = new List<object>();
            card.Add("Miriam");
            card.Add(7);
            card.Add(12);
            card.Add(8);
            card.Add("mage");
            card.Add("monki");
            card.Add("none");
            card.Add(1);
            return card;
        }
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
