using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lore : MonoBehaviour
{
    public static List<string> loresegments = new List<string>();
    // Start is called before the first frame update
    void Start()
    {
        loresegments.Add("A stick from a tree you could find anywhere in the world. The owner and age of the branch has been lost to history, or it is better to say was never found in history. " +
            "There are no unique engravings on it, and there has yet to be any connection to any events throughout the world. " +
            "It is quite frequently questioned why it is even in this database to begin with. " +
            "Some say that there is some power trapped within, while others comment on how it may have been misplaced by a staff used by one of the great doggos long ago. " +
            "No matter what, it is safe to say that the mystery of it's history has cemented it in history.");

        loresegments.Add("Estimated to be created around year 26 A.D., this object was found in a storage unit from the demon realm, blood still splattered on. " +
            "The crown was created for John William, the creator of the cool empire. While whoever wore the crown would see protection from the guards and respect of the people, due to the responsibilities and stress many who wore the crown found themselves dying of young age. " +
            "The last known wearer was a you man named William Halbert, the ruler of the cool empire from 57 A.D to the destruction of the empire, and his subsequent death, in year 62.");

        loresegments.Add("A leftover piece from the construction of the great doggo hall. " +
            "While it was initially being stored to use for an expansion, with the doggo lords able to find a way for the retired doggos " +
            "to leave the bubble there is no reason to believe it will ever find use. While there are hundreds of boards that were left behind, " +
            "this one in particular was the one the young Lone Child picked up to help, promptly acquired a splinter, and was forced away by her children.");
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
