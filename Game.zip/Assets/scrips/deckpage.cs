using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class deckpage : MonoBehaviour
{
   // public Button DeckPage;
    public Button Deck1;
    public Button Deck2;
    public Button Deck3;

    public static List<string> cards = new List<string>();
    public static List<string> deck = new List<string>();
    public static string currentdeck = "Deck_1";
    // public Canvas targetCanvas; // Reference to the target Canvas
    //  public Button goback;

    public void getcards()
    {
        Debug.Log(cards.Count);
            Debug.Log("test");
            StartCoroutine(main.Instance.web.Upload(user_info.level.ToString(), "none!", "none!", "https://lone-child.000webhostapp.com/availablecards.php"));
        Debug.Log(deck.Count);
        string[] betterdeck = decks.deck.Split(",");
        List<int> stringList = new List<int>();
        foreach (string str in betterdeck)
        {
            if (int.TryParse(str, out int num))
            {
                stringList.Add(num);
            }
        }
        string query = convertor.setupquery(betterdeck, stringList, stringList);
        Debug.Log(query);//https://lone-child.000webhostapp.com/Get_units.php
        StartCoroutine(main.Instance.web.Upload(query, "none!", "none!", "http://localhost/lone_child/Get_units.php"));
    }

    public  void updatedeck()
    {
        Transform transform = GameObject.Find("rectdect").transform;
        string deck = "";
        for (int i = 0; i < transform.childCount; i++)
        {
            deck += transform.GetChild(i).gameObject.GetComponent<unit_info>().key;
            if(i < transform.childCount - 1)
            {
                deck += ",";
            }
        }//https://lone-child.000webhostapp.com/setdeck.php
        StartCoroutine(main.Instance.web.Upload(currentdeck, deck, web.user, "http://localhost/lone_child/setdeck.php"));
    }

    public void onexit()
    {
        Transform transform = GameObject.Find("rectdect").transform;
        Transform transformmore = GameObject.Find("rectall_cards").transform;
        cleanup.cleancards(transform);
        cleanup.cleancards(transformmore);
    }
    public void getDeck1()
    {
        /*        List<string> test = new List<string>();
                test.Add("placeholder");
                decks.Deck1true.Add(test);
                decks.currentdeck = decks.Deck1;*/
        currentdeck = "Deck_1";//https://lone-child.000webhostapp.com/getDeck.php
        StartCoroutine(main.Instance.web.Upload(web.user, currentdeck, "none!", "http://localhost/lone_child/getDeck.php"));
    }
    public void getDeck2()
    {
        /*        List<string> test = new List<string>();
                test.Add("placeholder");
                decks.Deck2true.Add(test);
                decks.currentdeck = decks.Deck2;*/
        currentdeck = "Deck_2";//https://lone-child.000webhostapp.com/getDeck.php
        StartCoroutine(main.Instance.web.Upload(web.user, currentdeck, "none!", "http://localhost/lone_child/getDeck.php"));
    }
    public void getDeck3()
    {
        /*        List<string> test = new List<string>();
                test.Add("placeholder");
                decks.Deck3true.Add(test);
                decks.currentdeck = decks.Deck3;*/
        currentdeck = "Deck_3";//https://lone-child.000webhostapp.com/getDeck.php
        StartCoroutine(main.Instance.web.Upload(web.user, currentdeck, "none!", "http://localhost/lone_child/getDeck.php"));
    }
    // Start is called before the first frame update
    void Start()
    {
/*        DeckPage.onClick.AddListener(() =>
        {
          //  StartCoroutine(main.Instance.web.Upload(web.user, "none!", "https://lone-child.000webhostapp.com/getDeck.php"));
        });*/
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
