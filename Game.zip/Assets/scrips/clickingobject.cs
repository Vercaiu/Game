using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class clickingobject : MonoBehaviour 
{
    public static float tileradius = 1.5f;
    public bool placeunittile = false;
    public int tiledigit;
    public bool selectedtile = false;
    public bool possibletile = false;
    public bool possibleattacktile = false;
    public bool unitontile = false;
    public bool armorable = false;
    public static GameObject selectedObjectTile;
    public static GameObject selectedObjectUnit;
    public static Collider[] colliders;
    public static List<Collider> tilecolidders = new List<Collider>();
    public static Collider[] hitcolliders;
    // Start is called before the first frame update
    void Start()
    {
        selectedObjectTile = GameObject.Find("blank");
        selectedObjectUnit = GameObject.Find("blank");
        colliders = new Collider[0];
    }
    private void OnMouseDown()
    {
        Debug.Log("check");
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit))
        {
            GameObject clickedObject = hit.collider.gameObject;
            if (selectedObjectTile != clickedObject
                && selectedObjectUnit != clickedObject)
            {
                reverting(hit);
                // Check if the clicked object is a tile or a unit
                if (clickedObject.transform.parent.name == "tiles")
                {
                    // Perform actions on the tile
                    Debug.Log("Clicked on a tile");
                    // Find the unit above the tile
                    RaycastHit unitHit;
                    if (Physics.Raycast(clickedObject.transform.position, Vector3.up, out unitHit))
                    {
                        if (unitHit.collider.gameObject.transform.parent.name == "units")
                        {
                            // Perform actions on the unit above the tile
                            Debug.Log("Unit above the tile: " + unitHit.collider.gameObject.name);
                            PerformTileActions(hit, unitHit);
                        }
                    }
                    else
                    {
                        GetComponent<Renderer>().material.color = Color.cyan;
                        transform.Translate(transform.up * 0.2f);
                        selectedObjectTile = clickedObject;
                        selectedObjectUnit = GameObject.Find("blank");
                        Debug.Log("Shouldn'tt go here");
                    }
                }
                else if (hit.collider.gameObject.transform.parent.name == "units")
                {
                    // Perform actions on the unit
                    Debug.Log("Clicked on a unit");

                    // Find the tile below the unit
                    RaycastHit tileHit;
                    if (Physics.Raycast(clickedObject.transform.position, Vector3.down, out tileHit))
                    {
                        if (tileHit.collider.gameObject.transform.parent.name == "tiles")
                        {
                            // Perform actions on the tile below the unit
                            Debug.Log("Tile below the unit: " + tileHit.collider.gameObject.name);
                            PerformTileActions(tileHit, hit);
                        }
                    }
                }
            }

            if (selectedObjectUnit != GameObject.Find("blank")
        && !selectedObjectUnit.GetComponent<unit_info>().canMove
        && !selectedObjectUnit.GetComponent<unit_info>().extraMove)
            {
                selectedObjectUnit.GetComponent<Renderer>().material.color = Color.cyan;
            }
        }
    }

    private void PerformTileActions(RaycastHit tiles, RaycastHit unit)
    {
        // Implement your tile-specific actions here
        selectedObjectUnit = unit.collider.gameObject;
        selectedObjectUnit.GetComponent<Renderer>().material.color = Color.black;
        selectedObjectTile = tiles.collider.gameObject;
        Renderer renderer = tile(tiles, unit);
        tiles.collider.gameObject.GetComponent<Renderer>().material.color = Color.yellow;
    }

/*    private void OnMouseDown()
    {
        Debug.Log("check");
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;
        if (Physics.Raycast(ray, out hit))
        {
            if (selectedObjectTile != hit.collider.gameObject
                && selectedObjectUnit != hit.collider.gameObject)
            {
                reverting(hit);
                if (Physics.Raycast(transform.position, Vector3.down, out hit) 
                    && hit.collider.gameObject.transform.parent.name != "units")
                {
                    Debug.Log(hit.collider.gameObject);
                    selectedObjectTile = hit.collider.gameObject;
                    selectedObjectUnit = gameObject;
                    Renderer renderer = tile(hit);
                    renderer.material.color = Color.yellow;
                    GetComponent<Renderer>().material.color = Color.black;
                }
                else if (Physics.Raycast(transform.position, Vector3.up, out hit)
                    && hit.collider.gameObject.transform.parent.name != "tiles")
                {
                    Debug.Log(hit.collider.gameObject);
                    
                    GetComponent<Renderer>().material.color = Color.yellow;
                    selectedObjectUnit = hit.collider.gameObject;
                    selectedObjectTile = gameObject;
                    Renderer renderer = tile(hit);
                    renderer.material.color = Color.black;
                    
                }
                else
                {
                    GetComponent<Renderer>().material.color = Color.cyan;
                    transform.Translate(transform.up * 0.2f);
                    selectedObjectTile = gameObject;
                    selectedObjectUnit = GameObject.Find("blank");
                }
                if(selectedObjectUnit != GameObject.Find("blank") 
                    && !selectedObjectUnit.GetComponent<unit_info>().canMove
                    && !selectedObjectUnit.GetComponent<unit_info>().extraMove)
                {
                    selectedObjectUnit.GetComponent<Renderer>().material.color = Color.cyan;
                }
            }
        }
    }*/

    private Renderer tile(RaycastHit hit, RaycastHit unit)
    {
        Renderer renderer = hit.transform.GetComponent<Renderer>();
        renderer.transform.Translate(renderer.transform.up * 0.2f);
        unit.transform.Translate(transform.up * 0.2f);
        GameObject tile = hit.collider.gameObject;
        clickingobject trial = tile.GetComponent<clickingobject>();
        if (!tile.CompareTag("blocker"))
        {
            selectedtile = true;
        }
        colliders = Physics.OverlapSphere(hit.collider.bounds.center, tileradius); // 5f is the radius
        tilecolidders.Clear();
        foreach (Collider collider in colliders)
        {
            clickingobject script = collider.gameObject.GetComponent<clickingobject>();
            if (!collider.gameObject.CompareTag("blocker") && script.selectedtile == false)
            {
                tilecolidders.Add(collider);
                Renderer renderer1 = collider.gameObject.GetComponent<Renderer>();
                script.possibletile = true;
                renderer1.material.color = Color.green;
                
                // Check if there is a unit on top of the collided object

/*                RaycastHit unitHit;
                if (Physics.Raycast(collider.transform.position, Vector3.up, out unitHit)
                    && collider.gameObject.transform.parent.name != "units" )
                {
                    // A unit is on top of the collided object
                    GameObject unit = unitHit.collider.gameObject;
                    // Perform actions with the unit object
                    renderer1.material.color = Color.red;
                }*/
            }
        }
        possibleHits(hit);
        return renderer;
    }



    private void possibleHits(RaycastHit hit)
    {
        float hitradius =0;
        float bufferradius = 0;
        if (selectedObjectUnit.GetComponent<unit_info>().Type == "hitter")
        {
             hitradius = tileradius;
        }
        if (selectedObjectUnit.GetComponent<unit_info>().Type == "mage")
        {
            hitradius = tileradius *2;
        }
        if (selectedObjectUnit.GetComponent<unit_info>().Type == "archer")
        {
            hitradius = tileradius *3;
            bufferradius = tileradius + .5f;
        }
        // Get all colliders intersecting with the sphere
        hitcolliders = Physics.OverlapSphere(hit.collider.bounds.center, hitradius);
        Debug.Log(bufferradius);
        // Exclude colliders within the buffer zone
        for (int i = 0; i < hitcolliders.Length; i++)
        {
            Vector3 colliderPosition = hitcolliders[i].transform.position;
            Vector3 sphereCenter = transform.position;
            float distance = Vector3.Distance(colliderPosition, sphereCenter);

            if (distance <= bufferradius)
            {
                Debug.Log(bufferradius);
                hitcolliders[i] = null;  // Remove the collider from the list
            }
        }

        // Process the remaining colliders (excluding the buffer zone)
        foreach (Collider collider in hitcolliders)
        {   
            if (collider != null && collider.gameObject.transform.parent.name != "units")
            {
                collider.gameObject.GetComponent<clickingobject>().possibleattacktile = true;
                Renderer renderer1 = collider.gameObject.GetComponent<Renderer>();
                RaycastHit unitHit;
                if (Physics.Raycast(collider.transform.position, Vector3.up, out unitHit)
                    && collider.gameObject.transform.parent.name != "units" 
                    && !collider.gameObject.CompareTag("blocker"))
                {   if (unitHit.collider.gameObject.transform.parent.name != "tiles")
                    {


                        if (web.user == unitHit.collider.gameObject.GetComponent<unit_info>().controller)
                        {
                            collider.gameObject.GetComponent<clickingobject>().possibleattacktile = false;
                        }
                        else
                        {
                            // A unit is on top of the collided object
                            GameObject unit = unitHit.collider.gameObject;
                            // Perform actions with the unit object
                            renderer1.material.color = Color.red;
                        }
                    }
                    /*                    for (int i = 0; i < load_game.player_turn.Count; i++)
                                        {
                                            if(load_game.player_turn[i] == collider.gameObject)
                                            {
                                                collider.gameObject.GetComponent<clickingobject>().possibleattacktile = false;
                                            }
                                            else
                                            {
                                                // A unit is on top of the collided object
                                                GameObject unit = unitHit.collider.gameObject;
                                                // Perform actions with the unit object
                                                renderer1.material.color = Color.red;
                                            }
                                        }*/
                }
            }
        }
    }

    public static void reverting(RaycastHit hit)
    {
        if (hitcolliders != null)
        {
            Debug.Log(hitcolliders.Length);
            foreach (Collider colliders in hitcolliders)
            {
                if (colliders != null)
                {


                    colliders.gameObject.GetComponent<clickingobject>().possibleattacktile = false;
                }
            }
        }
        Debug.Log(selectedObjectTile + " " + hit.collider.gameObject);
        selectedObjectTile.transform.Translate(selectedObjectTile.transform.up * -.2f);
        selectedObjectUnit.transform.Translate(selectedObjectUnit.transform.up * -.2f);
        if (tilecolidders.Count != 0)
        {
            foreach (Collider collider in tilecolidders)
            {
                if (collider != null)
                {


                    clickingobject script = collider.gameObject.GetComponent<clickingobject>();
                    if (collider.gameObject.transform.parent.name != "units"
                        && !collider.gameObject.CompareTag("blocker")
                        && script.selectedtile == false
                        && script.unitontile == false)
                    {
                        Renderer renderer1 = collider.gameObject.GetComponent<Renderer>();
                        script.possibletile = false;
                        renderer1.material.color = Color.white;
                    }
                    else if (script.unitontile == true && collider.gameObject.transform.parent.name != "units")
                    {
                        RaycastHit unitHit;
                        if (Physics.Raycast(collider.transform.position, Vector3.up, out unitHit))
                        {
                            if(unitHit.collider.gameObject.transform.parent.name == "units")
                            {
                            Renderer renderer1 = collider.gameObject.GetComponent<Renderer>();
                            script.possibletile = false;
                            Debug.Log("Unit above the tile: " + unitHit.collider.gameObject.name);
                            renderer1.material.color = unitHit.collider.gameObject.GetComponent<unit_info>().color;
                            }

                        }
                    }
                }
            }
            if (selectedObjectUnit == GameObject.Find("blank") && selectedObjectTile != GameObject.Find("blank"))
            {
                Renderer renderer1 = selectedObjectTile.GetComponent<Renderer>();
                renderer1.material.color = Color.white;
            }
            else if (selectedObjectUnit != GameObject.Find("blank") && selectedObjectTile != GameObject.Find("blank"))
            {
                Renderer renderer1 = selectedObjectTile.GetComponent<Renderer>();
                renderer1.material.color = selectedObjectUnit.gameObject.GetComponent<unit_info>().color;
            }
        }
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
