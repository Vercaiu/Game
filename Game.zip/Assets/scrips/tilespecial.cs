using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tilespecial : MonoBehaviour
{
    public  void leavingtile(GameObject tile, GameObject person)
    {
        if(tile.CompareTag("attacktile"))
        {
            attacktile(person, true);
        }
        if (tile.CompareTag("defensetile"))
        {
            defensetile(person, true);
        }
        if (tile.CompareTag("healthtile"))
        {
            healthtile(person, true);
        }
    }

    public void enteringtile(GameObject tile, GameObject person)
    {
        if (tile.CompareTag("attacktile"))
        {
            attacktile(person, false);
        }
        if (tile.CompareTag("defensetile"))
        {
            defensetile(person, false);
        }
        if (tile.CompareTag("healthtile"))
        {
            healthtile(person, false);
        }
    }

    private void attacktile(GameObject person, bool leaving)
    {
        if (leaving)
        {
            person.GetComponent<unit_info>().Attack -= 2;
            deathgraveyard.ispersondead(person);
        }
        else
        {
            person.GetComponent<unit_info>().Attack += 2;
        }
        
        
        stats_ui.setui(person);
    }

    private void defensetile(GameObject person, bool leaving)
    {
        if (leaving)
        {
            person.GetComponent<unit_info>().Defense -= 2;
            person.GetComponent<unit_info>().Defensemax -= 2;
            if(person.GetComponent<unit_info>().Defense < 0)
            {
                person.GetComponent<unit_info>().Defense = 0;
            }
            deathgraveyard.ispersondead(person);
        }
        else
        {
            person.GetComponent<unit_info>().Defense += 2;
            person.GetComponent<unit_info>().Defensemax += 2;
        }

        stats_ui.setui(person);
    }

    private void healthtile(GameObject person, bool leaving)
    {
        if (leaving)
        {
            person.GetComponent<unit_info>().Health -= 2;
            deathgraveyard.ispersondead(person);
        }
        else
        {
            person.GetComponent<unit_info>().Health += 2;
        }

        stats_ui.setui(person);
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
