using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gamemodeselect : MonoBehaviour
{
    public static int playeramount= 0;
    public static string gamemode = "none";

    public void twoffa()
    {
        playeramount = 2;
        gamemode = "FFA";
    }
    public void threeffa()
    {
        playeramount = 3;
        gamemode = "FFA";
    }
    public void fourffa()
    {
        playeramount = 4;
        gamemode = "FFA";
    }
    public void fiveffa()
    {
        playeramount = 5;
        gamemode = "FFA";
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
