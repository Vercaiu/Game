using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class moving : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }
    public clickingobject Clickingobject;
    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonUp(1))
        {
            if (clickingobject.selectedObjectUnit != GameObject.Find("blank"))
            {
                if (web.user == clickingobject.selectedObjectUnit.GetComponent<unit_info>().controller
                    && web.user == load_game.turn)
                {


                    unit_info mover = clickingobject.selectedObjectUnit.GetComponent<unit_info>();
/*                    if (!mover.canMove && !mover.extraMove)
                    {
                        Debug.Log("here? here?");
                    }*/

               //     else
                //    {
                        RaycastHit hit;
                        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                        if (Physics.Raycast(ray, out hit))
                        {
                            /*                    if (clickingobject.selectedObjectUnit != GameObject.Find("blank"))
                                                {*/
                            RaycastHit Hit1;
                            GameObject tilehit = hit.collider.gameObject;
                            clickingobject script = tilehit.GetComponent<clickingobject>();
                            if (hit.collider.gameObject.transform.parent.name == "units")
                            {
                                
                                Physics.Raycast(hit.collider.gameObject.transform.position, Vector3.down, out Hit1);
                                GameObject bottom = Hit1.collider.gameObject;
                                clickingobject bottom2 = bottom.GetComponent<clickingobject>();
                                if (bottom2.possibleattacktile == true)
                                {
                                    attack(Hit1, hit);
                                }
                            }
                            else if (hit.collider.gameObject.transform.parent.name == "tiles" && script.possibleattacktile == true
                                && Physics.Raycast(hit.collider.gameObject.transform.position, Vector3.up))
                            {
                                
                                Physics.Raycast(hit.collider.gameObject.transform.position, Vector3.up, out Hit1);
                                attack(hit, Hit1);
                            }
                            else if (tilehit.transform.parent.name == "tiles" && script.possibletile == true
                                && !Physics.Raycast(tilehit.transform.position, Vector3.up)
                                && mover.canMove || mover.extraMove)
                            {
                                
                                movings(hit, tilehit);
                            }
                            //}
                        }
                 //   }
                }
            }
        }
    }
    private void movings(RaycastHit hit, GameObject tilehit)
    {

        unit_info person = clickingobject.selectedObjectUnit.GetComponent<unit_info>();
        if(person.Type == "hitter" && !person.canMove)
        {
            Debug.Log("2");
            person.extraMove = false;
        }
        /*        if (!person.canMove &&
                    !person.extraMove)
                {
                    Debug.Log("3");
                }*/
        main.Instance.tilespecial.enteringtile(tilehit, clickingobject.selectedObjectUnit);
        main.Instance.tilespecial.leavingtile(clickingobject.selectedObjectTile, clickingobject.selectedObjectUnit);
        tilehit.GetComponent<clickingobject>().unitontile = true;
        clickingobject.selectedObjectTile.GetComponent<clickingobject>().unitontile = false;
        Vector3 center = tilehit.transform.position;
        float y = convertor.placeunitontile(clickingobject.selectedObjectUnit, tilehit);

        // Set the object's position using the center's x and z coordinates, and the calculated y value
        Vector3 newPosition = new Vector3(center.x, y, center.z);
        clickingobject.selectedObjectUnit.transform.position = newPosition;
        person.canMove = false;
        clickingobject.reverting(hit);
        clickingobject.selectedObjectUnit = GameObject.Find("blank");
        clickingobject.selectedObjectTile = GameObject.Find("blank");
    }


    private void attack(RaycastHit tile, RaycastHit person)
    {
        GameObject attacker = clickingobject.selectedObjectUnit.gameObject;
        unit_info attacker_stats = attacker.GetComponent<unit_info>();
        if (attacker_stats.canAttack)
        {


            GameObject tilehit = tile.collider.gameObject;
            Debug.Log(tilehit.transform.parent.name);

            // A unit is on top of the collided object
            GameObject opponent = person.collider.gameObject;
            // Perform actions with the unit object
            unit_info opponent_stats = opponent.GetComponent<unit_info>();
            if(opponent_stats.Defense >= attacker_stats.Attack)
            {
                opponent_stats.Defense -= attacker_stats.Attack;
            }
            else
            {
                opponent_stats.Health += opponent_stats.Defense - attacker_stats.Attack;
                opponent_stats.Defense = 0;
            }
            //opponent_stats.Health -= attacker_stats.Attack;
            attacker_stats.canAttack = false;
            stats_ui.setui(opponent);
            // unit_info mover = clickingobject.selectedObjectUnit.GetComponent<unit_info>();
            //    mover.canMove = false;
            deathgraveyard.ispersondead(opponent);
            clickingobject.reverting(tile);
            clickingobject.selectedObjectUnit = GameObject.Find("blank");
            clickingobject.selectedObjectTile = GameObject.Find("blank");


        }
    }
}
