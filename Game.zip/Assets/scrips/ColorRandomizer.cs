using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColorRandomizer : MonoBehaviour
{
    public static List<Color> excludedColors = new List<Color>(); // List of colors to exclude



    public static Color SetRandomColor()
    {
        // Generate a random color
        Color randomColor = GetRandomColor();

        // Check if the random color is in the list of excluded colors
        while (IsColorExcluded(randomColor))
        {
            randomColor = GetRandomColor(); // Generate a new random color
        }

        // Apply the random color to the object's material
        return randomColor;
    }

    private static Color GetRandomColor()
    {
        // Generate random values for red, green, and blue channels
        float r = Random.Range(0f, 1f);
        float g = Random.Range(0f, 1f);
        float b = Random.Range(0f, 1f);

        return new Color(r, g, b);
    }

    private static bool IsColorExcluded(Color color)
    {
        // Check if the provided color matches any of the excluded colors
        foreach (Color excludedColor in excludedColors)
        {
            if (color == excludedColor)
            {
                return true;
            }
        }
        return false;
    }
}
