using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player_login : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void setdeck()
    {
        Debug.Log("test test test");//https://lone-child.000webhostapp.com/getDecks.php
        StartCoroutine(main.Instance.web.Upload(web.user, "none!", "none!", "http://localhost/lone_child/getDecks.php"));
    
    }

    public void pickHero()
    {
        Debug.Log("test test test");//https://lone-child.000webhostapp.com/Get_Hero.php
        StartCoroutine(main.Instance.web.Upload(2 + "", "none!", "none!", "http://localhost/lone_child/Get_Hero.php"));
    }

    public void getuserinfo()
    {//https://lone-child.000webhostapp.com/userinfo.php
        StartCoroutine(main.Instance.web.Upload(web.user, "none!", "none!", "http://localhost/lone_child/userinfo.php"));

        //NEED TO MAKE IT WHERE YOU GET ALL DECKS AT THE START.
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
