using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class main : MonoBehaviour
{
    public static main Instance;

    public web web;
    public user_info UserInfo;
    public login Login;
    public items items;
    public Canvas Canvas;
    public createmap createmap;
    public  decks decks;
    public  unit_info unit_Info;
    public Canvascontroller Canvascontroller;
    public creategame_ui creategame_Ui;
    public creategame creategame;
    public tilespecial tilespecial;
    public Maps maps;

    public GameObject userprofile;
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log(items);
        Instance = this;
        web = GetComponent<web>();
        UserInfo = GetComponent<user_info>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
