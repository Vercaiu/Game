using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class species : MonoBehaviour
{
    public string human = "cost 1 less for each ally creature that is not a human";
    public string wisp = "gains +1 +1 each time armor is attached";
    public string mutants = "loses 1 health each turn";
    
    public static void humanabilitygain(unit_info script)
    {
        Debug.Log("what is happening");
        if (script.Species != "Human")
        {
            Transform parentTransform = GameObject.Find("Canvas-gameplay").transform;
            Transform cards = parentTransform.Find("cards");
            for (int i = 0; i < cards.childCount; i++)
            {
                if (cards.GetChild(i).gameObject.GetComponent<unit_info>().Species == "Human")
                {
                    cards.GetChild(i).gameObject.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text= (int.Parse(cards.GetChild(i).gameObject.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text)-1).ToString();
                if(int.Parse(cards.GetChild(i).gameObject.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text) < 0)
                    {
                        cards.GetChild(i).gameObject.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = "0";
                    }
                    cards.GetChild(i).gameObject.GetComponent<unit_info>().mojo = int.Parse(cards.GetChild(i).gameObject.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text);
                }
            }
        }
    }

    public static void humanabilitylost(unit_info script)
    {
        if (script.Species == "Human")
        {
            Transform parentTransform = GameObject.Find("Canvas-gameplay").transform;
            Transform cards = parentTransform.Find("cards");
            for (int i = 0; i < cards.childCount; i++)
            {
                if (cards.GetChild(i).gameObject.GetComponent<unit_info>().Species == "Human")
                {
                    cards.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text = (int.Parse(cards.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text) + 1).ToString();
                    cards.GetComponent<unit_info>().mojo = int.Parse(cards.transform.Find("Mojo").GetComponent<TextMeshProUGUI>().text);
                }
            }
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
