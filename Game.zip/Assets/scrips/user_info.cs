using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class user_info : MonoBehaviour
{
    public static int rank1;
    public static int rank2;
    public static int rank3;
    public static int rank4;
    public static int level;
    public static int exp;

    public void userinfobutton()
    {
        Transform canvas = GameObject.Find("Canvas-userinfo").transform;
        Transform background = canvas.Find("background").transform;
        background.Find("exp").gameObject.GetComponent<TextMeshProUGUI>().text = "exp: " + exp;
        background.Find("level").gameObject.GetComponent<TextMeshProUGUI>().text = "level: " + level;
        background.Find("rank1").gameObject.GetComponent<TextMeshProUGUI>().text = "rank1: " + rank1;
        background.Find("rank2").gameObject.GetComponent<TextMeshProUGUI>().text = "rank2: " + rank2;
        background.Find("rank3").gameObject.GetComponent<TextMeshProUGUI>().text = "rank3: " + rank3;
        background.Find("rank4").gameObject.GetComponent<TextMeshProUGUI>().text = "rank4: " + rank4;
    }

    public string UserID { get; private set; }
     string UserName;
     string Password;

    public void SetCredentials(string username, string password)
    {
        UserName = username;
        Password = password;
    }
    public void setID(string id)
    {
        UserID = id;
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
