using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cleanup : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public static void cleancards(Transform parenttransform)
    {
        for (int i = 0; i < parenttransform.childCount; i++)
        {
            Destroy(parenttransform.GetChild(i).gameObject);
        }
    }

    public static void cleanupgameplay()
    {
        Transform parentTransform = GameObject.Find("units").transform;
        for (int i = 0; i < parentTransform.childCount; i++)
        {
            Destroy(parentTransform.GetChild(i).gameObject);
        }
        Transform tiles = GameObject.Find("tiles").transform;
        for (int i = 0; i < tiles.childCount; i++)
        {
            Destroy(tiles.GetChild(i).gameObject);
        }
        Transform parent = GameObject.Find("Canvas-gameplay").transform;
        Transform cards = parent.Find("cards").transform;
        cleancards(cards);
        Transform parent2 = GameObject.Find("Canvas-gameplay").transform;
        Transform discarded = parent2.Find("discarded").transform;
        for (int i = 0; i < discarded.childCount; i++)
        {
            Destroy(discarded.GetChild(i).gameObject);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
