using System.Collections;
using System.Collections.Generic;
using SimpleJSON;
using UnityEngine;
using UnityEngine.Networking;

public class web : MonoBehaviour
{
    public static string user;
    void Start()
    {
        // A correct website page.
        StartCoroutine(GetRequest("http://lone-child.000webhostapp.com/GetDate.php"));
        StartCoroutine(GetRequest("http://lone-child.000webhostapp.com/Gettiles.php"));
        StartCoroutine(GetRequest("http://localhost/lone_child/Gettiles.php"));
        //   StartCoroutine(GetRequest("https://lone-child.000webhostapp.com/getDeck.php"));
        // StartCoroutine(main.Instance.web.GetDeck());
    }

    /*public void ShowUserItems()
    {
        StartCoroutine(GetItemsID(main.Instance.UserInfo.UserID));
    } */

    public IEnumerator GetRequest(string uri)
    {
        using (UnityWebRequest webRequest = UnityWebRequest.Get(uri))
        {
            // Request and wait for the desired page.
            yield return webRequest.SendWebRequest();

            string[] pages = uri.Split('/');
            int page = pages.Length - 1;

            switch (webRequest.result)
            {
                case UnityWebRequest.Result.ConnectionError:
                case UnityWebRequest.Result.DataProcessingError:
                    Debug.LogError(pages[page] + ": Error: " + webRequest.error);
                    break;
                case UnityWebRequest.Result.ProtocolError:
                    Debug.LogError(pages[page] + ": HTTP Error: " + webRequest.error);
                    break;
                case UnityWebRequest.Result.Success:
                    Debug.Log(pages[page] + ":\nReceived: " + webRequest.downloadHandler.text);
                    break;
            }
        }
    }
    public IEnumerator Upload(string username, string password, string thirdoption, string website)
    {
        WWWForm form = new WWWForm();
        if(username != "none!")
        {
            form.AddField("loginUser", username);
        }
        if(password != "none!")
        {
            form.AddField("loginPass", password);
        }
        if (thirdoption != "none!")
        {
            Debug.Log(thirdoption);
            form.AddField("thirdoption", thirdoption);
        }

        using UnityWebRequest www = UnityWebRequest.Post(website, form);
        yield return www.SendWebRequest();

        if (www.result != UnityWebRequest.Result.Success)
        {
            Debug.Log(www.error);
        } //https://lone-child.000webhostapp.com/login.php https://lone-child.000webhostapp.com/createAccount.php
        else if ("http://localhost/lone_child/login(1).php" == website || "http://localhost/lone_child/createAccount.php" == website)
        {
            /*                StartCoroutine(GetDeck(username));*/
            main.Instance.UserInfo.SetCredentials(username, password);
            main.Instance.UserInfo.setID(www.downloadHandler.text);
            if (www.downloadHandler.text.Contains("wrong credentials.") ||
                www.downloadHandler.text.Contains("0 results, no username matches") ||
                www.downloadHandler.text.Contains("that user already exists"))
            {
                Debug.Log("try again");
            }
            else
            {
                player_login player_login = GameObject.FindObjectOfType<player_login>();
                user = username;
                player_login.setdeck();
                player_login.pickHero();
                player_login.getuserinfo();
                //  StartCoroutine(main.Instance.web.GetDeck(username));
                main.Instance.userprofile.SetActive(true);
                main.Instance.Login.gameObject.SetActive(false);
                main.Instance.Canvascontroller.gotoMain();
                main.Instance.items.CreateItems();
                //   yield return StartCoroutine(main.Instance.web.Upload(username, "none!", "https://lone-child.000webhostapp.com/getDeck.php"));
            }
        }//https://lone-child.000webhostapp.com/setdeck.php
        else if ("http://localhost/lone_child/setdeck.php" == website)
        {
            Debug.Log(www.downloadHandler.text);
        }//https://lone-child.000webhostapp.com/getDeck.php
        else if ("http://localhost/lone_child/getDeck.php" == website)
        {
            /*            Debug.Log(www.downloadHandler.text);
                        string jsonArrays = www.downloadHandler.text;
                        StartCoroutine(main.Instance.decks.decodeDeck(jsonArrays));*/

            List<string> test = jsonConverter(www.downloadHandler.text);
            decks.deck = test[0];
            deckpage deckpage = GameObject.FindObjectOfType<deckpage>();
            deckpage.getcards();
            Debug.Log(www.downloadHandler.text);
        }//https://lone-child.000webhostapp.com/getDecks.php
        else if ("http://localhost/lone_child/getDecks.php" == website)
        {
            /*            Debug.Log(www.downloadHandler.text);
                        string jsonArrays = www.downloadHandler.text;
                        StartCoroutine(main.Instance.decks.decodeDeck(jsonArrays));*/

            List<string> test = jsonConverter(www.downloadHandler.text);
            decks.deck = test[0];
            decks.deck1 = test[0];
            decks.deck2 = test[1];
            decks.deck3 = test[2];
            Debug.Log(www.downloadHandler.text);
        }
        else if ("http://localhost/lone_child/Get_units.php" == website)
        {
            Debug.Log(www.downloadHandler.text);
            deckpage.deck = multijsonConverter(www.downloadHandler.text);
            Transform transform = GameObject.Find("rectdect").transform;
            cleanup.cleancards(transform);
            convertor.gettingcards(deckpage.deck, "rectdect");
            Debug.Log(deckpage.deck.Count);
        }//https://lone-child.000webhostapp.com/createAccount.php
        else if ("http://localhost/lone_child/createAccount.php" == website)
        {
            user = username;
            main.Instance.Canvascontroller.gotoMain();
        }//https://lone-child.000webhostapp.com/creategame.php
        else if ("http://localhost/lone_child/creategame.php" == website
            && !www.downloadHandler.text.Contains("Cannot create more"))
        {
            Debug.Log("first");
            creategame_ui.creategameswitch = true;
            Debug.Log(www.downloadHandler.text);
            List<string> num = new List<string>();
            num = jsonConverter(www.downloadHandler.text);
            creategame_ui.gamenum = int.Parse(num[0]);
        }//https://lone-child.000webhostapp.com/createpreviousgames.php
        else if ("http://localhost/lone_child/createpreviousgames.php" == website)
        {
            Debug.Log("test");
            List<string> num = new List<string>();
            num = jsonConverter(www.downloadHandler.text);
            creategame_ui.games = num;
            Debug.Log(www.downloadHandler.text);
        }//https://lone-child.000webhostapp.com/addtopreviousgame.php
        else if("http://localhost/lone_child/addtopreviousgame.php" == website
             && !www.downloadHandler.text.Contains("already in game"))
        {
            Debug.Log(www.downloadHandler.text);
            creategame_ui.joingameswitch = true;
        }//https://lone-child.000webhostapp.com/createdgameinfo.php
        else if("http://localhost/lone_child/createdgameinfo.php" == website)
        {
            Debug.Log(www.downloadHandler.text);
            StartCoroutine(SaveGame.savinggamefirst(www.downloadHandler.text));
        }//https://lone-child.000webhostapp.com/createtruegame.php
        else if("http://localhost/lone_child/createtruegame.php" == website)
        {
            
            Debug.Log(www.downloadHandler.text);
            SaveGame.gamenum = int.Parse(www.downloadHandler.text);
            StartCoroutine(main.Instance.web.Upload(SaveGame.gamenum + "", "none!", "none!", "http://localhost/lone_child/loadgame.php"));
        }//https://lone-child.000webhostapp.com/loadedgames.php
        else if ("http://localhost/lone_child/loadedgames.php" == website)
        {
            Debug.Log(www.downloadHandler.text);
            load_game.loaded_info =jsonConverter(www.downloadHandler.text);
        }//https://lone-child.000webhostapp.com/loadgame.php
        else if ("http://localhost/lone_child/loadgame.php" == website)
        {
            load_game load_game = GameObject.FindObjectOfType<load_game>();
            load_game.loadgame(jsonConverter(www.downloadHandler.text));
        }//https://lone-child.000webhostapp.com/Get_Hero.php
        else if ("http://localhost/lone_child/Get_Hero.php" == website)
        {
            Debug.Log(www.downloadHandler.text);
            decks.hero = jsonConverter(www.downloadHandler.text);
        }//https://lone-child.000webhostapp.com/getcardinfo.php
        else if ("http://localhost/lone_child/getcardinfo.php" == website)
        {
            if(load_game.deckbool == true)
            {
                Debug.Log(www.downloadHandler.text);
                load_game.deckbool = false;
                List<string> num = new List<string>();
                num = multijsonConverter(www.downloadHandler.text);
                load_game.deckinfo = num;
            }
            else if (load_game.graveyardbool == true)
            {
                Debug.Log(www.downloadHandler.text);
                load_game.graveyardbool = false;
                load_game.graveyardinfo = multijsonConverter(www.downloadHandler.text);
            }
            else if (load_game.handbool == true)
            {
                Debug.Log(www.downloadHandler.text);
                load_game.handbool = false;
                load_game.handinfo = multijsonConverter(www.downloadHandler.text);
                convertor.gettingcards(load_game.handinfo, "cards");
                
                Debug.Log(load_game.turn);
                if (load_game.turn == web.user)
                {
                    newturn newturn = GameObject.FindObjectOfType<newturn>();
                    newturn.startturn();
                }
            }
        }//https://lone-child.000webhostapp.com/updatesavegame.php
        else if("http://localhost/lone_child/updatesavegame.php" == website)
        {
            Debug.Log(www.downloadHandler.text);
        }//https://lone-child.000webhostapp.com/recieved_losses.php
        else if ("http://localhost/lone_child/recieved_losses.php" == website)
        {
            Debug.Log(www.downloadHandler.text);
        }//https://lone-child.000webhostapp.com/recieved_wins.php
        else if ("http://localhost/lone_child/recieved_wins.php" == website)
        {
            nextturn nextturn = GameObject.FindObjectOfType<nextturn>();
            nextturn.cleanups();
            Debug.Log(load_game.currentloadednum);
            Debug.Log(www.downloadHandler.text);
        }//https://lone-child.000webhostapp.com/userinfo.php
        else if ("http://localhost/lone_child/userinfo.php" == website)
        {
            Debug.Log(www.downloadHandler.text);
            List<string> info = jsonConverter(www.downloadHandler.text);
            user_info.exp = int.Parse(info[0]);
            user_info.level = int.Parse(info[1]);
            user_info.rank1 = int.Parse(info[2]);
            user_info.rank2 = int.Parse(info[3]);
            user_info.rank3 = int.Parse(info[4]);
            user_info.rank4 = int.Parse(info[5]);
        }//https://lone-child.000webhostapp.com/availablecards.php
        else if ("http://localhost/lone_child/availablecards.php" == website)
        {
            Debug.Log(www.downloadHandler.text);

            deckpage.cards = multijsonConverter(www.downloadHandler.text);

            convertor.gettingcards(deckpage.cards, "rectall_cards");
        }
    }
    public IEnumerator GetItemsID(string userID, System.Action<string> callback)
    {
        WWWForm form = new WWWForm();
        form.AddField("userID", userID);
        using (UnityWebRequest www = UnityWebRequest.Post("http://lone-child.000webhostapp.com/getitemsid.php", form))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }
            else
            {
                Debug.Log(www.downloadHandler.text);
                string jsonArray = www.downloadHandler.text;
                Debug.Log(jsonArray);
                StartCoroutine(main.Instance.items.CreateItemsRoutine(jsonArray));
            }
        }
    }
    public IEnumerator GetItems(string itemid, System.Action<string> callback)
    {
        WWWForm form = new WWWForm();
        form.AddField("itemID", itemid);
        using (UnityWebRequest www = UnityWebRequest.Post("http://lone-child.000webhostapp.com/getitem.php", form))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }
            else
            {
                Debug.Log(www.downloadHandler.text);
                string jsonArray = www.downloadHandler.text;

                callback(jsonArray);
            }
        }
    }
    public IEnumerator Gettiles()
    {
        using (UnityWebRequest www = UnityWebRequest.Get("http://lone-child.000webhostapp.com/Gettiles.php"))
        {
            yield return www.SendWebRequest();
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }
            else
            {
                string jsonArray = www.downloadHandler.text;
                StartCoroutine(main.Instance.createmap.mapMaker(jsonArray));
            }
        }
    }
/*    public IEnumerator GetDeck(string username)
    {
                Debug.Log(username);
                WWWForm form = new WWWForm();
                form.AddField("loginUser", username);
        using (UnityWebRequest www = UnityWebRequest.Get("https://lone-child.000webhostapp.com/getDeck.php"))
        {
            Debug.Log("test");
            yield return www.SendWebRequest();
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }
            else
            {
                Debug.Log(www.downloadHandler.text);
                string jsonArrays = www.downloadHandler.text;
                StartCoroutine(main.Instance.decks.decodeDeck(jsonArrays));
            }
        }
    }

    public IEnumerator insertUnits(string query)
    {
        WWWForm form = new WWWForm();
        form.AddField("querys", query);
        using (UnityWebRequest www = UnityWebRequest.Get("https://lone-child.000webhostapp.com/Get_units.php"))
        {
            yield return www.SendWebRequest();
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }
            else
            {
                string jsonArrays = www.downloadHandler.text;
                Debug.Log(jsonArrays);
                StartCoroutine(main.Instance.decks.GetRightDeck(jsonArrays));
            }
        }
    }*/
    public List<string> jsonConverter(string jsonArrayString)
    {
        JSONArray jsonarray = JSON.Parse(jsonArrayString) as JSONArray;
        List<string> valuesList = new List<string>();
        foreach (JSONNode node in jsonarray)
        {
            foreach (KeyValuePair<string, JSONNode> kvp in node)
            {
                string value = kvp.Value;
                valuesList.Add(value);
            }
        }
        return valuesList;
    }
    public List<string> multijsonConverter(string jsonArrayString)
    {
        List<string> valuesList = new List<string>();

        JSONNode json = JSON.Parse(jsonArrayString);
        JSONArray queryResults = json["query_results"].AsArray;

        // Check if the query_results array exists and has elements
        if (queryResults != null && queryResults.Count > 0)
        {
            // Loop through each array in queryResults
            foreach (JSONArray resultArray in queryResults)
            {
                // Loop through each element in the resultArray
                foreach (JSONNode resultObject in resultArray)
                {
                    // Loop through the key-value pairs of the resultObject
                    foreach (KeyValuePair<string, JSONNode> kvp in resultObject.AsObject)
                    {
                        string value = kvp.Value.ToString();
                        valuesList.Add(value);
                    }
                }
            }
        }
        else if (queryResults != null && queryResults.Count == 1)
        {
            // Only a single array in query_results
            JSONArray resultArray = queryResults[0].AsArray;

            // Loop through each element in the resultArray
            foreach (JSONNode resultObject in resultArray)
            {
                // Loop through the key-value pairs of the resultObject
                foreach (KeyValuePair<string, JSONNode> kvp in resultObject.AsObject)
                {
                    string value = kvp.Value.ToString();
                    valuesList.Add(value);
                }
            }
        }

        Debug.Log(valuesList.Count);
        return valuesList;
    }
}
