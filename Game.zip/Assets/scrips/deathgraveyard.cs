using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class deathgraveyard : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public static void ispersondead(GameObject person)
    {
        unit_info opponent_stats = person.GetComponent<unit_info>();
        if (opponent_stats.Health <= 0)
        {
            endofgame endofgame = GameObject.FindObjectOfType<endofgame>();
            endofgame.isherodead(opponent_stats, person.GetComponent<unit_info>().controller, "FFA");
            Debug.Log(person.transform.parent.name);
            Destroy(person);
            //  movings(tile, tilehit);
        }
        string controller = opponent_stats.controller;
        graveyard(opponent_stats.key, controller);
    }

    public static void graveyard(int key, string controller)
    {
        for (int i = 0; i < load_game.people.Count; i++)
        {
            if (load_game.people[i][0] == web.user)
            {
                load_game.graveyardorder.Add(key);

                break;
            }
            if (load_game.people[i][0] == controller)
            {
                if (load_game.people[i][2] == "")
                {
                    load_game.people[i][2] += key;
                }
                else
                {
                    load_game.people[i][2] += "," + key;
                }
                break;
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
