using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClickableObject : MonoBehaviour
{
    public Vector3 originalPosition;
    private static GameObject currentObject;

    void Start()
    {
        originalPosition = transform.position;
        gameObject.tag = "ClickableObject";
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            RaycastHit hit;
            if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit))
            {
                GameObject obj = hit.collider.gameObject;
                if (obj.tag == "ClickableObject")
                {
                    // Deselect the current object if one is selected
                    if (currentObject != null)
                    {
                        currentObject.transform.position = currentObject.GetComponent<ClickableObject>().originalPosition;
                    }
                    // Select the new object and move it to a new position
                    currentObject = obj;
                    obj.transform.position = new Vector3(0, 1, 0);
                }
            }
        }
    }
}

