using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ui_game : MonoBehaviour
{
/*    public float rotationSpeed = 10f;

    private bool isRotating = false;
    private float moveSpeed = 15.0f;
    private Vector3 moveVector;
    private bool isFlipped = false;
    private Quaternion targetRotation;*/

    public void RotateCamera()
    {
/*        if (!isRotating)
        {
            isRotating = true;
            Invoke("StopRotation", 1f); // Rotate for 1 second
        }*/
    }
    public void Flip()
    {
        // Get the current MyCamera rotation
        Quaternion currentRotation = transform.rotation;

        // Calculate the flipped rotation by adding 180 degrees to the Y-axis rotation
        Quaternion flippedRotation = Quaternion.Euler(currentRotation.eulerAngles.x, currentRotation.eulerAngles.y + 30f, currentRotation.eulerAngles.z);

        // Apply the flipped rotation to the MyCamera
        transform.rotation = flippedRotation;
    }
    // Start is called before the first frame update
    void Start()
    {
/*        moveVector = Vector3.zero;
        targetRotation = transform.rotation;*/
    }

    // Update is called once per frame
    void Update()
    {
/*        // Get the raw input values for horizontal and vertical axes
        float horizontalInput = Input.GetAxisRaw("Horizontal");
        float verticalInput = Input.GetAxisRaw("Vertical");

        // Adjust the input values based on the flipped state
        if (isFlipped)
        {
            horizontalInput *= -1f;
            verticalInput *= -1f;
        }

        // Update the moveVector based on the adjusted input values
        moveVector.x = horizontalInput;
        moveVector.z = verticalInput;

        // Check if there is any movement input
        if (moveVector != Vector3.zero)
        {
            // Rotate the MyCamera towards the target rotation
            Quaternion currentRotation = transform.rotation;
            transform.rotation = Quaternion.RotateTowards(currentRotation, targetRotation, Time.deltaTime * 100f);

            // Move the MyCamera based on the adjusted moveVector
            transform.position += moveSpeed * moveVector.normalized * Time.deltaTime;
        }
*/
    }
/*    private void StopRotation()
    {
        isRotating = false;
        transform.eulerAngles = new Vector3(transform.eulerAngles.x, 180f, transform.eulerAngles.z);
    }*/
}
