using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Canvascontroller : MonoBehaviour
{
    public Canvas Main;
    public Canvas gameplay;
    public Button Gameplaybutton;
    public Button Mainbutton;
    public Canvas decks;
    public Button Decksbutton;
    public static Canvas CurrentCanvas { get; set; }//probably use this instead of repeating.
    public Canvas createuser;
    public Canvas makegame;
    public Canvas profile;
    // Start is called before the first frame update

    public void gotoMain()
    {
        DisableChildElements(gameplay.gameObject);
        DisableChildElements(decks.gameObject);
        DisableChildElements(createuser.gameObject);
        DisableChildElements(makegame.gameObject);
        DisableChildElements(profile.gameObject);
        EnableAllElements(Main.gameObject);
        CurrentCanvas = Main;
    }
    public void gotoDecks()
    {
        DisableChildElements(gameplay.gameObject);
        DisableChildElements(Main.gameObject);
        DisableChildElements(createuser.gameObject);
        DisableChildElements(makegame.gameObject);
        EnableAllElements(decks.gameObject);
        CurrentCanvas = decks;
    }
    public void gotoGame()
    {
        DisableChildElements(Main.gameObject);
        DisableChildElements(decks.gameObject);
        DisableChildElements(createuser.gameObject);
        DisableChildElements(makegame.gameObject);
        EnableAllElements(gameplay.gameObject);
        GameObject Canvas = GameObject.Find("Canvas-gameplay");
        Canvas canvas = Canvas.GetComponent<Canvas>();
        CurrentCanvas = gameplay;
        canvas.transform.Find("must_discard").gameObject.GetComponent<TextMeshProUGUI>().enabled = false;
        DisableChildElements(canvas.transform.Find("enhanced_card").gameObject);
        
    }
    public void gotocreateuser()
    {
        DisableChildElements(gameplay.gameObject);
        DisableChildElements(decks.gameObject);
        DisableChildElements(Main.gameObject);
        DisableChildElements(makegame.gameObject);
        EnableAllElements(createuser.gameObject);
        CurrentCanvas = createuser;
    }
    public void gotomakegame()
    {
        DisableChildElements(gameplay.gameObject);
        DisableChildElements(decks.gameObject);
        DisableChildElements(Main.gameObject);
        DisableChildElements(createuser.gameObject);
        EnableAllElements(makegame.gameObject);
        CurrentCanvas = makegame;
    }

    public void gotologin()
    {
        main.Instance.Login.gameObject.SetActive(true);
    }
    
    public void gotoprofile()
    {
        EnableAllElements(profile.gameObject);
        DisableChildElements(Main.gameObject);
        CurrentCanvas = profile;
    }

    public static void DisableChildElements(GameObject parentObject)
    {
        DisableChildElementss(parentObject);
    }

    private static void DisableChildElementss(GameObject parentObject)
    {
        // Get all child GameObjects of the parentObject
        GameObject[] childObjects = new GameObject[parentObject.transform.childCount];
        for (int i = 0; i < parentObject.transform.childCount; i++)
        {
            childObjects[i] = parentObject.transform.GetChild(i).gameObject;
        }

        // Disable components on all child GameObjects
        foreach (GameObject childObject in childObjects)
        {
            if (childObject.TryGetComponent(out Graphic graphic))
            {
                graphic.enabled = false;
            }
            if (childObject.TryGetComponent(out Button button))
            {
                button.enabled = false;
            }
            if (childObject.TryGetComponent(out Image image))
            {
                image.enabled = false;
            }
            // Add more components to disable if needed (e.g., Text, etc.)

            // Recursively disable children of the childObject
            DisableChildElements(childObject);
        }
    }

    public static void EnableAllElements(GameObject parentObject)
    {
        EnableChildElements(parentObject);
    }

    private static void EnableChildElements(GameObject parentObject)
    {
        // Get all child GameObjects of the parentObject
        GameObject[] childObjects = new GameObject[parentObject.transform.childCount];
        for (int i = 0; i < parentObject.transform.childCount; i++)
        {
            childObjects[i] = parentObject.transform.GetChild(i).gameObject;
        }

        // Enable components on all child GameObjects
        foreach (GameObject childObject in childObjects)
        {
            if (childObject.TryGetComponent(out Graphic graphic))
            {
                graphic.enabled = true;
            }
            if (childObject.TryGetComponent(out Button button))
            {
                button.enabled = true;
            }
            if (childObject.TryGetComponent(out Image image))
            {
                image.enabled = true;
            }
            // Add more components to enable if needed (e.g., Text, etc.)

            // Recursively enable children of the childObject
            EnableChildElements(childObject);
        }
    }
    void Start()
    {
        gotoMain();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
