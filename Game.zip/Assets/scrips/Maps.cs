using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Maps : MonoBehaviour
{   public static int[] Map1 = new int[] {0
    ,1,0,1,0,0,0
    ,0,1,0,0,1,1,1,1,0,1,1,0
    ,0,1,1,0,0,0,0,0,1,1,1,1,0,0,1,0,1,0
    ,0,1,1,1,1,1,1,1,1,1,0,0,0,0,1,0,0,1,0,0,0,0,0,0
    ,0,0,0,0,0,0,0,0,0,1,0,1,1,1,1,1,0,0,0,0,0,0,1,1,1,0,0,0,0,1
    ,0,1,0,1,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0
    ,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    ,5,19,25,64,93,53,55}; //test
    // Start is called before the first frame update
    public static int[] Map2 = new int[] {0
    ,0,0,0,0,0,0
    ,1,0,0,0,1,0,0,0,1,0,0,0
    ,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1
    ,1,1,1,0,0,1,1,0,1,1,1,0,0,1,1,0,1,1,1,0,0,1,1,0
    ,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    ,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0
    ,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    ,126, 114, 102, 1000,1000,1000,1000}; //3players

    public static int[] Map3 = new int[] {1
    ,0,1,0,1,0,1
    ,0,0,0,0,0,0,0,0,0,0,0,0
    ,0,1,3,0,1,0,0,1,3,0,1,0,0,1,3,0,1,0
    ,1,1,0,1,0,2,2,0,1,1,0,1,0,2,2,0,1,1,0,1,0,2,2,0
    ,0,0,0,0,0,0,1,2,1,0,0,1,0,0,0,0,0,0,0,0,0,1,2,1,0,0,1,0,0,0
    ,0,2,0,1,1,1,0,3,0,1,1,1,0,2,0,1,1,1,0,3,0,1,1,1,0,2,0,1,1,1,0,3,0,1,1,1
    ,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    ,123,105,1000,1000,1000,1000,1000
    }; //2players

    public GameObject[] tilesarray;
    public GameObject[] unitsarray;
    public double currentx = 0;
    public double currentz = 0;
    private int count = 0;
    public static int player_count = 6;
    private int current_count = 0;
    private List<string> savedgamedata;
    // Start is called before the first frame update
    public int value;
    public override string ToString()
    {
        return "MyClass - value: " + value.ToString();
    }

    public void mapMaker(List<string> data)
    {
        newturn.units.Clear();
        savedgamedata = data;
        player_count = int.Parse(data[data.Count - 1]);
        count = 0;
        int[] valuesArray = new int[Map2.Length];
        if (player_count == 2)
        {
            List<int[]> p2 = new List<int[]>();
            p2.Add(Map3);
            int p = UnityEngine.Random.Range(0, 1);
            Array.Copy(Map3, valuesArray, Map3.Length);
            Debug.Log(Map3.Length);
        }
        else if (player_count == 3)
        {
            List<int[]> p2 = new List<int[]>();
            p2.Add(Map2);
            int p = UnityEngine.Random.Range(0, 1);
            Array.Copy(Map2, valuesArray, Map2.Length);
        }
        else
        {
            List<int[]> p2 = new List<int[]>();
            p2.Add(Map1);
            int p = UnityEngine.Random.Range(0, 1);
            Array.Copy(Map1, valuesArray, Map1.Length);
        }
        GameObject tiled = Instantiate(tilesarray[valuesArray[count]], new Vector3((float).85, 0, (float)-1.5), tilesarray[valuesArray[count]].transform.rotation, GameObject.Find("tiles").transform);
        MyCamera.centerOfMap = tiled.transform;
        place_unit(count, valuesArray, tiled);
        tiled.GetComponent<clickingobject>().tiledigit = valuesArray[count];
        ++count;
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < i; j++)
            {
                // Debug.Log(count);
                currentz += -1.5;
                currentx += -.85;
                place_tileandunit(valuesArray);
            }
            for (int k = 0; k < i; k++)
            {
                //  Debug.Log(count);
                currentz += 0;
                currentx += -1.7;
                place_tileandunit(valuesArray);
            }
            for (int k = 0; k < i; ++k)
            {
                //  Debug.Log(count);
                currentz += 1.5;
                currentx += -.85;
                place_tileandunit(valuesArray);
            }
            for (int k = 0; k < i; ++k)
            {
                currentz += 1.5;
                currentx += .85;
                place_tileandunit(valuesArray);
            }
            for (int k = 0; k < i; ++k)
            {
                // Debug.Log(count);
                currentz += 0;
                currentx += 1.7;
                place_tileandunit(valuesArray);
            }
            for (int k = 0; k < (i - 1); ++k)
            {
                // Debug.Log(count);
                currentz += -1.5;
                currentx += .85;
                place_tileandunit(valuesArray);
            }
            for (int k = 0; k < 1; ++k)
            {
                if (count <= 160)
                {
                    currentz += -1.5;
                    currentx += .85;
                    currentx += 1.7;
                    place_tileandunit(valuesArray);
                }
                else
                {
                    break;
                }
            }
        }
        MyCamera mycamera = GameObject.FindObjectOfType<MyCamera>();
        mycamera.cameraposition();
    }
    private void place_tileandunit(int[] valuesArray)
    {
        GameObject tile = Instantiate(tilesarray[valuesArray[count]], new Vector3((float)currentx, 0, (float)currentz), tilesarray[valuesArray[count]].transform.rotation, GameObject.Find("tiles").transform);
        place_unit(count, valuesArray, tile);
        tile.GetComponent<clickingobject>().tiledigit = valuesArray[count];
        ++count;
    }
    private void place_unit(int count, int[] valuesArray, GameObject newtile)
    {
        if ((count == valuesArray[valuesArray.Length - 7] ||
            count == valuesArray[valuesArray.Length - 6] || count == valuesArray[valuesArray.Length - 5] ||
            count == valuesArray[valuesArray.Length - 4] || count == valuesArray[valuesArray.Length - 3] ||
            count == valuesArray[valuesArray.Length - 2] || count == valuesArray[valuesArray.Length - 1])
            && current_count < player_count)
        {
            string[] value = savedgamedata[(current_count * 3) + 2].Split(',');
            List<object> hero = new List<object>();
            for (int i = 0; i < value.Length; i++)
            {
                hero.Add(value[i]);
            }
            hero.Add(savedgamedata[(current_count * 3)]);
            Debug.Log(hero.Count);
            string myString = hero[7].ToString(); //defense

            // Insert the string at index 2
            hero.Insert(8, myString);

            GameObject unit = unitsarray[int.Parse(hero[hero.Count - 2].ToString())];
            float y = convertor.placeunitontile(unit, newtile);
            Vector3 desiredPosition = new Vector3((float)currentx, y, (float)currentz);
            GameObject instantiatedObject = Instantiate(unit, desiredPosition, Quaternion.Euler(0f, 0f, 0f), GameObject.Find("units").transform);
            ++current_count;
            main.Instance.unit_Info.Create_unit(hero, instantiatedObject);
            if (instantiatedObject.GetComponent<unit_info>().Type == "hitter")
            {
                instantiatedObject.GetComponent<unit_info>().extraMove = true;
            }
            stats_ui.setui(instantiatedObject);
            bool nothere = true;
            for (int i = 0; i < newturn.units.Count; i++)
            {
                Debug.Log("huh");
                if (newturn.units[i][0].GetComponent<unit_info>().controller
                    == instantiatedObject.GetComponent<unit_info>().controller)
                {
                    newturn.units[i].Add(instantiatedObject);
                    nothere = false;
                }
            }
            if (nothere)
            {
                Debug.Log("check");
                List<GameObject> controller = new List<GameObject>();
                controller.Add(instantiatedObject);

                // Create a new instance of the controller list before adding it to people list
                List<GameObject> newController = new List<GameObject>(controller);
                newturn.units.Add(newController);
            }
        }
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
